plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "cat.asra.rusc"
    compileSdk = 34

    defaultConfig {
        applicationId = "cat.asra.rusc"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
        externalNativeBuild {
            cmake {
                arguments += "-DANDROID_STL=c++_shared"
                cppFlags += "-std=c++17"
            }
        }
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    // Firma fija guardada en el proyecto: todas las compilaciones llevan la misma, así una versión nueva
    // se instala encima de la anterior y conserva favoritos y ajustes.
    signingConfigs {
        create("rusc") {
            storeFile = file("rusc.jks")
            storePassword = "ruscrusc"
            keyAlias = "rusc"
            keyPassword = "ruscrusc"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("rusc")
        }
    }

    buildFeatures { prefab = true }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.google.oboe:oboe:1.9.0")
}
