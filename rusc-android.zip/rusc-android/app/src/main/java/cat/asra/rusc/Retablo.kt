package cat.asra.rusc

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// Cabecera: dos columnas salomónicas sostienen un arco con el nombre. Estática: se dibuja solo al cambiar de tamaño.
class Retablo(context: Context) : View(context) {
    private val left = SolomonicColumn()
    private val right = SolomonicColumn()
    private val arch = Path()
    private val voussoirs = Path()
    private val keystone = Path()
    private val stars = Path()
    private val archPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val archEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Magic.goldDark }
    private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Magic.goldLight }
    private val title = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private var tx = 0f
    private var ty = 0f

    init {
        contentDescription = "Rusc"
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, (w * .40f).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val W = w.toFloat()
        val H = h.toFloat()
        val colW = W * .1f
        val colTop = H * .37f
        left.layout(W * .015f, colTop, colW, H - colTop - H * .02f)
        right.layout(W - W * .015f - colW, colTop, colW, H - colTop - H * .02f)

        // arco rebajado entre los capiteles, con dovelas y clave
        arch.reset(); voussoirs.reset(); keystone.reset(); stars.reset()
        val cx = W / 2
        val baseY = colTop
        val rx = (W - 2 * W * .015f - colW) / 2
        val ry = H * .24f
        val band = H * .07f
        val outer = RectF(cx - rx - colW * .5f, baseY - ry - band, cx + rx + colW * .5f, baseY + ry + band)
        val inner = RectF(cx - rx + colW * .5f, baseY - ry + band * .2f, cx + rx - colW * .5f, baseY + ry)
        arch.arcTo(outer, 180f, 180f, true)
        arch.arcTo(inner, 0f, -180f, false)
        arch.close()
        val n = 15
        for (i in 1 until n) {
            val a = PI + PI * i / n
            voussoirs.moveTo(cx + (inner.width() / 2) * cos(a).toFloat(), baseY + (inner.height() / 2) * sin(a).toFloat())
            voussoirs.lineTo(cx + (outer.width() / 2) * cos(a).toFloat(), baseY + (outer.height() / 2) * sin(a).toFloat())
        }
        val kTop = outer.top - band * .35f
        val kBot = inner.top + band * .5f
        keystone.moveTo(cx - band * .75f, kTop)
        keystone.lineTo(cx + band * .75f, kTop)
        keystone.lineTo(cx + band * .45f, kBot)
        keystone.lineTo(cx - band * .45f, kBot)
        keystone.close()
        archPaint.shader = LinearGradient(0f, outer.top, 0f, baseY,
            intArrayOf(Magic.goldLight, Magic.gold, Magic.goldDark), null, Shader.TileMode.CLAMP)
        archEdge.strokeWidth = W * .004f

        // destellos bajo el arco
        val spots = floatArrayOf(.27f, .55f, .012f, .73f, .5f, .014f, .36f, .8f, .009f, .64f, .86f, .01f, .2f, .78f, .007f, .8f, .72f, .008f)
        for (i in spots.indices step 3) Shapes.sparkle(stars, W * spots[i], H * spots[i + 1], W * spots[i + 2] * 2.2f)

        title.typeface = Magic.font
        title.textSize = H * .34f
        title.shader = LinearGradient(0f, H * .5f, 0f, H * .85f,
            intArrayOf(Magic.goldLight, Magic.gold, Color.parseColor("#A87C2E")), null, Shader.TileMode.CLAMP)
        tx = cx
        ty = H * .6f - (title.descent() + title.ascent()) / 2
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawPath(stars, starPaint)
        canvas.drawPath(arch, archPaint)
        canvas.drawPath(voussoirs, archEdge)
        canvas.drawPath(arch, archEdge)
        canvas.drawPath(keystone, archPaint)
        canvas.drawPath(keystone, archEdge)
        left.draw(canvas)
        right.draw(canvas)
        canvas.drawText("Rusc", tx, ty, title)
    }
}
