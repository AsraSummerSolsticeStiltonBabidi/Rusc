package cat.asra.rusc

// Estado compartido entre el servicio y la pantalla
object Status {
    @Volatile var running = false
    @Volatile var audioOk = false
    @Volatile var midi = ""
    @Volatile var sf2Names: List<String> = emptyList()
    @Volatile var sf2Busy = false
    @Volatile var onStopped: (() -> Unit)? = null
}
