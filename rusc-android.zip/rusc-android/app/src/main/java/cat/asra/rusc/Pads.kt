package cat.asra.rusc

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.provider.OpenableColumns
import android.text.TextPaint
import android.text.TextUtils
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicIntegerArray
import kotlin.math.abs

// Sampler de pads: carga de samples (cualquier formato de audio que abra el móvil) y sus ajustes.
object Pads {
    const val N = 10

    // Mismo orden que Pads::What en pads.h
    const val TRIGGER = 0
    const val VOLUME = 1
    const val REVERB = 2
    const val DELAY = 3
    const val LOWCUT = 4
    const val LOOP = 5

    const val EMPTY = 0
    const val LOADING = 1
    const val READY = 2
    val state = AtomicIntegerArray(N)

    fun name(p: SharedPreferences, i: Int): String = p.getString("pad_${i}_name", "") ?: ""
    fun volume(p: SharedPreferences, i: Int) = p.getFloat("pad_${i}_vol", .8f)
    fun reverb(p: SharedPreferences, i: Int) = p.getFloat("pad_${i}_rev", 0f)
    fun delay(p: SharedPreferences, i: Int) = p.getFloat("pad_${i}_dly", 0f)
    fun lowCut(p: SharedPreferences, i: Int) = p.getFloat("pad_${i}_cut", 20f)
    fun loop(p: SharedPreferences, i: Int) = p.getBoolean("pad_${i}_loop", false)

    fun applyParams(p: SharedPreferences) {
        for (i in 0 until N) {
            Engine.pad(i, VOLUME, volume(p, i))
            Engine.pad(i, REVERB, reverb(p, i))
            Engine.pad(i, DELAY, delay(p, i))
            Engine.pad(i, LOWCUT, lowCut(p, i))
            Engine.pad(i, LOOP, if (loop(p, i)) 1f else 0f)
        }
    }

    // Vuelve a cargar los samples guardados. Bloqueante: llamar desde un hilo secundario.
    fun restore(c: Context) {
        val p = Sound.prefs(c)
        for (i in 0 until N) {
            val u = p.getString("pad_${i}_uri", null) ?: continue
            if (state.get(i) == EMPTY) load(c, i, Uri.parse(u))
        }
    }

    fun fileName(c: Context, uri: Uri): String {
        val full = runCatching {
            c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        }.getOrNull() ?: "Sample"
        val dot = full.lastIndexOf('.')
        return if (dot > 0) full.substring(0, dot) else full
    }

    fun clear(i: Int) {
        Engine.padClear(i)
        state.set(i, EMPTY)
    }

    // Decodifica el archivo y se lo pasa al motor por trozos. Bloqueante: llamar desde un hilo secundario.
    fun load(c: Context, i: Int, uri: Uri): Boolean {
        state.set(i, LOADING)
        val ok = decode(c, i, uri)
        if (!ok) Engine.padClear(i)
        state.set(i, if (ok) READY else EMPTY)
        return ok
    }

    private fun decode(c: Context, i: Int, uri: Uri): Boolean {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(c, uri, null)
            var track = -1
            var fmt: MediaFormat? = null
            for (t in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(t)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { track = t; fmt = f; break }
            }
            val format = fmt ?: return false
            ex.selectTrack(track)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return false
            var rate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var encoding = AudioFormat.ENCODING_PCM_16BIT
            format.setInteger(MediaFormat.KEY_PCM_ENCODING, AudioFormat.ENCODING_PCM_16BIT)
            val dec = MediaCodec.createDecoderByType(mime)
            codec = dec
            dec.configure(format, null, null, 0)
            dec.start()
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            var begun = false
            var shorts = ShortArray(0)
            var idle = 0
            while (!outDone && idle < 500) {
                if (!inDone) {
                    val ii = dec.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val buf = dec.getInputBuffer(ii)
                        val n = if (buf != null) ex.readSampleData(buf, 0) else -1
                        if (n < 0) {
                            dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            dec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = dec.dequeueOutputBuffer(info, 10000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = dec.outputFormat
                    rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    if (of.containsKey(MediaFormat.KEY_PCM_ENCODING)) encoding = of.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    idle = 0
                } else if (oi >= 0) {
                    idle = 0
                    val ob = dec.getOutputBuffer(oi)
                    if (ob != null && info.size > 0) {
                        if (!begun) { Engine.padBegin(i, channels, rate); begun = true }
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        ob.order(ByteOrder.LITTLE_ENDIAN)
                        val n: Int
                        if (encoding == AudioFormat.ENCODING_PCM_FLOAT) {
                            val fb = ob.asFloatBuffer()
                            n = fb.remaining()
                            if (shorts.size < n) shorts = ShortArray(n)
                            for (k in 0 until n) shorts[k] = (fb.get(k).coerceIn(-1f, 1f) * 32767f).toInt().toShort()
                        } else if (encoding == AudioFormat.ENCODING_PCM_16BIT) {
                            val sb = ob.asShortBuffer()
                            n = sb.remaining()
                            if (shorts.size < n) shorts = ShortArray(n)
                            sb.get(shorts, 0, n)
                        } else {
                            return false   // formato de muestra que no sabemos leer
                        }
                        Engine.padAppend(i, shorts, n, channels)
                    }
                    dec.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else {
                    idle++
                }
            }
            return begun && Engine.padEnd(i)
        } catch (e: Exception) {
            return false
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { ex.release() }
        }
    }
}

// Pad heptagonal: suena al tocarlo (sin esperar a levantar el dedo). Ocupa toda su celda.
class PadView(context: Context, private val index: Int, private val onPress: () -> Unit) : View(context) {
    private var label = ""
    private var state = Pads.EMPTY
    private var selected = false
    private var playing = false
    private var progress = 0f

    private val shape = Path()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND }
    private val ink = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Magic.font }
    private val jewel = Magic.jewels[index % Magic.jewels.size]

    init { contentDescription = "Pad ${index + 1}" }

    private fun blend(a: Int, b: Int, t: Float) = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt())

    fun show(label: String, state: Int, selected: Boolean) {
        if (label == this.label && state == this.state && selected == this.selected) return
        this.label = label; this.state = state; this.selected = selected
        invalidate()
    }

    fun setPlaying(on: Boolean, pos: Float) {
        if (on == playing && (!on || abs(pos - progress) < .004f)) return
        playing = on; progress = pos
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        // heptágono regular estirado hasta llenar la celda
        val xs = FloatArray(7)
        val ys = FloatArray(7)
        Shapes.heptagon(xs, ys, 0f, 0f, 1f, 0f)
        val x0 = xs.minOrNull() ?: -1f
        val x1 = xs.maxOrNull() ?: 1f
        val y0 = ys.minOrNull() ?: -1f
        val y1 = ys.maxOrNull() ?: 1f
        val m = minOf(w, h) * .05f
        shape.reset()
        for (k in 0 until 7) {
            val x = m + (xs[k] - x0) / (x1 - x0) * (w - 2 * m)
            val y = m + (ys[k] - y0) / (y1 - y0) * (h - 2 * m)
            if (k == 0) shape.moveTo(x, y) else shape.lineTo(x, y)
        }
        shape.close()
        edge.strokeWidth = minOf(w, h) * .022f
    }

    override fun onDraw(c: Canvas) {
        val loaded = state == Pads.READY
        fill.color = when {
            !loaded -> Magic.surface
            playing -> blend(jewel, Magic.goldLight, .28f)
            else -> jewel
        }
        c.drawPath(shape, fill)
        if (playing) {   // lo ya sonado se ilumina de izquierda a derecha
            glow.color = Color.argb(70, 255, 246, 214)
            c.save()
            c.clipPath(shape)
            c.drawRect(0f, 0f, width * progress, height.toFloat(), glow)
            c.restore()
        }
        edge.color = when {
            selected -> Magic.heartLight
            playing -> Magic.goldLight
            loaded -> Magic.gold
            else -> Magic.line
        }
        c.drawPath(shape, edge)
        val cx = width / 2f
        val cy = height / 2f
        val u = minOf(width, height).toFloat()
        ink.textSize = u * .2f
        ink.color = if (loaded) Magic.goldLight else Magic.muted
        c.drawText((index + 1).toString(), cx, cy - u * .02f, ink)
        ink.textSize = u * .105f
        ink.color = if (loaded) Magic.ink else Magic.muted
        val text = when (state) { Pads.LOADING -> "cargando…"; Pads.READY -> label; else -> "vacío" }
        c.drawText(TextUtils.ellipsize(text, ink, width * .62f, TextUtils.TruncateAt.END).toString(), cx, cy + u * .17f, ink)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            onPress()
        }
        return true
    }
}
