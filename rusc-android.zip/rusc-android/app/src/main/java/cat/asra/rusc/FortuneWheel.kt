package cat.asra.rusc

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// Rueda de la fortuna heptagonal. Las notas pulsadas aparecen en el aro según su clase de altura
// (0 cents arriba) y el corazón muestra los intervalos entre notas vecinas, en cents.
class FortuneWheel(context: Context) : View(context) {
    private val left = SolomonicColumn()
    private val right = SolomonicColumn()

    private val vx = FloatArray(7)
    private val vy = FloatArray(7)
    private val ix = FloatArray(7)
    private val iy = FloatArray(7)
    private val seg = Path()
    private val rim = Path()
    private val innerRim = Path()
    private val heartPath = Path()
    private val pointer = Path()
    private val chord = Path()

    private val segPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val spoke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Magic.gold; strokeCap = Paint.Cap.ROUND }
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Magic.gold; strokeJoin = Paint.Join.ROUND }
    private val rimDark = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Magic.goldDark; strokeJoin = Paint.Join.ROUND }
    private val thin = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(110, 210, 168, 82) }
    private val stud = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Magic.goldLight }
    private val studEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Magic.goldDark }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(70, 235, 228, 210) }
    private val dotGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(90, 111, 198, 177) }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Magic.live }
    private val chordFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(45, 111, 198, 177) }
    private val chordLine = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(150, 111, 198, 177) }
    private val heartFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val heartEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Magic.goldLight }
    private val hub = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(215, 22, 34, 42) }
    private val hubRing = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(160, 210, 168, 82) }
    private val pointerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Magic.goldLight }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Magic.ink; textAlign = Paint.Align.CENTER }

    private var cx = 0f
    private var cy = 0f
    private var r = 0f
    private var heartW = 0f

    // estado
    private val pitches = FloatArray(Synth_MAX)
    private var count = 0
    private val angles = FloatArray(Synth_MAX)
    private val ring = FloatArray(Synth_MAX)     // ángulos ordenados alrededor del aro
    private var lines: List<String> = emptyList()
    private var textSize = 0f

    // animación: giro de un gajo al entrar notas y latido del corazón
    private var rot = 0f
    private var rotTarget = 0f
    private var beat = 0f
    private var lastFrame = 0L

    companion object { const val Synth_MAX = 24 }

    init { contentDescription = "Intervalos" }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val W = w.toFloat()
        val H = h.toFloat()
        val colW = min(W * .085f, H * .14f)
        left.layout(W * .03f, H * .06f, colW, H * .9f)
        right.layout(W - W * .03f - colW, H * .06f, colW, H * .9f)
        cx = W / 2
        cy = H * .53f
        r = min(H * .44f, (W - 2 * (colW + W * .06f)) * .5f)
        heartW = r * .74f
        Shapes.heart(heartPath, cx, cy + r * .03f, heartW)
        heartFill.shader = RadialGradient(cx - heartW * .15f, cy - heartW * .2f, heartW * .75f,
            intArrayOf(Magic.heartLight, Magic.heart, Magic.heartDark), floatArrayOf(0f, .45f, 1f), Shader.TileMode.CLAMP)
        pointer.reset()
        val pt = cy - r * 1.07f
        pointer.moveTo(cx - r * .07f, pt - r * .1f)
        pointer.lineTo(cx + r * .07f, pt - r * .1f)
        pointer.lineTo(cx, pt + r * .06f)
        pointer.close()
        rimPaint.strokeWidth = r * .07f
        rimDark.strokeWidth = r * .11f
        spoke.strokeWidth = r * .022f
        thin.strokeWidth = r * .012f
        studEdge.strokeWidth = r * .012f
        track.strokeWidth = r * .01f
        chordLine.strokeWidth = r * .018f
        heartEdge.strokeWidth = r * .02f
        hubRing.strokeWidth = r * .014f
        text.typeface = Magic.font
        relayoutText()
    }

    // Llamado desde el sondeo de la interfaz; solo redibuja si algo cambió
    fun update(buf: FloatArray, n: Int) {
        var same = n == count
        if (same) for (i in 0 until n) if (abs(buf[i] - pitches[i]) > .05f) { same = false; break }
        if (same) return
        val grew = n > count
        for (i in 0 until n) pitches[i] = buf[i]
        count = n
        pitches.sort(0, n)
        for (i in 0 until n) {
            val pc = ((pitches[i] % 1200f) + 1200f) % 1200f
            angles[i] = (pc / 1200f * 2 * PI - PI / 2).toFloat()
            ring[i] = angles[i]
        }
        ring.sort(0, n)
        val iv = ArrayList<String>(n)
        for (i in 1 until n) iv.add("${(pitches[i] - pitches[i - 1]).roundToInt()}¢")
        // un intervalo por línea mientras quepan; con muchas notas se agrupan
        val perLine = when { iv.size <= 4 -> 1; iv.size <= 8 -> 2; else -> 3 }
        lines = iv.chunked(perLine).map { it.joinToString("  ") }
        contentDescription = if (iv.isEmpty()) "Intervalos" else iv.joinToString(", ")
        relayoutText()
        if (grew) {
            rotTarget += (2 * PI / 7).toFloat()
            beat = 1f
            if (rotTarget > 2 * PI * 7) { rotTarget -= (2 * PI * 7).toFloat(); rot -= (2 * PI * 7).toFloat() }
        }
        startAnimation()
    }

    private fun relayoutText() {
        if (heartW <= 0f || lines.isEmpty()) return
        var size = r * .19f
        text.textSize = size
        val widest = lines.maxOf { text.measureText(it) }
        val maxW = heartW * (if (lines.size <= 2) .7f else .62f)
        if (widest > maxW) size *= maxW / widest
        val maxH = heartW * .42f / (lines.size * 1.1f)
        if (size > maxH) size = maxH
        textSize = size
    }

    private fun startAnimation() {
        lastFrame = SystemClock.uptimeMillis()
        postInvalidateOnAnimation()
    }

    override fun onDraw(c: Canvas) {
        // avance de la animación con tiempo real (independiente de la tasa de refresco)
        val now = SystemClock.uptimeMillis()
        val dt = ((now - lastFrame).coerceIn(0, 50)) / 1000f
        lastFrame = now
        val k = 1f - exp(-dt * 9f)
        rot += (rotTarget - rot) * k
        beat *= exp(-dt * 7f)
        val animating = abs(rotTarget - rot) > .001f || beat > .01f
        if (!animating) { rot = rotTarget; beat = 0f }

        left.draw(c)
        right.draw(c)

        // gajos, radios y aro que giran
        Shapes.heptagon(vx, vy, cx, cy, r, rot)
        Shapes.heptagon(ix, iy, cx, cy, r * .6f, rot)
        for (i in 0 until 7) {
            val j = (i + 1) % 7
            seg.reset()
            seg.moveTo(cx, cy); seg.lineTo(vx[i], vy[i]); seg.lineTo(vx[j], vy[j]); seg.close()
            segPaint.color = Magic.jewels[i]
            c.drawPath(seg, segPaint)
        }
        rim.reset(); innerRim.reset()
        for (i in 0 until 7) {
            if (i == 0) { rim.moveTo(vx[0], vy[0]); innerRim.moveTo(ix[0], iy[0]) }
            else { rim.lineTo(vx[i], vy[i]); innerRim.lineTo(ix[i], iy[i]) }
        }
        rim.close(); innerRim.close()
        for (i in 0 until 7) c.drawLine(ix[i], iy[i], vx[i], vy[i], spoke)
        c.drawPath(innerRim, thin)
        c.drawPath(rim, rimDark)
        c.drawPath(rim, rimPaint)
        for (i in 0 until 7) {
            c.drawCircle(vx[i], vy[i], r * .065f, stud)
            c.drawCircle(vx[i], vy[i], r * .065f, studEdge)
        }

        // notas pulsadas (marco fijo): aro de alturas, polígono del acorde y puntos
        val tr = r * .8f
        c.drawCircle(cx, cy, tr, track)
        if (count >= 2) {
            chord.reset()
            for (i in 0 until count) {
                val x = cx + tr * cos(ring[i].toDouble()).toFloat()
                val y = cy + tr * sin(ring[i].toDouble()).toFloat()
                if (i == 0) chord.moveTo(x, y) else chord.lineTo(x, y)
            }
            chord.close()
            c.drawPath(chord, chordFill)
            c.drawPath(chord, chordLine)
        }
        for (i in 0 until count) {
            val x = cx + tr * cos(angles[i].toDouble()).toFloat()
            val y = cy + tr * sin(angles[i].toDouble()).toFloat()
            c.drawCircle(x, y, r * .075f, dotGlow)
            c.drawCircle(x, y, r * .042f, dot)
        }

        // medallón bajo el corazón: separa el texto de radios y líneas
        c.drawCircle(cx, cy, heartW * .64f, hub)
        c.drawCircle(cx, cy, heartW * .64f, hubRing)

        // corazón con latido y los intervalos
        val s = 1f + beat * .07f
        c.save()
        c.scale(s, s, cx, cy)
        c.drawPath(heartPath, heartFill)
        c.drawPath(heartPath, heartEdge)
        if (lines.isNotEmpty()) {
            text.textSize = textSize
            val lh = textSize * 1.15f
            val top = cy + heartW * .03f - lh * (lines.size - 1) / 2 - (text.descent() + text.ascent()) / 2
            for (i in lines.indices) c.drawText(lines[i], cx, top + i * lh, text)
        }
        c.restore()
        c.drawPath(pointer, pointerPaint)

        if (animating) postInvalidateOnAnimation()
    }
}
