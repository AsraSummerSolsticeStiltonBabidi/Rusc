package cat.asra.rusc

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// Rueda de la fortuna heptagonal. Las notas pulsadas aparecen en el aro según su clase de altura
// (0 cents arriba) y el corazón muestra los intervalos entre notas vecinas, en cents.
class FortuneWheel(context: Context) : View(context) {
    private val left = SolomonicColumn()
    private val right = SolomonicColumn()

    private val vx = FloatArray(7)
    private val vy = FloatArray(7)
    private val ix = FloatArray(7)
    private val iy = FloatArray(7)
    private val seg = Path()
    private val rim = Path()
    private val innerRim = Path()
    private val heartPath = Path()
    private val pointer = Path()
    private val chord = Path()

    private val segPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val spoke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Magic.gold; strokeCap = Paint.Cap.ROUND }
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Magic.gold; strokeJoin = Paint.Join.ROUND }
    private val rimDark = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Magic.goldDark; strokeJoin = Paint.Join.ROUND }
    private val thin = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(110, 210, 168, 82) }
    private val stud = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Magic.goldLight }
    private val studEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Magic.goldDark }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(70, 235, 228, 210) }
    private val dotGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(90, 111, 198, 177) }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Magic.live }
    private val chordFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(45, 111, 198, 177) }
    private val chordLine = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(150, 111, 198, 177) }
    private val heartFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val heartEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Magic.goldLight }
    private val hub = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(215, 22, 34, 42) }
    private val hubRing = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(160, 210, 168, 82) }
    private val pointerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Magic.goldLight }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Magic.ink; textAlign = Paint.Align.CENTER }

    private var cx = 0f
    private var cy = 0f
    private var r = 0f
    private var heartW = 0f

    // estado: notas mostradas (pulsadas o en release de 0,5 s)
    private val keys = IntArray(MAXN)
    private val pitches = FloatArray(MAXN)
    private val released = LongArray(MAXN)     // 0 = pulsada; si no, instante en que se soltó
    private var count = 0
    private val order = IntArray(MAXN)          // índices ordenados de grave a agudo
    private val angles = FloatArray(MAXN)
    private val ring = FloatArray(MAXN)         // ángulos ordenados alrededor del aro
    private var lines: List<String> = emptyList()
    private var textSize = 0f
    private val segs = FloatArray(MAXN * 2 * 6)   // x1, y1, x2, y2, octava, opacidad
    private var nSegs = 0
    private val bandPaint = Array(BAND_COLORS.size) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = BAND_COLORS[it] }
    }

    // animación: giro de un gajo al entrar notas y latido del corazón
    private var rot = 0f
    private var rotTarget = 0f
    private var beat = 0f
    private var lastFrame = 0L

    companion object {
        const val Synth_MAX = 24
        const val MAXN = 32
        const val RELEASE_MS = 500L
        // un color por cada octava por encima de la nota más grave
        val BAND_COLORS = intArrayOf(
            Color.parseColor("#6FC6B1"), Color.parseColor("#F2D27A"), Color.parseColor("#E8707E"),
            Color.parseColor("#B08CEB"), Color.parseColor("#7DB7F0"), Color.parseColor("#B5D86A"))
    }

    init { contentDescription = "Intervalos" }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val W = w.toFloat()
        val H = h.toFloat()
        val colW = min(W * .085f, H * .14f)
        left.layout(W * .03f, H * .06f, colW, H * .9f)
        right.layout(W - W * .03f - colW, H * .06f, colW, H * .9f)
        cx = W / 2
        cy = H * .53f
        r = min(H * .44f, (W - 2 * (colW + W * .06f)) * .5f)
        heartW = r * .74f
        Shapes.heart(heartPath, cx, cy + r * .03f, heartW)
        heartFill.shader = RadialGradient(cx - heartW * .15f, cy - heartW * .2f, heartW * .75f,
            intArrayOf(Magic.heartLight, Magic.heart, Magic.heartDark), floatArrayOf(0f, .45f, 1f), Shader.TileMode.CLAMP)
        pointer.reset()
        val pt = cy - r * 1.07f
        pointer.moveTo(cx - r * .07f, pt - r * .1f)
        pointer.lineTo(cx + r * .07f, pt - r * .1f)
        pointer.lineTo(cx, pt + r * .06f)
        pointer.close()
        rimPaint.strokeWidth = r * .07f
        rimDark.strokeWidth = r * .11f
        spoke.strokeWidth = r * .022f
        thin.strokeWidth = r * .012f
        studEdge.strokeWidth = r * .012f
        track.strokeWidth = r * .01f
        chordLine.strokeWidth = r * .018f
        // octavas más agudas: trazo más fino, dibujado encima (cordón de colores si coinciden)
        bandPaint.forEachIndexed { b, p -> p.strokeWidth = r * .034f * (1f - .2f * b) }
        heartEdge.strokeWidth = r * .02f
        hubRing.strokeWidth = r * .014f
        text.typeface = Magic.font
        relayoutText()
    }

    // Llamado desde el sondeo de la interfaz con las notas pulsadas (nota en cents + identidad canal/nota).
    // Las que se sueltan se quedan 0,5 s desvaneciéndose, para ver acordes rasgueados enteros.
    fun update(buf: FloatArray, ids: IntArray, n: Int) {
        val now = SystemClock.uptimeMillis()
        var changed = false
        var grew = false
        for (i in 0 until count) {
            if (released[i] != 0L) continue
            var still = false
            for (j in 0 until n) if (ids[j] == keys[i]) { still = true; break }
            if (!still) { released[i] = now; changed = true }
        }
        for (j in 0 until n) {
            var found = -1
            for (i in 0 until count) if (keys[i] == ids[j]) { found = i; break }
            if (found >= 0) {
                if (released[found] != 0L) { released[found] = 0L; changed = true }
                if (abs(pitches[found] - buf[j]) > .05f) { pitches[found] = buf[j]; changed = true }
            } else if (count < MAXN) {
                keys[count] = ids[j]; pitches[count] = buf[j]; released[count] = 0L; count++
                changed = true; grew = true
            }
        }
        if (prune(now)) changed = true
        if (!changed) return
        relayout()
        if (grew) {
            rotTarget += (2 * PI / 7).toFloat()
            beat = 1f
            if (rotTarget > 2 * PI * 7) { rotTarget -= (2 * PI * 7).toFloat(); rot -= (2 * PI * 7).toFloat() }
        }
        startAnimation()
    }

    // quita las notas cuyo release terminó
    private fun prune(now: Long): Boolean {
        var w = 0
        val before = count
        for (i in 0 until count) {
            if (released[i] != 0L && now - released[i] >= RELEASE_MS) continue
            keys[w] = keys[i]; pitches[w] = pitches[i]; released[w] = released[i]; w++
        }
        count = w
        return w != before
    }

    private fun relayout() {
        for (i in 0 until count) order[i] = i
        // orden de grave a agudo (inserción: pocas notas)
        for (i in 1 until count) {
            val o = order[i]; var j = i - 1
            while (j >= 0 && pitches[order[j]] > pitches[o]) { order[j + 1] = order[j]; j-- }
            order[j + 1] = o
        }
        for (i in 0 until count) {
            val pc = ((pitches[i] % 1200f) + 1200f) % 1200f
            angles[i] = (pc / 1200f * 2 * PI - PI / 2).toFloat()
            ring[i] = angles[i]
        }
        ring.sort(0, count)
        val iv = ArrayList<String>(count)
        for (k in 1 until count) iv.add("${(pitches[order[k]] - pitches[order[k - 1]]).roundToInt()}¢")
        val perLine = when { iv.size <= 4 -> 1; iv.size <= 8 -> 2; else -> 3 }
        lines = iv.chunked(perLine).map { it.joinToString("  ") }
        contentDescription = if (iv.isEmpty()) "Intervalos" else iv.joinToString(", ")
        relayoutText()
    }

    private fun alphaOf(i: Int, now: Long): Float =
        if (released[i] == 0L) 1f else (1f - (now - released[i]).toFloat() / RELEASE_MS).coerceIn(0f, 1f)

    private fun px(a: Float, rr: Float) = cx + rr * cos(a.toDouble()).toFloat()
    private fun py(a: Float, rr: Float) = cy + rr * sin(a.toDouble()).toFloat()

    // Recorrido de grave a agudo: cada tramo toma el color de su octava sobre el bajo; si cruza
    // el techo de una octava, se parte justo donde atraviesa el radio de la nota más grave.
    private fun drawVoicing(c: Canvas, tr: Float, now: Long) {
        val bass = pitches[order[0]]
        val bx = px(angles[order[0]], tr); val by = py(angles[order[0]], tr)
        fun band(p: Float) = (((p - bass) / 1200f).toInt()).coerceIn(0, BAND_COLORS.size - 1)
        nSegs = 0
        fun seg(x1: Float, y1: Float, x2: Float, y2: Float, b: Int, alpha: Float) {
            val o = nSegs * 6
            segs[o] = x1; segs[o + 1] = y1; segs[o + 2] = x2; segs[o + 3] = y2
            segs[o + 4] = b.toFloat(); segs[o + 5] = alpha
            nSegs++
        }
        for (k in 0 until count) {
            val a = order[k]
            val b = if (k + 1 < count) order[k + 1] else order[0]
            val closing = k + 1 >= count
            if (count < 2) break
            val x1 = px(angles[a], tr); val y1 = py(angles[a], tr)
            val x2 = px(angles[b], tr); val y2 = py(angles[b], tr)
            val al = minOf(alphaOf(a, now), alphaOf(b, now))
            val ba = band(pitches[a])
            val bb = if (closing) ba else band(pitches[b])
            if (bb == ba) { seg(x1, y1, x2, y2, ba, al); continue }
            // intersección del tramo con la recta centro-bajo
            val dx = x2 - x1; val dy = y2 - y1; val ex = bx - cx; val ey = by - cy
            val den = dx * ey - dy * ex
            var t = -1f
            if (abs(den) > 1e-6f) {
                t = ((cx - x1) * ey - (cy - y1) * ex) / den
                val s = ((cx - x1) * dy - (cy - y1) * dx) / den
                if (s < 0f) t = -1f
            }
            if (t in 0.01f..0.99f) {
                val ix = x1 + dx * t; val iy = y1 + dy * t
                seg(x1, y1, ix, iy, ba, al)
                seg(ix, iy, x2, y2, bb, al)
            } else seg(x1, y1, x2, y2, bb, al)
        }
        for (b in BAND_COLORS.indices) for (i in 0 until nSegs) {
            val o = i * 6
            if (segs[o + 4].toInt() != b) continue
            val pnt = bandPaint[b]
            pnt.alpha = (segs[o + 5] * 230).toInt()
            c.drawLine(segs[o], segs[o + 1], segs[o + 2], segs[o + 3], pnt)
        }
    }

    private fun relayoutText() {
        if (heartW <= 0f || lines.isEmpty()) return
        var size = r * .19f
        text.textSize = size
        val widest = lines.maxOf { text.measureText(it) }
        val maxW = heartW * (if (lines.size <= 2) .7f else .62f)
        if (widest > maxW) size *= maxW / widest
        val maxH = heartW * .42f / (lines.size * 1.1f)
        if (size > maxH) size = maxH
        textSize = size
    }

    private fun startAnimation() {
        lastFrame = SystemClock.uptimeMillis()
        postInvalidateOnAnimation()
    }

    override fun onDraw(c: Canvas) {
        // avance de la animación con tiempo real (independiente de la tasa de refresco)
        val now = SystemClock.uptimeMillis()
        val dt = ((now - lastFrame).coerceIn(0, 50)) / 1000f
        lastFrame = now
        val k = 1f - exp(-dt * 9f)
        rot += (rotTarget - rot) * k
        beat *= exp(-dt * 7f)
        val animating = abs(rotTarget - rot) > .001f || beat > .01f
        if (!animating) { rot = rotTarget; beat = 0f }

        left.draw(c)
        right.draw(c)

        // gajos, radios y aro que giran
        Shapes.heptagon(vx, vy, cx, cy, r, rot)
        Shapes.heptagon(ix, iy, cx, cy, r * .6f, rot)
        for (i in 0 until 7) {
            val j = (i + 1) % 7
            seg.reset()
            seg.moveTo(cx, cy); seg.lineTo(vx[i], vy[i]); seg.lineTo(vx[j], vy[j]); seg.close()
            segPaint.color = Magic.jewels[i]
            c.drawPath(seg, segPaint)
        }
        rim.reset(); innerRim.reset()
        for (i in 0 until 7) {
            if (i == 0) { rim.moveTo(vx[0], vy[0]); innerRim.moveTo(ix[0], iy[0]) }
            else { rim.lineTo(vx[i], vy[i]); innerRim.lineTo(ix[i], iy[i]) }
        }
        rim.close(); innerRim.close()
        for (i in 0 until 7) c.drawLine(ix[i], iy[i], vx[i], vy[i], spoke)
        c.drawPath(innerRim, thin)
        c.drawPath(rim, rimDark)
        c.drawPath(rim, rimPaint)
        for (i in 0 until 7) {
            c.drawCircle(vx[i], vy[i], r * .065f, stud)
            c.drawCircle(vx[i], vy[i], r * .065f, studEdge)
        }

        // notas (marco fijo): aro de alturas, forma del acorde, recorrido por octavas y puntos
        val tr = r * .8f
        c.drawCircle(cx, cy, tr, track)
        var fading = false
        for (i in 0 until count) if (released[i] != 0L) fading = true
        if (count >= 2) {
            var amax = 0f
            for (i in 0 until count) amax = maxOf(amax, alphaOf(i, now))
            chord.reset()
            for (i in 0 until count) {
                val x = px(ring[i], tr); val y = py(ring[i], tr)
                if (i == 0) chord.moveTo(x, y) else chord.lineTo(x, y)
            }
            chord.close()
            chordFill.alpha = (45 * amax).toInt()
            c.drawPath(chord, chordFill)
            drawVoicing(c, tr, now)
        }
        for (i in 0 until count) {
            val al = alphaOf(i, now)
            val x = px(angles[i], tr); val y = py(angles[i], tr)
            dotGlow.alpha = (90 * al).toInt(); dot.alpha = (255 * al).toInt()
            c.drawCircle(x, y, r * .075f, dotGlow)
            c.drawCircle(x, y, r * .042f, dot)
        }

        // medallón bajo el corazón: separa el texto de radios y líneas
        c.drawCircle(cx, cy, heartW * .64f, hub)
        c.drawCircle(cx, cy, heartW * .64f, hubRing)

        // corazón con latido y los intervalos
        val s = 1f + beat * .07f
        c.save()
        c.scale(s, s, cx, cy)
        c.drawPath(heartPath, heartFill)
        c.drawPath(heartPath, heartEdge)
        if (lines.isNotEmpty()) {
            text.textSize = textSize
            val lh = textSize * 1.15f
            val top = cy + heartW * .03f - lh * (lines.size - 1) / 2 - (text.descent() + text.ascent()) / 2
            for (i in lines.indices) c.drawText(lines[i], cx, top + i * lh, text)
        }
        c.restore()
        c.drawPath(pointer, pointerPaint)

        if (fading && prune(now)) relayout()
        if (animating || fading) postInvalidateOnAnimation()
    }
}
