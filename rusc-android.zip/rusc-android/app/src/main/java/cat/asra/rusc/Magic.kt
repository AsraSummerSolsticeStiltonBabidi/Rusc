package cat.asra.rusc

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

// Paleta y tipografía comunes
object Magic {
    val bg = Color.parseColor("#16222A")
    val surface = Color.parseColor("#1F2E37")
    val line = Color.parseColor("#34474F")
    val ink = Color.parseColor("#EBE4D2")
    val muted = Color.parseColor("#93A5A9")
    val gold = Color.parseColor("#D2A852")
    val goldDark = Color.parseColor("#7A5A22")
    val goldLight = Color.parseColor("#F6DE93")
    val goldSoft = Color.parseColor("#3A3F34")
    val live = Color.parseColor("#6FC6B1")
    val heart = Color.parseColor("#B23A48")
    val heartLight = Color.parseColor("#E0707A")
    val heartDark = Color.parseColor("#5E1822")
    // Siete gemas apagadas para los gajos de la rueda
    val jewels = intArrayOf(
        Color.parseColor("#4A2530"), Color.parseColor("#4E3A20"), Color.parseColor("#44421F"),
        Color.parseColor("#1F4032"), Color.parseColor("#1B3E42"), Color.parseColor("#22304E"),
        Color.parseColor("#352848")
    )

    var font: Typeface = Typeface.SERIF
}

// Columna salomónica: fuste retorcido en espiral, basa y capitel. Se calcula una vez por tamaño.
class SolomonicColumn {
    private val shaft = Path()
    private val grooves = Path()
    private val shine = Path()
    private val base = Path()
    private val capital = Path()
    private val volutes = Path()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val solid = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(120, 20, 12, 4) }
    private val glint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.argb(150, 255, 240, 190)
        strokeCap = Paint.Cap.ROUND
    }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Magic.goldDark
    }

    fun layout(x: Float, y: Float, w: Float, h: Float) {
        for (p in arrayOf(shaft, grooves, shine, base, capital, volutes)) p.reset()
        val cx = x + w / 2
        val abacus = h * .045f
        val bell = h * .07f
        val plinth = h * .06f
        val torus = h * .035f
        val top = y + abacus + bell
        val bottom = y + h - plinth - torus
        val sh = bottom - top
        val sw = w * .56f
        val amp = w * .085f
        val turns = max(3, (sh / (w * 1.15f)).roundToInt())
        val period = sh / turns

        fun centre(yy: Float) = cx + amp * sin(2.0 * PI * (yy - top) / period).toFloat()

        // silueta ondulante del fuste
        val n = turns * 16
        for (i in 0..n) {
            val yy = top + sh * i / n
            val xx = centre(yy) - sw / 2
            if (i == 0) shaft.moveTo(xx, yy) else shaft.lineTo(xx, yy)
        }
        for (i in n downTo 0) {
            val yy = top + sh * i / n
            shaft.lineTo(centre(yy) + sw / 2, yy)
        }
        shaft.close()

        // estrías en espiral (curvas en S de izquierda a derecha) y su brillo
        val th = period * .2f
        var yk = top - period
        while (yk < bottom + period) {
            val y2 = yk + period / 2
            val l1 = centre(yk) - sw / 2
            val r1 = centre(y2) + sw / 2
            grooves.moveTo(l1, yk)
            grooves.cubicTo(l1 + sw * .38f, yk + period * .04f, r1 - sw * .38f, y2 - period * .04f, r1, y2)
            grooves.lineTo(r1, y2 + th)
            grooves.cubicTo(r1 - sw * .38f, y2 + th - period * .04f, l1 + sw * .38f, yk + th + period * .04f, l1, yk + th)
            grooves.close()
            val o = -period * .07f
            shine.moveTo(l1 + sw * .2f, yk + o + period * .06f)
            shine.cubicTo(l1 + sw * .45f, yk + o + period * .1f, r1 - sw * .5f, y2 + o - period * .12f, r1 - sw * .22f, y2 + o - period * .08f)
            yk += period / 2 * 2
        }

        // basa (plinto + toro) y capitel (campana + ábaco + volutas)
        base.addRect(x, y + h - plinth, x + w, y + h, Path.Direction.CW)
        base.addRoundRect(x + w * .07f, bottom, x + w * .93f, bottom + torus, torus / 2, torus / 2, Path.Direction.CW)
        capital.addRect(x, y, x + w, y + abacus, Path.Direction.CW)
        capital.moveTo(x + w * .1f, y + abacus)
        capital.lineTo(x + w * .9f, y + abacus)
        capital.lineTo(cx + sw * .55f, top)
        capital.lineTo(cx - sw * .55f, top)
        capital.close()
        val vr = w * .085f
        volutes.addCircle(x + w * .14f, y + abacus + vr, vr, Path.Direction.CW)
        volutes.addCircle(x + w * .86f, y + abacus + vr, vr, Path.Direction.CW)

        val grad = LinearGradient(x, 0f, x + w, 0f,
            intArrayOf(Magic.goldDark, Magic.gold, Magic.goldLight, Magic.gold, Magic.goldDark),
            floatArrayOf(0f, .25f, .45f, .7f, 1f), Shader.TileMode.CLAMP)
        fill.shader = grad
        solid.shader = grad
        edge.strokeWidth = max(1f, w * .02f)
        glint.strokeWidth = max(1f, w * .035f)
    }

    fun draw(c: Canvas) {
        c.drawPath(base, solid)
        c.drawPath(base, edge)
        c.drawPath(shaft, fill)
        c.save()
        c.clipPath(shaft)
        c.drawPath(grooves, shadow)
        c.drawPath(shine, glint)
        c.restore()
        c.drawPath(shaft, edge)
        c.drawPath(capital, solid)
        c.drawPath(capital, edge)
        c.drawPath(volutes, solid)
        c.drawPath(volutes, edge)
    }
}

object Shapes {
    // Corazón centrado en (cx, cy) de ancho w
    fun heart(p: Path, cx: Float, cy: Float, w: Float) {
        p.reset()
        val h = w * .92f
        val top = cy - h * .42f
        p.moveTo(cx, top + h * .22f)
        p.cubicTo(cx - w * .05f, top - h * .04f, cx - w * .52f, top - h * .06f, cx - w * .5f, top + h * .3f)
        p.cubicTo(cx - w * .48f, top + h * .56f, cx - w * .2f, top + h * .76f, cx, top + h)
        p.cubicTo(cx + w * .2f, top + h * .76f, cx + w * .48f, top + h * .56f, cx + w * .5f, top + h * .3f)
        p.cubicTo(cx + w * .52f, top - h * .06f, cx + w * .05f, top - h * .04f, cx, top + h * .22f)
        p.close()
    }

    // Vértices de un heptágono (primer vértice arriba), girado `rot` radianes
    fun heptagon(xs: FloatArray, ys: FloatArray, cx: Float, cy: Float, r: Float, rot: Float) {
        for (k in 0 until 7) {
            val a = rot - PI / 2 + k * 2 * PI / 7
            xs[k] = cx + r * cos(a).toFloat()
            ys[k] = cy + r * sin(a).toFloat()
        }
    }

    // Destello de cuatro puntas
    fun sparkle(p: Path, cx: Float, cy: Float, r: Float) {
        p.moveTo(cx, cy - r)
        p.quadTo(cx, cy, cx + r * .32f, cy)
        p.quadTo(cx, cy, cx, cy + r)
        p.quadTo(cx, cy, cx - r * .32f, cy)
        p.quadTo(cx, cy, cx, cy - r)
        p.close()
    }
}
