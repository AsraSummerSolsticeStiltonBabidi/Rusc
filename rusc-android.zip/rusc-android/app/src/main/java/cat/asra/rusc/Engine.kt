package cat.asra.rusc

object Engine {
    init { System.loadLibrary("rusc") }

    external fun start(): Boolean
    external fun stop()
    external fun setBufferMode(mode: Int)
    external fun latencyMs(): Float
    external fun xruns(): Int
    external fun bufferFrames(): Int
    external fun sampleRate(): Int
    external fun exclusive(): Boolean
    external fun rpnRange(): Int
    external fun channelMask(): Int
    external fun voices(): Int
    external fun wheelCents(): Float
    external fun modWheel(): Float
    external fun heldNotes(pitches: FloatArray, keys: IntArray): Int
    external fun loadSamples(set: Int, data: ByteArray): Boolean
    external fun samplesReady(set: Int): Boolean
    external fun buildPrimes(mask: Int, maxHarm: Int, slope: Float)
    external fun presetDefault(preset: Int, which: Int): Float
    external fun sf2Open(fd: Int): Int
    external fun sf2Name(i: Int): String
    external fun sf2Select(i: Int): Boolean
    external fun sf2Collect()
    private external fun send(kind: Int, a: Int, b: Int, c: Int, v: Float)

    @Synchronized fun midi(status: Int, d1: Int, d2: Int) = send(0, status, d1, d2, 0f)
    @Synchronized fun param(id: Int, value: Float) = send(1, id, 0, 0, value)

    // Mismo orden que el enum Param de synth.h
    const val PRESET = 0
    const val VOLUME = 1
    const val REVERB_MIX = 2
    const val BEND_NOTE = 3
    const val PANIC = 4
    const val ATTACK = 5          // ATTACK + 0..3 = A, D, S, R
    const val BEND_GLOBAL = 9
    const val MOD_DEST = 10
    const val LFO_RATE = 11
    const val VIB_DEPTH = 12
    const val REVERB_SIZE = 13
    const val DELAY_MIX = 14
    const val DELAY_TIME = 15
    const val DELAY_FB = 16
}
