package cat.asra.rusc

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.provider.OpenableColumns

// Catálogo de timbres y ajustes guardados; aplica todo al motor
object Sound {
    val synths = listOf("E-Piano", "Órgano", "Pulsado", "Pad", "Cuerdas", "Caña",
        "Campana", "Marimba FM", "Kalimba FM", "Sierra", "Bajo", "Seno")
    const val PRIMES = 12
    val sampled = listOf("Piano" to "piano", "Arpa" to "arpa", "Clavecín" to "clavecin", "Vibráfono" to "vibrafono",
        "Marimba" to "marimba", "Kalimba" to "kalimba", "Campanas" to "campanas", "Cítara" to "dantranh")
    const val FIRST_SAMPLE = 13
    const val SF2 = 21
    const val COUNT = 22

    val primes = intArrayOf(2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31)
    val noteRanges = intArrayOf(1, 2, 12, 24, 48, 96)
    val wheelRanges = intArrayOf(1, 2, 3, 5, 7, 12, 24, 48)
    val modTargets = listOf("Vibrato", "Trémolo", "Filtro")
    val bufferModes = listOf("Auto", "1 ráfaga", "2 ráfagas", "3 ráfagas", "4 ráfagas")

    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("rusc", Context.MODE_PRIVATE)

    fun adsr(p: SharedPreferences, preset: Int, which: Int): Float =
        p.getFloat("adsr_${preset}_$which", Engine.presetDefault(preset, which))

    fun selectPreset(p: SharedPreferences, preset: Int) {
        Engine.param(Engine.PRESET, preset.toFloat())
        if (preset != SF2) for (w in 0..3) Engine.param(Engine.ATTACK + w, adsr(p, preset, w))
    }

    fun primeMask(p: SharedPreferences) = p.getInt("primesMask", 0b111)
    fun primeMax(p: SharedPreferences) = p.getInt("primesMax", 32)
    fun primeSlope(p: SharedPreferences) = p.getFloat("primesSlope", 1f)
    fun applyPrimes(p: SharedPreferences) = Engine.buildPrimes(primeMask(p), primeMax(p), primeSlope(p))

    // Armónicos cuyos factores primos están todos en la selección
    fun harmonics(mask: Int, max: Int): List<Int> = (1..max).filter { n ->
        var m = n
        primes.forEachIndexed { k, pr -> if (mask and (1 shl k) != 0) while (m % pr == 0) m /= pr }
        m == 1
    }

    fun applyEffects(p: SharedPreferences) {
        Engine.param(Engine.REVERB_MIX, if (p.getBoolean("revOn", false)) p.getFloat("revMix", .25f) else 0f)
        Engine.param(Engine.REVERB_SIZE, p.getFloat("revSize", .5f))
        Engine.param(Engine.DELAY_MIX, if (p.getBoolean("dlyOn", false)) p.getFloat("dlyMix", .3f) else 0f)
        Engine.param(Engine.DELAY_TIME, p.getFloat("dlyTime", .35f))
        Engine.param(Engine.DELAY_FB, p.getFloat("dlyFb", .35f))
    }

    fun applyAll(c: Context) {
        val p = prefs(c)
        Engine.setBufferMode(p.getInt("buffer", 0))
        Engine.param(Engine.VOLUME, p.getFloat("volume", .8f))
        Engine.param(Engine.BEND_NOTE, p.getInt("bendNote", 48).toFloat())
        Engine.param(Engine.BEND_GLOBAL, p.getInt("bendGlobal", 2).toFloat())
        Engine.param(Engine.MOD_DEST, p.getInt("modDest", 0).toFloat())
        Engine.param(Engine.LFO_RATE, p.getFloat("lfoRate", 5.6f))
        Engine.param(Engine.VIB_DEPTH, p.getFloat("vibDepth", 35f))
        applyEffects(p)
        applyPrimes(p)
        selectPreset(p, p.getInt("preset", 0).coerceIn(0, COUNT - 1))
    }

    // Abre un SoundFont y elige un preset. Bloqueante: llamar desde un hilo secundario.
    fun loadSf2(c: Context, uri: Uri, index: Int): Boolean {
        Status.sf2Busy = true
        return try {
            val pfd = c.contentResolver.openFileDescriptor(uri, "r") ?: return false
            val n = Engine.sf2Open(pfd.detachFd())
            if (n <= 0) return false
            Status.sf2Names = List(n) { Engine.sf2Name(it) }
            Engine.sf2Select(index.coerceIn(0, n - 1))
        } catch (e: Exception) {
            false
        } finally {
            Status.sf2Busy = false
        }
    }

    fun displayName(c: Context, uri: Uri): String = runCatching {
        c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    }.getOrNull() ?: "SoundFont"
}
