package cat.asra.rusc

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.provider.OpenableColumns

// Catálogo de timbres (en páginas) y ajustes guardados; aplica todo al motor.
// Índices: 0-39 sintes, 40 primos, 41-72 sampleados, 73 SoundFont (igual que synth.h)
object Sound {
    const val PRIMES = 40
    const val FIRST_SAMPLE = 41
    const val SF2 = 73
    const val COUNT = 74

    private val synthNames = listOf(
        "Rhodes", "Rhodes suave", "Rhodes bark", "Wurlitzer", "E-Piano DX", "Tine", "Clavinet", "Celesta",
        "Órgano", "Órgano jazz", "Órgano iglesia", "Armonio", "Acordeón", "EP vintage", "Pulsado", "Seno",
        "Pad cálido", "Pad ancho", "Pad cristal", "Coro", "Cuerdas", "Cuerdas lentas", "Atmósfera", "Pad seno",
        "Arpa sint.", "Kalimba FM", "Marimba FM", "Campana", "Vidrio", "Steel drum", "Koto", "Caja música",
        "Caña", "Flauta", "Clarinete", "Metales", "Sierra", "Cuadrada", "Bajo", "Bajo sub")

    // mismo orden que los archivos .rsc del motor
    val sampleFiles = listOf("piano", "pianokawai", "vertical", "tx81z", "clavecin", "clavecinit", "arpa", "arpaceltica",
        "vibrafono", "marimba", "xilofono", "glockenspiel", "balafon", "campanas", "campanillas", "strumstick",
        "kalimba", "glocktubular", "mbira", "nyunga", "dantranh", "salterio", "salterioarco", "clavisynth",
        "organo", "organoren", "ocarina", "flauta", "armonica", "saxo", "saxello", "tx81zpiano")
    private val sampleNames = listOf("Piano", "Piano Kawai", "Vertical", "TX81Z EP", "Clavecín", "Clavecín it.", "Arpa", "Arpa celta",
        "Vibráfono", "Marimba", "Xilófono", "Glockenspiel", "Balafón", "Campanas", "Campanillas", "Strumstick",
        "Kalimba", "Glock tubular", "Mbira", "Nyunga", "Cítara", "Salterio", "Salterio arco", "Clavisynth",
        "Órgano tubos", "Órgano renac.", "Ocarina", "Flauta dulce", "Armónica", "Saxo tenor", "Saxello", "TX81Z piano")

    class Page(val name: String, val presets: List<Int>)

    val synthPages = listOf(
        Page("Eléctricos", (0..7).toList()), Page("Teclados", (8..15).toList()), Page("Pads", (16..23).toList()),
        Page("Pulsados", (24..31).toList()), Page("Viento", (32..39).toList()))
    val samplePages = listOf(
        Page("Pianos", listOf(0, 1, 2, 3, 31, 4, 5, 23).map { it + FIRST_SAMPLE }),
        Page("Cuerdas", listOf(6, 7, 20, 21, 15, 16, 18, 19).map { it + FIRST_SAMPLE }),
        Page("Láminas", listOf(8, 9, 10, 11, 17, 12, 13, 14).map { it + FIRST_SAMPLE }),
        Page("Viento", listOf(24, 25, 26, 27, 28, 29, 30, 22).map { it + FIRST_SAMPLE }))

    fun name(preset: Int): String = when {
        preset < PRIMES -> synthNames[preset]
        preset == PRIMES -> "Primos"
        preset < SF2 -> sampleNames[preset - FIRST_SAMPLE]
        else -> "SoundFont"
    }

    fun isSample(preset: Int) = preset in FIRST_SAMPLE until SF2

    val primes = intArrayOf(2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31)
    val noteRanges = intArrayOf(1, 2, 12, 24, 48, 96)
    val wheelRanges = intArrayOf(1, 2, 3, 5, 7, 12, 24, 48)
    val modTargets = listOf("Vibrato", "Trémolo", "Filtro")
    val bufferModes = listOf("Auto", "1 ráfaga", "2 ráfagas", "3 ráfagas", "4 ráfagas")

    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("rusc", Context.MODE_PRIVATE)

    // ---------- favoritos ----------
    fun favorites(p: SharedPreferences): List<Int> =
        (p.getString("favs", "") ?: "").split(',').mapNotNull { it.toIntOrNull() }.filter { it in 0 until COUNT }

    fun toggleFavorite(p: SharedPreferences, preset: Int): Boolean {
        val f = favorites(p).toMutableList()
        val now = if (preset in f) { f.remove(preset); false } else { f.add(preset); true }
        p.edit().putString("favs", f.joinToString(",")).apply()
        return now
    }

    // ---------- samples bajo demanda ----------
    private val loading = HashSet<Int>()

    // Carga (en segundo plano) el instrumento si hace falta; done() en el hilo que llama a post
    fun ensureSamples(c: Context, preset: Int, done: (() -> Unit)? = null) {
        if (!isSample(preset)) return
        val set = preset - FIRST_SAMPLE
        if (Engine.samplesReady(set)) { done?.invoke(); return }
        synchronized(loading) { if (!loading.add(set)) return }
        val app = c.applicationContext
        Thread {
            runCatching {
                val bytes = app.assets.open("samples/${sampleFiles[set]}.rsc").use { it.readBytes() }
                Engine.loadSamples(set, bytes)
            }
            synchronized(loading) { loading.remove(set) }
            done?.invoke()
        }.start()
    }

    fun adsr(p: SharedPreferences, preset: Int, which: Int): Float =
        p.getFloat("adsr_${preset}_$which", Engine.presetDefault(preset, which))

    fun selectPreset(p: SharedPreferences, preset: Int) {
        Engine.param(Engine.PRESET, preset.toFloat())
        if (preset != SF2) for (w in 0..3) Engine.param(Engine.ATTACK + w, adsr(p, preset, w))
    }

    fun primeMask(p: SharedPreferences) = p.getInt("primesMask", 0b111)
    fun primeMax(p: SharedPreferences) = p.getInt("primesMax", 32)
    fun primeSlope(p: SharedPreferences) = p.getFloat("primesSlope", 1f)
    fun applyPrimes(p: SharedPreferences) = Engine.buildPrimes(primeMask(p), primeMax(p), primeSlope(p))

    // Armónicos cuyos factores primos están todos en la selección
    fun harmonics(mask: Int, max: Int): List<Int> = (1..max).filter { n ->
        var m = n
        primes.forEachIndexed { k, pr -> if (mask and (1 shl k) != 0) while (m % pr == 0) m /= pr }
        m == 1
    }

    fun applyEffects(p: SharedPreferences) {
        Engine.param(Engine.REVERB_MIX, if (p.getBoolean("revOn", false)) p.getFloat("revMix", .25f) else 0f)
        Engine.param(Engine.REVERB_SIZE, p.getFloat("revSize", .5f))
        Engine.param(Engine.DELAY_MIX, if (p.getBoolean("dlyOn", false)) p.getFloat("dlyMix", .3f) else 0f)
        Engine.param(Engine.DELAY_TIME, p.getFloat("dlyTime", .35f))
        Engine.param(Engine.DELAY_FB, p.getFloat("dlyFb", .35f))
    }

    fun currentPreset(p: SharedPreferences): Int {
        // los índices cambiaron en esta versión: un valor guardado de la anterior vuelve al Rhodes
        if (p.getInt("catalog", 1) < 2) p.edit().putInt("preset", 0).putInt("catalog", 2).remove("favs").apply()
        return p.getInt("preset", 0).coerceIn(0, COUNT - 1)
    }

    fun applyAll(c: Context) {
        val p = prefs(c)
        Engine.setBufferMode(p.getInt("buffer", 0))
        Engine.param(Engine.VOLUME, p.getFloat("volume", .8f))
        Engine.param(Engine.BEND_NOTE, p.getInt("bendNote", 48).toFloat())
        Engine.param(Engine.BEND_GLOBAL, p.getInt("bendGlobal", 2).toFloat())
        Engine.param(Engine.MOD_DEST, p.getInt("modDest", 0).toFloat())
        Engine.param(Engine.LFO_RATE, p.getFloat("lfoRate", 5.6f))
        Engine.param(Engine.VIB_DEPTH, p.getFloat("vibDepth", 35f))
        applyEffects(p)
        applyPrimes(p)
        val cur = currentPreset(p)
        selectPreset(p, cur)
        ensureSamples(c, cur)
    }

    // Abre un SoundFont y elige un preset. Bloqueante: llamar desde un hilo secundario.
    fun loadSf2(c: Context, uri: Uri, index: Int): Boolean {
        Status.sf2Busy = true
        return try {
            val pfd = c.contentResolver.openFileDescriptor(uri, "r") ?: return false
            val n = Engine.sf2Open(pfd.detachFd())
            if (n <= 0) return false
            Status.sf2Names = List(n) { Engine.sf2Name(it) }
            Engine.sf2Select(index.coerceIn(0, n - 1))
        } catch (e: Exception) {
            false
        } finally {
            Status.sf2Busy = false
        }
    }

    fun displayName(c: Context, uri: Uri): String = runCatching {
        c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    }.getOrNull() ?: "SoundFont"
}
