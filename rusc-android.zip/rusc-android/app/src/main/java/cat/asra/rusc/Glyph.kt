package cat.asra.rusc

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.min

// Botón redondo con icono dibujado (sin texto)
class Glyph(context: Context, private val kind: Int, label: String) : View(context) {
    companion object { const val PLAY = 0; const val STOP = 1; const val POWER = 2; const val RESET = 3 }

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Magic.gold }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Magic.goldLight }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Magic.goldLight; strokeCap = Paint.Cap.ROUND
    }
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Magic.surface }
    private val path = Path()
    private val arc = RectF()

    init {
        contentDescription = label
        isClickable = true
        isFocusable = true
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val s = min(w, h).toFloat()
        val cx = w / 2f
        val cy = h / 2f
        ring.strokeWidth = s * .045f
        stroke.strokeWidth = s * .075f
        path.reset()
        val u = s * .16f
        when (kind) {
            PLAY -> { path.moveTo(cx - u * .8f, cy - u * 1.1f); path.lineTo(cx + u * 1.2f, cy); path.lineTo(cx - u * .8f, cy + u * 1.1f); path.close() }
            STOP -> path.addRoundRect(cx - u, cy - u, cx + u, cy + u, u * .2f, u * .2f, Path.Direction.CW)
            POWER -> { arc.set(cx - u * 1.2f, cy - u * 1.1f, cx + u * 1.2f, cy + u * 1.3f) }
            RESET -> {
                val rr = u * 1.15f
                arc.set(cx - rr, cy - rr, cx + rr, cy + rr)
                // punta de flecha al final del arco, en la dirección de giro (horario)
                val th = Math.toRadians(310.0)
                val px = cx + rr * Math.cos(th).toFloat()
                val py = cy + rr * Math.sin(th).toFloat()
                val dx = -Math.sin(th).toFloat(); val dy = Math.cos(th).toFloat()
                val nx = Math.cos(th).toFloat(); val ny = Math.sin(th).toFloat()
                val a = u * .85f
                path.moveTo(px + dx * a, py + dy * a)
                path.lineTo(px - dx * a * .35f + nx * a * .75f, py - dy * a * .35f + ny * a * .75f)
                path.lineTo(px - dx * a * .35f - nx * a * .75f, py - dy * a * .35f - ny * a * .75f)
                path.close()
            }
        }
    }

    override fun onDraw(c: Canvas) {
        val s = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val alpha = if (isPressed) 150 else 255
        fill.alpha = alpha; stroke.alpha = alpha
        c.drawCircle(cx, cy, s / 2 - ring.strokeWidth, bgPaint)
        c.drawCircle(cx, cy, s / 2 - ring.strokeWidth, ring)
        when (kind) {
            PLAY, STOP -> c.drawPath(path, fill)
            POWER -> { c.drawArc(arc, -60f, 300f, false, stroke); c.drawLine(cx, cy - s * .24f, cx, cy - s * .02f, stroke) }
            RESET -> { c.drawArc(arc, 20f, 280f, false, stroke); c.drawPath(path, fill) }
        }
    }

    override fun drawableStateChanged() {
        super.drawableStateChanged()
        invalidate()
    }
}

// Flecha de sección plegable
class Chevron(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Magic.gold; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    var open = false
        set(v) { field = v; animate().rotation(if (v) 180f else 0f).setDuration(160).start() }

    init { importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val s = min(w, h).toFloat()
        p.strokeWidth = s * .1f
        path.reset()
        path.moveTo(w / 2f - s * .25f, h / 2f - s * .1f)
        path.lineTo(w / 2f, h / 2f + s * .15f)
        path.lineTo(w / 2f + s * .25f, h / 2f - s * .1f)
    }

    override fun onDraw(c: Canvas) = c.drawPath(path, p)
}
