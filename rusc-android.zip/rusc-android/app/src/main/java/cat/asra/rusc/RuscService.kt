package cat.asra.rusc

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

// Servicio en primer plano: mantiene el audio y el MIDI con la app minimizada o la pantalla apagada
class RuscService : Service() {

    companion object {
        private const val ACTION_STOP = "cat.asra.rusc.STOP"
        private const val CHANNEL = "rusc"
        private const val NOTIF = 1

        fun start(c: Context) = c.startForegroundService(Intent(c, RuscService::class.java))

        fun stop(c: Context) {
            if (Status.running) c.startService(Intent(c, RuscService::class.java).setAction(ACTION_STOP))
        }
    }

    private var midi: MidiInput? = null
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        goForeground()
        Status.running = true
        Status.audioOk = Engine.start()
        Sound.applyAll(this)
        midi = MidiInput(this) { text -> Status.midi = text }.also { it.start() }
        wake = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "rusc:audio")
            .apply { setReferenceCounted(false); acquire() }
        Thread { loadSamples() }.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        midi?.close()
        Engine.stop()
        wake?.let { if (it.isHeld) it.release() }
        Status.running = false
        Status.onStopped?.invoke()
        super.onDestroy()
    }

    // El SoundFont que se estaba usando se reabre al arrancar; los samples se cargan bajo demanda
    private fun loadSamples() {
        val p = Sound.prefs(this)
        p.getString("sfUri", null)?.let { u ->
            if (Status.sf2Names.isEmpty()) Sound.loadSf2(this, android.net.Uri.parse(u), p.getInt("sfPreset", 0))
        }
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Rusc sonando", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Aviso mientras el sinte está activo"
                setShowBadge(false)
            }
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, RuscService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val icon = Icon.createWithResource(this, R.drawable.ic_launcher_monochrome)
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(icon)
            .setContentTitle("Rusc está activo")
            .setContentText("Sigue sonando con la pantalla apagada.")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(icon, "Apagar", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF, n)
        }
    }
}
