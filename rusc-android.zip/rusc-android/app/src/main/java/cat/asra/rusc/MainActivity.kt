package cat.asra.rusc

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import java.util.Locale
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private val ui = Handler(Looper.getMainLooper())
    private val held = FloatArray(FortuneWheel.Synth_MAX)
    private val heldKeys = IntArray(FortuneWheel.Synth_MAX)
    private var tick = 0
    private var lastRpn = -1

    private lateinit var wheel: FortuneWheel
    private lateinit var status: TextView
    private val tabs = mutableListOf<TextView>()
    private val pages = mutableListOf<View>()
    private val tiles = HashMap<Int, TextView>()      // mosaicos visibles por índice de timbre
    private lateinit var tilesBox: LinearLayout
    private val primeChips = mutableListOf<TextView>()
    private lateinit var harmList: TextView
    private lateinit var sfTile: TextView
    private lateinit var sfFile: TextView
    private lateinit var sfSpinner: Spinner
    private var sfShown = -1
    private lateinit var envSection: View
    private val adsrRows = mutableListOf<SliderRow>()
    private lateinit var wheels: TextView
    private lateinit var bendNote: TextView
    private lateinit var diag: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density
    private fun fmt(s: String, vararg a: Any) = String.format(Locale.US, s, *a)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Magic.bg
        window.navigationBarColor = Magic.bg
        runCatching { Magic.font = resources.getFont(R.font.macondo) }
        prefs = Sound.prefs(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        RuscService.start(this)
        setContentView(build())
        Status.onStopped = { ui.post { finish() } }
        ui.post(poll)
    }

    override fun onResume() {
        super.onResume()
        if (!Status.running) RuscService.start(this)
    }

    // ---------- pedal USB que escribe la letra «b» ----------
    // Pisado: sustain. Mantenido más de 1,5 s: arpegio ascendente sobre los timbres ambient.
    // Al soltar se esperan 150 ms por si el pedal repite la tecla soltándola entre medias.
    private var pedalDown = false
    private val pedalArp = Runnable { Engine.param(Engine.ARP, 1f) }
    private val pedalUp = Runnable { releasePedal() }

    private fun releasePedal() {
        ui.removeCallbacks(pedalArp)
        ui.removeCallbacks(pedalUp)
        if (!pedalDown) return
        pedalDown = false
        Engine.param(Engine.ARP, 0f)
        Engine.midi(0xB0, 64, 0)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode != KeyEvent.KEYCODE_B) return super.dispatchKeyEvent(event)
        if (event.action == KeyEvent.ACTION_DOWN) {
            ui.removeCallbacks(pedalUp)
            if (!pedalDown) {
                pedalDown = true
                Engine.midi(0xB0, 64, 127)
                ui.postDelayed(pedalArp, 1500)
            }
        } else if (event.action == KeyEvent.ACTION_UP) {
            ui.postDelayed(pedalUp, 150)
        }
        return true
    }

    override fun onPause() {
        releasePedal()   // sin la app delante no llegaría el aviso de que se ha soltado
        super.onPause()
    }

    override fun onDestroy() {
        releasePedal()
        ui.removeCallbacksAndMessages(null)
        Status.onStopped = null
        super.onDestroy()
    }

    // ---------- sondeo: rueda a 25 fps, el resto dos veces por segundo ----------
    private val poll = object : Runnable {
        override fun run() {
            wheel.update(held, heldKeys, Engine.heldNotes(held, heldKeys))
            if (tick % 3 == 0 && wheels.isShown) {
                wheels.text = fmt("Pitch %+.2f   ·   Mod %d%%", Engine.wheelCents() / 100f, (Engine.modWheel() * 100).roundToInt())
            }
            if (padsLayer.visibility == View.VISIBLE) {
                val mask = Engine.padMask()
                padViews.forEachIndexed { i, v -> v.setPlaying(mask and (1 shl i) != 0, Engine.padProgress(i)) }
                if (tick % 6 == 0) refreshPads()
            }
            if (tick % 12 == 0) slowUpdate()
            tick++
            ui.postDelayed(this, 40)
        }
    }

    private fun slowUpdate() {
        val lat = Engine.latencyMs()
        status.text = listOfNotNull(Status.midi.ifEmpty { null },
            if (Status.audioOk && lat > 0) fmt("%.0f ms", lat) else null).joinToString("   ·   ")
        for ((i, t) in tiles) if (Sound.isSample(i)) t.alpha = if (Engine.samplesReady(i - Sound.FIRST_SAMPLE)) 1f else .45f
        if (Status.sf2Names.size != sfShown) refreshSf2()
        Engine.sf2Collect()
        if (diag.isShown) {
            val sr = Engine.sampleRate()
            val buf = Engine.bufferFrames()
            diag.text = fmt("%d muestras · %.1f ms · %s · %d cortes · %d voces",
                buf, if (sr > 0) buf * 1000f / sr else 0f,
                if (Engine.exclusive()) "exclusivo" else "compartido", Engine.xruns(), Engine.voices())
        }
        val r = Engine.rpnRange()
        if (r > 0 && r != lastRpn) { lastRpn = r; bendNote.text = resolution(r, true) }
    }

    private fun resolution(range: Int, fromController: Boolean) =
        fmt("%s%.2f¢ de resolución", if (fromController) "HexBoard ±$range · " else "", range * 200f / 16384f)

    // ---------- piezas ----------
    private fun box(fill: Int, stroke: Int, radius: Float = dpf(12f)) = GradientDrawable().apply {
        cornerRadius = radius
        setColor(fill)
        setStroke(dp(1).coerceAtLeast(2), stroke)
    }

    private fun text(s: CharSequence, size: Float, color: Int = Magic.ink) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        typeface = Magic.font
        includeFontPadding = false
    }

    private fun tile(label: String, onClick: () -> Unit) = text(label, 17f).apply {
        gravity = Gravity.CENTER
        minHeight = dp(52)
        setPadding(dp(6), dp(8), dp(6), dp(8))
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }

    private fun gridParams() = GridLayout.LayoutParams(
        GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f)
    ).apply { width = 0; setMargins(dp(4), dp(4), dp(4), dp(4)) }

    inner class SliderRow(val view: View, private val bar: SeekBar, private val value: TextView,
                          private val toPos: (Float) -> Int, private val show: (Float) -> String) {
        fun set(v: Float) { bar.progress = toPos(v); value.text = show(v) }
    }

    private fun slider(name: String, min: Float, max: Float, start: Float, log: Boolean = false,
                       show: (Float) -> String, onChange: (Float) -> Unit): SliderRow {
        val toVal = { pos: Int -> val t = pos / 1000f; if (log) exp(ln(min) + (ln(max) - ln(min)) * t) else min + (max - min) * t }
        val toPos = { v: Float ->
            val c = v.coerceIn(min, max)
            ((if (log) (ln(c) - ln(min)) / (ln(max) - ln(min)) else (c - min) / (max - min)) * 1000).roundToInt()
        }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(2), 0, dp(2)) }
        row.addView(text(name, 16f), LinearLayout.LayoutParams(dp(92), WRAP_CONTENT))
        val value = text(show(start), 14f, Magic.muted).apply { gravity = Gravity.END }
        val bar = SeekBar(this).apply {
            this.max = 1000
            progress = toPos(start)
            progressTintList = ColorStateList.valueOf(Magic.gold)
            thumbTintList = ColorStateList.valueOf(Magic.goldLight)
            progressBackgroundTintList = ColorStateList.valueOf(Magic.line)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    val v = toVal(p); value.text = show(v); onChange(v)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        row.addView(bar, LinearLayout.LayoutParams(0, dp(44), 1f))
        row.addView(value, LinearLayout.LayoutParams(dp(64), WRAP_CONTENT))
        return SliderRow(row, bar, value, toPos, show)
    }

    // Adaptador de desplegables con la tipografía de la app
    private inner class FontAdapter(items: List<String>) : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
        private fun style(v: View, drop: Boolean) = (v as TextView).apply {
            typeface = Magic.font
            textSize = 16f
            setTextColor(Magic.ink)
            setPadding(dp(12), dp(if (drop) 12 else 6), dp(12), dp(if (drop) 12 else 6))
        }
        override fun getView(p: Int, c: View?, parent: ViewGroup) = style(super.getView(p, c, parent), false)
        override fun getDropDownView(p: Int, c: View?, parent: ViewGroup) = style(super.getDropDownView(p, c, parent), true)
    }

    private fun spinner(items: List<String>, selected: Int, onPick: (Int) -> Unit) = Spinner(this).apply {
        adapter = FontAdapter(items)
        setPopupBackgroundDrawable(ColorDrawable(Magic.surface))
        background = box(Magic.surface, Magic.line)
        if (items.isNotEmpty()) setSelection(selected.coerceIn(0, items.size - 1), false)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) = onPick(pos)
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun labeled(name: String, v: View): View = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(4), 0, dp(4))
        addView(text(name, 16f), LinearLayout.LayoutParams(dp(92), WRAP_CONTENT))
        addView(v, LinearLayout.LayoutParams(0, dp(44), 1f))
    }

    private fun toggle(name: String, on: Boolean, onToggle: (Boolean) -> Unit) = Switch(this).apply {
        text = name
        textSize = 17f
        typeface = Magic.font
        setTextColor(Magic.ink)
        isChecked = on
        thumbTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(Magic.goldLight, Magic.muted))
        trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(Magic.gold, Magic.line))
        minHeight = dp(48)
        setOnCheckedChangeListener { _, c -> onToggle(c) }
    }

    // Sección plegable: título + flecha; se recuerda abierta o cerrada
    private fun section(root: LinearLayout, key: String, title: String, fill: (LinearLayout) -> Unit): View {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(4), dp(14), dp(14))
        }
        fill(body)
        val chevron = Chevron(this)
        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), 0, dp(10), 0)
            minimumHeight = dp(56)
            isClickable = true
            isFocusable = true
            addView(text(title, 20f, Magic.goldLight), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(chevron, LinearLayout.LayoutParams(dp(28), dp(28)))
        }
        val open = prefs.getBoolean("open_$key", false)
        body.visibility = if (open) View.VISIBLE else View.GONE
        chevron.rotation = if (open) 180f else 0f
        head.setOnClickListener {
            val now = body.visibility != View.VISIBLE
            body.visibility = if (now) View.VISIBLE else View.GONE
            chevron.open = now
            prefs.edit().putBoolean("open_$key", now).apply()
        }
        wrap.background = box(Magic.surface, Magic.line, dpf(16f))
        wrap.addView(head)
        wrap.addView(body)
        root.addView(wrap, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(10) })
        return wrap
    }

    private fun ms(v: Float) = if (v < 1f) fmt("%.0f ms", v * 1000) else fmt("%.1f s", v)
    private fun pct(v: Float) = fmt("%.0f%%", v * 100)

    // ---------- construcción ----------
    private fun build(): View {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(20))
        }

        page.addView(Retablo(this))

        // estado + acciones
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(4), 0, dp(8)) }
        status = text("", 14f, Magic.muted)
        top.addView(status, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        val actions = listOf<Triple<Int, String, () -> Unit>>(
            Triple(Glyph.PADS, "Pads") { showPads(true) },
            Triple(Glyph.PLAY, "Probar sonido") { playTest() },
            Triple(Glyph.STOP, "Silenciar todo") { Engine.param(Engine.PANIC, 0f) },
            Triple(Glyph.POWER, "Apagar Rusc") { RuscService.stop(this); finish() })
        for ((kind, label, action) in actions) {
            top.addView(Glyph(this, kind, label).apply { setOnClickListener { action() } },
                LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(8) })
        }
        page.addView(top)

        // pestañas de timbre: favoritos, sintes, primos, samples, SoundFont, laboratorio (timbres nuevos)
        val tabRow = LinearLayout(this)
        listOf("♥", "Sinte", "Primos", "Samples", "SF2", "Lab").forEachIndexed { i, name ->
            val t = text(name, 18f).apply {
                gravity = Gravity.CENTER
                minHeight = dp(48)
                isClickable = true
                maxLines = 1
                contentDescription = when (i) { 0 -> "Favoritos"; 5 -> "Laboratorio"; else -> name }
                setOnClickListener { showTab(i) }
            }
            tabs.add(t)
            tabRow.addView(t, LinearLayout.LayoutParams(0, WRAP_CONTENT, when (i) { 0 -> .6f; 4, 5 -> .75f; else -> 1f }))
        }
        page.addView(tabRow)

        val pagesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, 0) }
        tilesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pages.add(tilesBox)          // ♥, Sinte, Samples y Lab comparten el mosaico (se rehace al cambiar)
        pages.add(primesPage())
        pages.add(sf2Page())
        pages.forEach { pagesBox.addView(it) }
        page.addView(pagesBox)

        // ajustes plegables
        section(page, "mix", "Mezcla") { b ->
            val choices = Sound.layerChoices
            b.addView(labeled("Con", spinner(listOf("Ninguno") + choices.map { Sound.name(it) }, choices.indexOf(Sound.layer(prefs)) + 1) { pos ->
                val l = if (pos == 0) -1 else choices[pos - 1]
                if (l != Sound.layer(prefs)) { prefs.edit().putInt("layer", l).apply(); Sound.applyLayer(this) }
            }))
            b.addView(slider("Nivel", 0f, 1.5f, prefs.getFloat("layerMix", .7f), show = ::pct) {
                prefs.edit().putFloat("layerMix", it).apply(); Engine.param(Engine.LAYER_MIX, it)
            }.view)
        }

        envSection = section(page, "env", "Envolvente") { b ->
            val cur = prefs.getInt("preset", 0)
            val ranges = listOf(Triple(.001f, 4f, true), Triple(.01f, 20f, true), Triple(0f, 1f, false), Triple(.005f, 8f, true))
            listOf("Ataque", "Caída", "Sostén", "Final").forEachIndexed { w, n ->
                val (mn, mx, lg) = ranges[w]
                val row = slider(n, mn, mx, Sound.adsr(prefs, cur, w), lg, show = { v -> if (w == 2) pct(v) else ms(v) }) { v ->
                    val p = prefs.getInt("preset", 0)
                    prefs.edit().putFloat("adsr_${p}_$w", v).apply()
                    Engine.param(Engine.ATTACK + w, v)
                }
                adsrRows.add(row)
                b.addView(row.view)
            }
            b.addView(Glyph(this, Glyph.RESET, "Restablecer envolvente").apply {
                setOnClickListener {
                    val p = prefs.getInt("preset", 0)
                    prefs.edit().apply { for (w in 0..3) remove("adsr_${p}_$w") }.apply()
                    Sound.selectPreset(prefs, p)
                    refreshAdsr(p)
                }
            }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { gravity = Gravity.END; topMargin = dp(4) })
        }

        section(page, "fx", "Efectos") { b ->
            b.addView(toggle("Reverb", prefs.getBoolean("revOn", false)) { prefs.edit().putBoolean("revOn", it).apply(); Sound.applyEffects(prefs) })
            b.addView(slider("Mezcla", 0f, .8f, prefs.getFloat("revMix", .25f), show = ::pct) { prefs.edit().putFloat("revMix", it).apply(); Sound.applyEffects(prefs) }.view)
            b.addView(slider("Tamaño", 0f, 1f, prefs.getFloat("revSize", .5f), show = ::pct) { prefs.edit().putFloat("revSize", it).apply(); Engine.param(Engine.REVERB_SIZE, it) }.view)
            b.addView(toggle("Delay", prefs.getBoolean("dlyOn", false)) { prefs.edit().putBoolean("dlyOn", it).apply(); Sound.applyEffects(prefs) },
                LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(10) })
            b.addView(slider("Mezcla", 0f, .8f, prefs.getFloat("dlyMix", .3f), show = ::pct) { prefs.edit().putFloat("dlyMix", it).apply(); Sound.applyEffects(prefs) }.view)
            b.addView(slider("Tiempo", .02f, 2f, prefs.getFloat("dlyTime", .35f), true, show = ::ms) { prefs.edit().putFloat("dlyTime", it).apply(); Engine.param(Engine.DELAY_TIME, it) }.view)
            b.addView(slider("Eco", 0f, .9f, prefs.getFloat("dlyFb", .35f), show = ::pct) { prefs.edit().putFloat("dlyFb", it).apply(); Engine.param(Engine.DELAY_FB, it) }.view)
        }

        section(page, "wheels", "Ruedas") { b ->
            wheels = text("", 14f, Magic.muted).apply { setPadding(0, 0, 0, dp(6)) }
            b.addView(wheels)
            b.addView(labeled("Mod", spinner(Sound.modTargets, prefs.getInt("modDest", 0)) {
                prefs.edit().putInt("modDest", it).apply(); Engine.param(Engine.MOD_DEST, it.toFloat())
            }))
            b.addView(slider("LFO", .5f, 12f, prefs.getFloat("lfoRate", 5.6f), true, show = { fmt("%.1f Hz", it) }) {
                prefs.edit().putFloat("lfoRate", it).apply(); Engine.param(Engine.LFO_RATE, it)
            }.view)
            b.addView(slider("Vibrato", 5f, 100f, prefs.getFloat("vibDepth", 35f), show = { fmt("%.0f¢", it) }) {
                prefs.edit().putFloat("vibDepth", it).apply(); Engine.param(Engine.VIB_DEPTH, it)
            }.view)
            b.addView(labeled("Pitch", spinner(Sound.wheelRanges.map { "±$it" },
                Sound.wheelRanges.indexOf(prefs.getInt("bendGlobal", 2)).coerceAtLeast(0)) {
                prefs.edit().putInt("bendGlobal", Sound.wheelRanges[it]).apply()
                Engine.param(Engine.BEND_GLOBAL, Sound.wheelRanges[it].toFloat())
            }))
        }

        section(page, "tuning", "Afinación") { b ->
            val saved = prefs.getInt("bendNote", 48)
            bendNote = text(resolution(saved, false), 14f, Magic.muted).apply { setPadding(0, dp(4), 0, 0) }
            b.addView(labeled("Bend", spinner(Sound.noteRanges.map { "±$it" }, Sound.noteRanges.indexOf(saved).coerceAtLeast(0)) {
                prefs.edit().putInt("bendNote", Sound.noteRanges[it]).apply()
                Engine.param(Engine.BEND_NOTE, Sound.noteRanges[it].toFloat())
                if (lastRpn < 0) bendNote.text = resolution(Sound.noteRanges[it], false)
            }))
            b.addView(bendNote)
        }

        section(page, "out", "Salida") { b ->
            b.addView(slider("Volumen", 0f, 1f, prefs.getFloat("volume", .8f), show = ::pct) {
                prefs.edit().putFloat("volume", it).apply(); Engine.param(Engine.VOLUME, it)
            }.view)
            b.addView(labeled("Buffer", spinner(Sound.bufferModes, prefs.getInt("buffer", 0)) {
                prefs.edit().putInt("buffer", it).apply(); Engine.setBufferMode(it)
            }))
            diag = text("", 13f, Magic.muted).apply { setPadding(0, dp(6), 0, 0) }
            b.addView(diag)
        }

        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            isVerticalFadingEdgeEnabled = true
            setFadingEdgeLength(dp(28))
            addView(page, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }

        // la rueda, fija abajo del todo
        wheel = FortuneWheel(this)
        val dm = resources.displayMetrics
        val wheelH = min(min(dm.heightPixels * .31f, dm.widthPixels * .72f), dpf(300f)).roundToInt()

        val cur = Sound.currentPreset(prefs)
        pageOf(cur, Sound.synthPages).takeIf { it >= 0 }?.let { prefs.edit().putInt("page_1", it).apply() }
        pageOf(cur, Sound.samplePages).takeIf { it >= 0 }?.let { prefs.edit().putInt("page_3", it).apply() }
        pageOf(cur, Sound.labPages).takeIf { it >= 0 }?.let { prefs.edit().putInt("page_5", it).apply() }
        showTab(tabOf(cur))
        paintTiles(cur)
        refreshPrimes(false)

        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Magic.bg)
            addView(scroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
            addView(wheel, LinearLayout.LayoutParams(MATCH_PARENT, wheelH))
        }
        // la pantalla de siempre y, encima, la de pads (oculta hasta que se abre)
        val root = FrameLayout(this)
        root.addView(main, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.addView(buildPads(), FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        if (prefs.getBoolean("padsOpen", false)) {
            showPads(true)
            if (prefs.getBoolean("padsLocked", false)) setPadLocked(true)
        }
        return root
    }

    // ---------- modo pads: diez pads heptagonales a pantalla completa ----------
    private lateinit var padsLayer: LinearLayout
    private val padViews = mutableListOf<PadView>()
    private lateinit var padSheet: LinearLayout
    private lateinit var padTitle: TextView
    private lateinit var padsTitle: TextView
    private lateinit var padEditBtn: Glyph
    private lateinit var padLockBtn: Glyph
    private lateinit var padCloseBtn: Glyph
    private lateinit var padLoop: Switch
    private val padRows = mutableListOf<SliderRow>()
    private var padEdit = false
    private var padLocked = false
    private var padSel = -1
    private var padPick = -1

    private fun buildPads(): View {
        padsLayer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Magic.bg)
            isClickable = true          // nada de lo que hay debajo recibe toques
            visibility = View.GONE
            setPadding(dp(8), dp(4), dp(8), dp(8))
        }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), 0, 0, dp(4)) }
        padsTitle = text("Pads", 20f, Magic.goldLight)
        bar.addView(padsTitle, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        padEditBtn = Glyph(this, Glyph.EDIT, "Editar pads").apply { setOnClickListener { setPadEdit(!padEdit) } }
        padLockBtn = Glyph(this, Glyph.LOCK, "Bloquear la pantalla de pads").apply {
            setOnClickListener { if (!padLocked) setPadLocked(true) else padsTitle.text = "Mantén pulsado el candado" }
            setOnLongClickListener {
                if (padLocked) { it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); setPadLocked(false) }
                true
            }
        }
        padCloseBtn = Glyph(this, Glyph.CLOSE, "Cerrar pads").apply { setOnClickListener { showPads(false) } }
        for (g in listOf(padEditBtn, padLockBtn, padCloseBtn)) {
            bar.addView(g, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(8) })
        }
        padsLayer.addView(bar)

        for (r in 0 until Pads.N / 2) {
            val row = LinearLayout(this)
            for (k in 0 until 2) {
                val i = r * 2 + k
                val pv = PadView(this, i) { pressPad(i) }
                padViews.add(pv)
                row.addView(pv, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f))
            }
            padsLayer.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        }

        // ficha del pad elegido (solo en modo edición)
        padSheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(Magic.surface, Magic.line, dpf(16f))
            setPadding(dp(14), dp(10), dp(14), dp(10))
            visibility = View.GONE
        }
        padTitle = text("", 18f, Magic.goldLight).apply { maxLines = 1 }
        padSheet.addView(padTitle)
        val buttons = LinearLayout(this)
        val actions = listOf<Pair<String, () -> Unit>>(
            "Cargar" to { pickPad() },
            "Probar" to { if (padSel >= 0) Engine.pad(padSel, Pads.TRIGGER, 1f) },
            "Vaciar" to { clearPad() })
        for ((label, action) in actions) {
            buttons.addView(tile(label) { action() }.apply { background = box(Magic.surface, Magic.gold) },
                LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { setMargins(dp(4), dp(6), dp(4), dp(4)) })
        }
        padSheet.addView(buttons)
        fun padSlider(name: String, key: String, what: Int, min: Float, max: Float, log: Boolean, show: (Float) -> String) {
            val row = slider(name, min, max, min, log, show) { v ->
                if (padSel >= 0) { prefs.edit().putFloat("pad_${padSel}_$key", v).apply(); Engine.pad(padSel, what, v) }
            }
            padRows.add(row)
            padSheet.addView(row.view)
        }
        padSlider("Volumen", "vol", Pads.VOLUME, 0f, 1.5f, false, ::pct)
        padSlider("Catedral", "rev", Pads.REVERB, 0f, 1f, false, ::pct)
        padSlider("Delay", "dly", Pads.DELAY, 0f, 1f, false, ::pct)
        padSlider("Graves", "cut", Pads.LOWCUT, 20f, 1000f, true) { if (it < 25f) "enteros" else fmt("%.0f Hz", it) }
        padLoop = toggle("Bucle", false) { on ->
            if (padSel >= 0) { prefs.edit().putBoolean("pad_${padSel}_loop", on).apply(); Engine.pad(padSel, Pads.LOOP, if (on) 1f else 0f) }
        }
        padSheet.addView(padLoop)
        padsLayer.addView(padSheet, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(6) })
        refreshPads()
        return padsLayer
    }

    private fun refreshPads() {
        padViews.forEachIndexed { i, v -> v.show(Pads.name(prefs, i), Pads.state.get(i), padEdit && i == padSel) }
    }

    // Tocar un pad: lo lanza (o lo apaga si está sonando). En modo edición, lo elige para ajustarlo.
    private fun pressPad(i: Int) {
        if (padEdit && !padLocked) selectPad(i) else Engine.pad(i, Pads.TRIGGER, 1f)
    }

    private fun selectPad(i: Int) {
        padSel = -1                      // mientras se rellenan los controles no se guarda nada
        padRows[0].set(Pads.volume(prefs, i))
        padRows[1].set(Pads.reverb(prefs, i))
        padRows[2].set(Pads.delay(prefs, i))
        padRows[3].set(Pads.lowCut(prefs, i))
        padLoop.isChecked = Pads.loop(prefs, i)
        padSel = i
        val name = Pads.name(prefs, i)
        padTitle.text = if (name.isEmpty()) "Pad ${i + 1}" else "Pad ${i + 1} · $name"
        padSheet.visibility = View.VISIBLE
        refreshPads()
    }

    private fun setPadEdit(on: Boolean) {
        padEdit = on
        padEditBtn.active = on
        if (on) selectPad(if (padSel >= 0) padSel else 0) else padSheet.visibility = View.GONE
        refreshPads()
    }

    // Bloqueo para directo: sin edición, sin salir y con las barras del sistema escondidas.
    // Se quita manteniendo pulsado el candado.
    private fun setPadLocked(on: Boolean) {
        padLocked = on
        if (on) setPadEdit(false)
        padLockBtn.active = on
        padEditBtn.visibility = if (on) View.GONE else View.VISIBLE
        padCloseBtn.visibility = if (on) View.GONE else View.VISIBLE
        padsTitle.text = if (on) "Pads · bloqueado" else "Pads"
        prefs.edit().putBoolean("padsLocked", on).apply()
        immersive(on)
    }

    @Suppress("DEPRECATION")
    private fun immersive(on: Boolean) {
        window.decorView.systemUiVisibility = if (on) (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE) else 0
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && padLocked) immersive(true)
    }

    private fun showPads(on: Boolean) {
        if (!on) { if (padLocked) setPadLocked(false); setPadEdit(false) }
        padsLayer.visibility = if (on) View.VISIBLE else View.GONE
        prefs.edit().putBoolean("padsOpen", on).apply()
    }

    @Deprecated("API clásica de actividad; la app no usa AndroidX")
    override fun onBackPressed() {
        if (padsLayer.visibility == View.VISIBLE) {
            if (!padLocked) showPads(false)
            return
        }
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }

    private fun pickPad() {
        if (padSel < 0) return
        padPick = padSel
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
        }
        runCatching { startActivityForResult(i, 8) }
    }

    private fun loadPad(i: Int, uri: Uri) {
        if (i < 0 || i >= Pads.N) return
        runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        prefs.edit().putString("pad_${i}_uri", uri.toString()).putString("pad_${i}_name", Pads.fileName(this, uri)).apply()
        if (padSel == i) selectPad(i)
        Thread {
            val ok = Pads.load(this, i, uri)
            ui.post {
                if (!ok) {
                    prefs.edit().remove("pad_${i}_uri").remove("pad_${i}_name").apply()
                    if (padSel == i) padTitle.text = "Pad ${i + 1} · no se pudo abrir"
                }
                refreshPads()
            }
        }.start()
    }

    private fun clearPad() {
        val i = padSel
        if (i < 0) return
        Pads.clear(i)
        prefs.edit().remove("pad_${i}_uri").remove("pad_${i}_name").apply()
        selectPad(i)
    }

    // Mosaico de timbres: pulsar elige, mantener pulsado guarda en favoritos
    private fun tileFor(i: Int): TextView {
        val t = tile(Sound.name(i)) { selectPreset(i) }
        t.setOnLongClickListener {
            val fav = Sound.toggleFavorite(prefs, i)
            it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            labelTile(t, i)
            if (!fav && currentTab == 0) showTab(0)
            true
        }
        labelTile(t, i)
        tiles[i] = t
        return t
    }

    private fun labelTile(t: TextView, i: Int) {
        val name = Sound.name(i)
        if (i in Sound.favorites(prefs)) {
            val sp = SpannableString("$name ♥")
            sp.setSpan(ForegroundColorSpan(Magic.heartLight), name.length + 1, name.length + 2, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            t.text = sp
        } else t.text = name
    }

    private fun grid(list: List<Int>): View {
        val g = GridLayout(this).apply { columnCount = 3 }
        for (i in list) g.addView(tileFor(i), gridParams())
        return g
    }

    private var currentTab = -1

    // Rehace el mosaico de la pestaña ♥, Sinte, Samples o Lab (como mucho 8-10 mosaicos: instantáneo)
    private fun fillTiles(tab: Int) {
        tilesBox.removeAllViews()
        tiles.keys.retainAll(setOf(Sound.PRIMES, Sound.SF2))
        when (tab) {
            0 -> {
                val f = Sound.favorites(prefs)
                if (f.isEmpty()) tilesBox.addView(text("Mantén pulsado un sonido para traerlo aquí", 15f, Magic.muted).apply {
                    gravity = Gravity.CENTER; setPadding(dp(12), dp(24), dp(12), dp(24))
                }) else tilesBox.addView(grid(f))
            }
            1, 3, 5 -> {
                val book = when (tab) { 1 -> Sound.synthPages; 3 -> Sound.samplePages; else -> Sound.labPages }
                val key = "page_$tab"
                val sel = prefs.getInt(key, 0).coerceIn(0, book.size - 1)
                val chips = LinearLayout(this)
                book.forEachIndexed { k, pg ->
                    chips.addView(text(pg.name, 14f, if (k == sel) Magic.goldLight else Magic.muted).apply {
                        gravity = Gravity.CENTER
                        minHeight = dp(40)
                        setPadding(dp(4), 0, dp(4), 0)
                        isClickable = true
                        background = if (k == sel) box(Magic.goldSoft, Magic.goldSoft, dpf(20f)) else null
                        setOnClickListener { prefs.edit().putInt(key, k).apply(); fillTiles(tab) }
                    }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
                }
                tilesBox.addView(chips)
                tilesBox.addView(grid(book[sel].presets))
            }
        }
        paintTiles(prefs.getInt("preset", 0))
    }

    private fun primesPage(): View {
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val t = tileFor(Sound.PRIMES)
        v.addView(t, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        val grid = GridLayout(this).apply { columnCount = 6 }
        Sound.primes.forEachIndexed { k, pr ->
            val chip = text(pr.toString(), 18f).apply {
                gravity = Gravity.CENTER
                minHeight = dp(48)
                isClickable = true
                contentDescription = "Primo $pr"
                setOnClickListener {
                    prefs.edit().putInt("primesMask", Sound.primeMask(prefs) xor (1 shl k)).apply()
                    refreshPrimes(true)
                    if (prefs.getInt("preset", 0) != Sound.PRIMES) selectPreset(Sound.PRIMES)
                }
            }
            primeChips.add(chip)
            grid.addView(chip, gridParams())
        }
        v.addView(grid)
        v.addView(slider("Máx", 4f, 128f, Sound.primeMax(prefs).toFloat(), true, show = { "${it.roundToInt()}" }) {
            prefs.edit().putInt("primesMax", it.roundToInt()).apply(); refreshPrimes(true)
        }.view)
        v.addView(slider("Caída", 0f, 2f, Sound.primeSlope(prefs), show = { fmt("1/n^%.1f", it) }) {
            prefs.edit().putFloat("primesSlope", it).apply(); refreshPrimes(true)
        }.view)
        harmList = text("", 14f, Magic.muted).apply { setPadding(dp(4), dp(2), dp(4), dp(4)) }
        v.addView(harmList)
        return v
    }

    private fun sf2Page(): View {
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(tile("Abrir .sf2") { pickSf2() }.apply { background = box(Magic.surface, Magic.gold) },
            LinearLayout.LayoutParams(dp(130), WRAP_CONTENT).apply { setMargins(dp(4), dp(4), dp(8), dp(4)) })
        sfFile = text(prefs.getString("sfFile", "") ?: "", 15f, Magic.muted).apply { maxLines = 2 }
        row.addView(sfFile, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        v.addView(row)
        sfTile = tile("") { selectPreset(Sound.SF2) }
        sfTile.setOnLongClickListener {
            Sound.toggleFavorite(prefs, Sound.SF2)
            it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            true
        }
        tiles[Sound.SF2] = sfTile
        v.addView(sfTile, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        sfSpinner = spinner(emptyList(), 0) { pos ->
            if (pos != prefs.getInt("sfPreset", 0)) {
                prefs.edit().putInt("sfPreset", pos).apply()
                Engine.sf2Select(pos)
                sfTile.text = Status.sf2Names.getOrElse(pos) { "" }
                selectPreset(Sound.SF2)
            }
        }
        v.addView(sfSpinner, LinearLayout.LayoutParams(MATCH_PARENT, dp(48)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        refreshSf2()
        return v
    }

    private fun refreshSf2() {
        val names = Status.sf2Names
        sfShown = names.size
        val sel = prefs.getInt("sfPreset", 0).coerceIn(0, maxOf(0, names.size - 1))
        sfSpinner.adapter = FontAdapter(names)
        if (names.isNotEmpty()) sfSpinner.setSelection(sel, false)
        sfSpinner.visibility = if (names.isEmpty()) View.GONE else View.VISIBLE
        sfTile.visibility = if (names.isEmpty()) View.GONE else View.VISIBLE
        sfTile.text = names.getOrElse(sel) { "" }
        sfFile.text = when {
            Status.sf2Busy -> "…"
            names.isEmpty() && prefs.getString("sfUri", null) != null -> "No se pudo abrir"
            else -> prefs.getString("sfFile", "") ?: ""
        }
    }

    private fun pickSf2() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        runCatching { startActivityForResult(i, 7) }
    }

    @Deprecated("API clásica de actividad; la app no usa AndroidX")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        if (requestCode == 8) { loadPad(padPick, uri); return }
        if (requestCode != 7) return
        runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        prefs.edit().putString("sfUri", uri.toString()).putInt("sfPreset", 0)
            .putString("sfFile", Sound.displayName(this, uri)).apply()
        sfFile.text = "…"
        Thread {
            val ok = Sound.loadSf2(this, uri, 0)
            ui.post {
                refreshSf2()
                if (ok) selectPreset(Sound.SF2) else sfFile.text = "No se pudo abrir"
            }
        }.start()
    }

    private fun tabOf(preset: Int) = when {
        preset < Sound.PRIMES -> 1
        preset == Sound.PRIMES -> 2
        preset < Sound.SF2 -> 3
        preset >= Sound.FIRST_LAB -> 5
        else -> 4
    }

    private fun pageOf(preset: Int, book: List<Sound.Page>) = book.indexOfFirst { preset in it.presets }

    private fun showTab(i: Int) {
        currentTab = i
        val cur = tabOf(prefs.getInt("preset", 0))
        tabs.forEachIndexed { k, t ->
            t.setTextColor(when { k == i -> Magic.goldLight; k == 0 -> Magic.heartLight; k == cur -> Magic.ink; else -> Magic.muted })
            t.background = if (k == i) GradientDrawable().apply { setColor(Magic.goldSoft); cornerRadius = dpf(12f) } else null
        }
        val pageIdx = when (i) { 0, 1, 3, 5 -> 0; 2 -> 1; else -> 2 }
        pages.forEachIndexed { k, p -> p.visibility = if (k == pageIdx) View.VISIBLE else View.GONE }
        if (pageIdx == 0) fillTiles(i)
    }

    private fun selectPreset(i: Int) {
        prefs.edit().putInt("preset", i).apply()
        Sound.selectPreset(prefs, i)
        Sound.ensureSamples(this, i) { ui.post { tiles[i]?.alpha = 1f; refreshAdsr(i) } }
        paintTiles(i)
        refreshAdsr(i)
        if (currentTab != 0 && currentTab != tabOf(i)) showTab(tabOf(i)) else showTabColors()
    }

    private fun showTabColors() {
        val cur = tabOf(prefs.getInt("preset", 0))
        tabs.forEachIndexed { k, t ->
            t.setTextColor(when { k == currentTab -> Magic.goldLight; k == 0 -> Magic.heartLight; k == cur -> Magic.ink; else -> Magic.muted })
        }
    }

    private fun paintTiles(selected: Int) {
        for ((j, t) in tiles) {
            val on = j == selected
            t.background = if (on) box(Magic.goldSoft, Magic.gold) else box(Magic.surface, Magic.line)
            t.setTextColor(if (on) Magic.goldLight else Magic.ink)
        }
        if (!::envSection.isInitialized) return
        envSection.visibility = if (selected == Sound.SF2) View.GONE else View.VISIBLE
    }

    private fun refreshAdsr(p: Int) {
        if (p == Sound.SF2) return
        adsrRows.forEachIndexed { w, row -> row.set(Sound.adsr(prefs, p, w)) }
    }

    private val rebuildPrimes = Runnable { Sound.applyPrimes(prefs) }

    private fun refreshPrimes(rebuild: Boolean) {
        val mask = Sound.primeMask(prefs)
        primeChips.forEachIndexed { k, c ->
            val on = mask and (1 shl k) != 0
            c.background = if (on) box(Magic.goldSoft, Magic.gold) else box(Magic.bg, Magic.line)
            c.setTextColor(if (on) Magic.goldLight else Magic.muted)
        }
        val h = Sound.harmonics(mask, Sound.primeMax(prefs))
        harmList.text = h.take(28).joinToString(" ") + if (h.size > 28) " …" else ""
        if (rebuild) {
            ui.removeCallbacks(rebuildPrimes)
            ui.postDelayed(rebuildPrimes, 60)
        }
    }

    private fun playTest() {
        intArrayOf(60, 64, 67, 71, 72).forEachIndexed { i, n ->
            val ch = i + 1
            ui.postDelayed({ Engine.midi(0x90 or ch, n, 100) }, i * 140L)
            ui.postDelayed({ Engine.midi(0x80 or ch, n, 0) }, 1100L + i * 40L)
        }
    }
}
