package cat.asra.rusc

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import java.util.Locale
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private val ui = Handler(Looper.getMainLooper())
    private val held = FloatArray(FortuneWheel.Synth_MAX)
    private var tick = 0
    private var lastRpn = -1

    private lateinit var wheel: FortuneWheel
    private lateinit var status: TextView
    private val tabs = mutableListOf<TextView>()
    private val pages = mutableListOf<View>()
    private val tiles = arrayOfNulls<TextView>(Sound.COUNT)
    private val primeChips = mutableListOf<TextView>()
    private lateinit var harmList: TextView
    private lateinit var sfTile: TextView
    private lateinit var sfFile: TextView
    private lateinit var sfSpinner: Spinner
    private var sfShown = -1
    private lateinit var envSection: View
    private val adsrRows = mutableListOf<SliderRow>()
    private lateinit var wheels: TextView
    private lateinit var bendNote: TextView
    private lateinit var diag: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density
    private fun fmt(s: String, vararg a: Any) = String.format(Locale.US, s, *a)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Magic.bg
        window.navigationBarColor = Magic.bg
        runCatching { Magic.font = resources.getFont(R.font.macondo) }
        prefs = Sound.prefs(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        RuscService.start(this)
        setContentView(build())
        Status.onStopped = { ui.post { finish() } }
        ui.post(poll)
    }

    override fun onResume() {
        super.onResume()
        if (!Status.running) RuscService.start(this)
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        Status.onStopped = null
        super.onDestroy()
    }

    // ---------- sondeo: rueda a 25 fps, el resto dos veces por segundo ----------
    private val poll = object : Runnable {
        override fun run() {
            wheel.update(held, Engine.heldPitches(held))
            if (tick % 3 == 0 && wheels.isShown) {
                wheels.text = fmt("Pitch %+.2f   ·   Mod %d%%", Engine.wheelCents() / 100f, (Engine.modWheel() * 100).roundToInt())
            }
            if (tick % 12 == 0) slowUpdate()
            tick++
            ui.postDelayed(this, 40)
        }
    }

    private fun slowUpdate() {
        val lat = Engine.latencyMs()
        status.text = listOfNotNull(Status.midi.ifEmpty { null },
            if (Status.audioOk && lat > 0) fmt("%.0f ms", lat) else null).joinToString("   ·   ")
        val loaded = Status.samplesLoaded
        for (i in Sound.sampled.indices) tiles[Sound.FIRST_SAMPLE + i]?.alpha = if (i < loaded) 1f else .35f
        if (Status.sf2Names.size != sfShown) refreshSf2()
        Engine.sf2Collect()
        if (diag.isShown) {
            val sr = Engine.sampleRate()
            val buf = Engine.bufferFrames()
            diag.text = fmt("%d muestras · %.1f ms · %s · %d cortes · %d voces",
                buf, if (sr > 0) buf * 1000f / sr else 0f,
                if (Engine.exclusive()) "exclusivo" else "compartido", Engine.xruns(), Engine.voices())
        }
        val r = Engine.rpnRange()
        if (r > 0 && r != lastRpn) { lastRpn = r; bendNote.text = resolution(r, true) }
    }

    private fun resolution(range: Int, fromController: Boolean) =
        fmt("%s%.2f¢ de resolución", if (fromController) "HexBoard ±$range · " else "", range * 200f / 16384f)

    // ---------- piezas ----------
    private fun box(fill: Int, stroke: Int, radius: Float = dpf(12f)) = GradientDrawable().apply {
        cornerRadius = radius
        setColor(fill)
        setStroke(dp(1).coerceAtLeast(2), stroke)
    }

    private fun text(s: CharSequence, size: Float, color: Int = Magic.ink) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        typeface = Magic.font
        includeFontPadding = false
    }

    private fun tile(label: String, onClick: () -> Unit) = text(label, 17f).apply {
        gravity = Gravity.CENTER
        minHeight = dp(52)
        setPadding(dp(6), dp(8), dp(6), dp(8))
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }

    private fun gridParams() = GridLayout.LayoutParams(
        GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f)
    ).apply { width = 0; setMargins(dp(4), dp(4), dp(4), dp(4)) }

    inner class SliderRow(val view: View, private val bar: SeekBar, private val value: TextView,
                          private val toPos: (Float) -> Int, private val show: (Float) -> String) {
        fun set(v: Float) { bar.progress = toPos(v); value.text = show(v) }
    }

    private fun slider(name: String, min: Float, max: Float, start: Float, log: Boolean = false,
                       show: (Float) -> String, onChange: (Float) -> Unit): SliderRow {
        val toVal = { pos: Int -> val t = pos / 1000f; if (log) exp(ln(min) + (ln(max) - ln(min)) * t) else min + (max - min) * t }
        val toPos = { v: Float ->
            val c = v.coerceIn(min, max)
            ((if (log) (ln(c) - ln(min)) / (ln(max) - ln(min)) else (c - min) / (max - min)) * 1000).roundToInt()
        }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(2), 0, dp(2)) }
        row.addView(text(name, 16f), LinearLayout.LayoutParams(dp(92), WRAP_CONTENT))
        val value = text(show(start), 14f, Magic.muted).apply { gravity = Gravity.END }
        val bar = SeekBar(this).apply {
            this.max = 1000
            progress = toPos(start)
            progressTintList = ColorStateList.valueOf(Magic.gold)
            thumbTintList = ColorStateList.valueOf(Magic.goldLight)
            progressBackgroundTintList = ColorStateList.valueOf(Magic.line)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    val v = toVal(p); value.text = show(v); onChange(v)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        row.addView(bar, LinearLayout.LayoutParams(0, dp(44), 1f))
        row.addView(value, LinearLayout.LayoutParams(dp(64), WRAP_CONTENT))
        return SliderRow(row, bar, value, toPos, show)
    }

    // Adaptador de desplegables con la tipografía de la app
    private inner class FontAdapter(items: List<String>) : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
        private fun style(v: View, drop: Boolean) = (v as TextView).apply {
            typeface = Magic.font
            textSize = 16f
            setTextColor(Magic.ink)
            setPadding(dp(12), dp(if (drop) 12 else 6), dp(12), dp(if (drop) 12 else 6))
        }
        override fun getView(p: Int, c: View?, parent: ViewGroup) = style(super.getView(p, c, parent), false)
        override fun getDropDownView(p: Int, c: View?, parent: ViewGroup) = style(super.getDropDownView(p, c, parent), true)
    }

    private fun spinner(items: List<String>, selected: Int, onPick: (Int) -> Unit) = Spinner(this).apply {
        adapter = FontAdapter(items)
        setPopupBackgroundDrawable(ColorDrawable(Magic.surface))
        background = box(Magic.surface, Magic.line)
        if (items.isNotEmpty()) setSelection(selected.coerceIn(0, items.size - 1), false)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) = onPick(pos)
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun labeled(name: String, v: View): View = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(4), 0, dp(4))
        addView(text(name, 16f), LinearLayout.LayoutParams(dp(92), WRAP_CONTENT))
        addView(v, LinearLayout.LayoutParams(0, dp(44), 1f))
    }

    private fun toggle(name: String, on: Boolean, onToggle: (Boolean) -> Unit) = Switch(this).apply {
        text = name
        textSize = 17f
        typeface = Magic.font
        setTextColor(Magic.ink)
        isChecked = on
        thumbTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(Magic.goldLight, Magic.muted))
        trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(Magic.gold, Magic.line))
        minHeight = dp(48)
        setOnCheckedChangeListener { _, c -> onToggle(c) }
    }

    // Sección plegable: título + flecha; se recuerda abierta o cerrada
    private fun section(root: LinearLayout, key: String, title: String, fill: (LinearLayout) -> Unit): View {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(4), dp(14), dp(14))
        }
        fill(body)
        val chevron = Chevron(this)
        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), 0, dp(10), 0)
            minimumHeight = dp(56)
            isClickable = true
            isFocusable = true
            addView(text(title, 20f, Magic.goldLight), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(chevron, LinearLayout.LayoutParams(dp(28), dp(28)))
        }
        val open = prefs.getBoolean("open_$key", false)
        body.visibility = if (open) View.VISIBLE else View.GONE
        chevron.rotation = if (open) 180f else 0f
        head.setOnClickListener {
            val now = body.visibility != View.VISIBLE
            body.visibility = if (now) View.VISIBLE else View.GONE
            chevron.open = now
            prefs.edit().putBoolean("open_$key", now).apply()
        }
        wrap.background = box(Magic.surface, Magic.line, dpf(16f))
        wrap.addView(head)
        wrap.addView(body)
        root.addView(wrap, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(10) })
        return wrap
    }

    private fun ms(v: Float) = if (v < 1f) fmt("%.0f ms", v * 1000) else fmt("%.1f s", v)
    private fun pct(v: Float) = fmt("%.0f%%", v * 100)

    // ---------- construcción ----------
    private fun build(): View {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(20))
        }

        page.addView(Retablo(this))

        // estado + acciones
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(4), 0, dp(8)) }
        status = text("", 14f, Magic.muted)
        top.addView(status, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        val actions = listOf<Triple<Int, String, () -> Unit>>(
            Triple(Glyph.PLAY, "Probar sonido") { playTest() },
            Triple(Glyph.STOP, "Silenciar todo") { Engine.param(Engine.PANIC, 0f) },
            Triple(Glyph.POWER, "Apagar Rusc") { RuscService.stop(this); finish() })
        for ((kind, label, action) in actions) {
            top.addView(Glyph(this, kind, label).apply { setOnClickListener { action() } },
                LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(8) })
        }
        page.addView(top)

        // pestañas de timbre
        val tabRow = LinearLayout(this)
        listOf("Sinte", "Primos", "Samples", "SF2").forEachIndexed { i, name ->
            val t = text(name, 18f).apply {
                gravity = Gravity.CENTER
                minHeight = dp(48)
                isClickable = true
                setOnClickListener { showTab(i) }
            }
            tabs.add(t)
            tabRow.addView(t, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        }
        page.addView(tabRow)

        val pagesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, 0) }
        pages.add(tileGrid(0 until Sound.PRIMES) { Sound.synths[it] })
        pages.add(primesPage())
        pages.add(tileGrid(Sound.FIRST_SAMPLE until Sound.SF2) { Sound.sampled[it - Sound.FIRST_SAMPLE].first })
        pages.add(sf2Page())
        pages.forEach { pagesBox.addView(it) }
        page.addView(pagesBox)

        // ajustes plegables
        envSection = section(page, "env", "Envolvente") { b ->
            val cur = prefs.getInt("preset", 0)
            val ranges = listOf(Triple(.001f, 4f, true), Triple(.01f, 20f, true), Triple(0f, 1f, false), Triple(.005f, 8f, true))
            listOf("Ataque", "Caída", "Sostén", "Final").forEachIndexed { w, n ->
                val (mn, mx, lg) = ranges[w]
                val row = slider(n, mn, mx, Sound.adsr(prefs, cur, w), lg, show = { v -> if (w == 2) pct(v) else ms(v) }) { v ->
                    val p = prefs.getInt("preset", 0)
                    prefs.edit().putFloat("adsr_${p}_$w", v).apply()
                    Engine.param(Engine.ATTACK + w, v)
                }
                adsrRows.add(row)
                b.addView(row.view)
            }
            b.addView(Glyph(this, Glyph.RESET, "Restablecer envolvente").apply {
                setOnClickListener {
                    val p = prefs.getInt("preset", 0)
                    prefs.edit().apply { for (w in 0..3) remove("adsr_${p}_$w") }.apply()
                    Sound.selectPreset(prefs, p)
                    refreshAdsr(p)
                }
            }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { gravity = Gravity.END; topMargin = dp(4) })
        }

        section(page, "fx", "Efectos") { b ->
            b.addView(toggle("Reverb", prefs.getBoolean("revOn", false)) { prefs.edit().putBoolean("revOn", it).apply(); Sound.applyEffects(prefs) })
            b.addView(slider("Mezcla", 0f, .8f, prefs.getFloat("revMix", .25f), show = ::pct) { prefs.edit().putFloat("revMix", it).apply(); Sound.applyEffects(prefs) }.view)
            b.addView(slider("Tamaño", 0f, 1f, prefs.getFloat("revSize", .5f), show = ::pct) { prefs.edit().putFloat("revSize", it).apply(); Engine.param(Engine.REVERB_SIZE, it) }.view)
            b.addView(toggle("Delay", prefs.getBoolean("dlyOn", false)) { prefs.edit().putBoolean("dlyOn", it).apply(); Sound.applyEffects(prefs) },
                LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(10) })
            b.addView(slider("Mezcla", 0f, .8f, prefs.getFloat("dlyMix", .3f), show = ::pct) { prefs.edit().putFloat("dlyMix", it).apply(); Sound.applyEffects(prefs) }.view)
            b.addView(slider("Tiempo", .02f, 2f, prefs.getFloat("dlyTime", .35f), true, show = ::ms) { prefs.edit().putFloat("dlyTime", it).apply(); Engine.param(Engine.DELAY_TIME, it) }.view)
            b.addView(slider("Eco", 0f, .9f, prefs.getFloat("dlyFb", .35f), show = ::pct) { prefs.edit().putFloat("dlyFb", it).apply(); Engine.param(Engine.DELAY_FB, it) }.view)
        }

        section(page, "wheels", "Ruedas") { b ->
            wheels = text("", 14f, Magic.muted).apply { setPadding(0, 0, 0, dp(6)) }
            b.addView(wheels)
            b.addView(labeled("Mod", spinner(Sound.modTargets, prefs.getInt("modDest", 0)) {
                prefs.edit().putInt("modDest", it).apply(); Engine.param(Engine.MOD_DEST, it.toFloat())
            }))
            b.addView(slider("LFO", .5f, 12f, prefs.getFloat("lfoRate", 5.6f), true, show = { fmt("%.1f Hz", it) }) {
                prefs.edit().putFloat("lfoRate", it).apply(); Engine.param(Engine.LFO_RATE, it)
            }.view)
            b.addView(slider("Vibrato", 5f, 100f, prefs.getFloat("vibDepth", 35f), show = { fmt("%.0f¢", it) }) {
                prefs.edit().putFloat("vibDepth", it).apply(); Engine.param(Engine.VIB_DEPTH, it)
            }.view)
            b.addView(labeled("Pitch", spinner(Sound.wheelRanges.map { "±$it" },
                Sound.wheelRanges.indexOf(prefs.getInt("bendGlobal", 2)).coerceAtLeast(0)) {
                prefs.edit().putInt("bendGlobal", Sound.wheelRanges[it]).apply()
                Engine.param(Engine.BEND_GLOBAL, Sound.wheelRanges[it].toFloat())
            }))
        }

        section(page, "tuning", "Afinación") { b ->
            val saved = prefs.getInt("bendNote", 48)
            bendNote = text(resolution(saved, false), 14f, Magic.muted).apply { setPadding(0, dp(4), 0, 0) }
            b.addView(labeled("Bend", spinner(Sound.noteRanges.map { "±$it" }, Sound.noteRanges.indexOf(saved).coerceAtLeast(0)) {
                prefs.edit().putInt("bendNote", Sound.noteRanges[it]).apply()
                Engine.param(Engine.BEND_NOTE, Sound.noteRanges[it].toFloat())
                if (lastRpn < 0) bendNote.text = resolution(Sound.noteRanges[it], false)
            }))
            b.addView(bendNote)
        }

        section(page, "out", "Salida") { b ->
            b.addView(slider("Volumen", 0f, 1f, prefs.getFloat("volume", .8f), show = ::pct) {
                prefs.edit().putFloat("volume", it).apply(); Engine.param(Engine.VOLUME, it)
            }.view)
            b.addView(labeled("Buffer", spinner(Sound.bufferModes, prefs.getInt("buffer", 0)) {
                prefs.edit().putInt("buffer", it).apply(); Engine.setBufferMode(it)
            }))
            diag = text("", 13f, Magic.muted).apply { setPadding(0, dp(6), 0, 0) }
            b.addView(diag)
        }

        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            isVerticalFadingEdgeEnabled = true
            setFadingEdgeLength(dp(28))
            addView(page, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }

        // la rueda, fija abajo del todo
        wheel = FortuneWheel(this)
        val dm = resources.displayMetrics
        val wheelH = min(min(dm.heightPixels * .31f, dm.widthPixels * .72f), dpf(300f)).roundToInt()

        val cur = prefs.getInt("preset", 0).coerceIn(0, Sound.COUNT - 1)
        paintTiles(cur)
        showTab(tabOf(cur))
        refreshPrimes(false)

        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Magic.bg)
            addView(scroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
            addView(wheel, LinearLayout.LayoutParams(MATCH_PARENT, wheelH))
        }
    }

    private fun tileGrid(range: IntRange, name: (Int) -> String): View {
        val g = GridLayout(this).apply { columnCount = 3 }
        for (i in range) {
            val t = tile(name(i)) { selectPreset(i) }
            tiles[i] = t
            g.addView(t, gridParams())
        }
        return g
    }

    private fun primesPage(): View {
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val t = tile("Primos") { selectPreset(Sound.PRIMES) }
        tiles[Sound.PRIMES] = t
        v.addView(t, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        val grid = GridLayout(this).apply { columnCount = 6 }
        Sound.primes.forEachIndexed { k, pr ->
            val chip = text(pr.toString(), 18f).apply {
                gravity = Gravity.CENTER
                minHeight = dp(48)
                isClickable = true
                contentDescription = "Primo $pr"
                setOnClickListener {
                    prefs.edit().putInt("primesMask", Sound.primeMask(prefs) xor (1 shl k)).apply()
                    refreshPrimes(true)
                    if (prefs.getInt("preset", 0) != Sound.PRIMES) selectPreset(Sound.PRIMES)
                }
            }
            primeChips.add(chip)
            grid.addView(chip, gridParams())
        }
        v.addView(grid)
        v.addView(slider("Máx", 4f, 128f, Sound.primeMax(prefs).toFloat(), true, show = { "${it.roundToInt()}" }) {
            prefs.edit().putInt("primesMax", it.roundToInt()).apply(); refreshPrimes(true)
        }.view)
        v.addView(slider("Caída", 0f, 2f, Sound.primeSlope(prefs), show = { fmt("1/n^%.1f", it) }) {
            prefs.edit().putFloat("primesSlope", it).apply(); refreshPrimes(true)
        }.view)
        harmList = text("", 14f, Magic.muted).apply { setPadding(dp(4), dp(2), dp(4), dp(4)) }
        v.addView(harmList)
        return v
    }

    private fun sf2Page(): View {
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(tile("Abrir .sf2") { pickSf2() }.apply { background = box(Magic.surface, Magic.gold) },
            LinearLayout.LayoutParams(dp(130), WRAP_CONTENT).apply { setMargins(dp(4), dp(4), dp(8), dp(4)) })
        sfFile = text(prefs.getString("sfFile", "") ?: "", 15f, Magic.muted).apply { maxLines = 2 }
        row.addView(sfFile, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        v.addView(row)
        sfTile = tile("") { selectPreset(Sound.SF2) }
        tiles[Sound.SF2] = sfTile
        v.addView(sfTile, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        sfSpinner = spinner(emptyList(), 0) { pos ->
            if (pos != prefs.getInt("sfPreset", 0)) {
                prefs.edit().putInt("sfPreset", pos).apply()
                Engine.sf2Select(pos)
                sfTile.text = Status.sf2Names.getOrElse(pos) { "" }
                selectPreset(Sound.SF2)
            }
        }
        v.addView(sfSpinner, LinearLayout.LayoutParams(MATCH_PARENT, dp(48)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        refreshSf2()
        return v
    }

    private fun refreshSf2() {
        val names = Status.sf2Names
        sfShown = names.size
        val sel = prefs.getInt("sfPreset", 0).coerceIn(0, maxOf(0, names.size - 1))
        sfSpinner.adapter = FontAdapter(names)
        if (names.isNotEmpty()) sfSpinner.setSelection(sel, false)
        sfSpinner.visibility = if (names.isEmpty()) View.GONE else View.VISIBLE
        sfTile.visibility = if (names.isEmpty()) View.GONE else View.VISIBLE
        sfTile.text = names.getOrElse(sel) { "" }
        sfFile.text = when {
            Status.sf2Busy -> "…"
            names.isEmpty() && prefs.getString("sfUri", null) != null -> "No se pudo abrir"
            else -> prefs.getString("sfFile", "") ?: ""
        }
    }

    private fun pickSf2() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        runCatching { startActivityForResult(i, 7) }
    }

    @Deprecated("API clásica de actividad; la app no usa AndroidX")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 7 || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        prefs.edit().putString("sfUri", uri.toString()).putInt("sfPreset", 0)
            .putString("sfFile", Sound.displayName(this, uri)).apply()
        sfFile.text = "…"
        Thread {
            val ok = Sound.loadSf2(this, uri, 0)
            ui.post {
                refreshSf2()
                if (ok) selectPreset(Sound.SF2) else sfFile.text = "No se pudo abrir"
            }
        }.start()
    }

    private fun tabOf(preset: Int) = when {
        preset < Sound.PRIMES -> 0
        preset == Sound.PRIMES -> 1
        preset < Sound.SF2 -> 2
        else -> 3
    }

    private fun showTab(i: Int) {
        val cur = tabOf(prefs.getInt("preset", 0))
        tabs.forEachIndexed { k, t ->
            t.setTextColor(if (k == i) Magic.goldLight else if (k == cur) Magic.ink else Magic.muted)
            t.background = if (k == i) GradientDrawable().apply { setColor(Magic.goldSoft); cornerRadius = dpf(12f) } else null
        }
        pages.forEachIndexed { k, p -> p.visibility = if (k == i) View.VISIBLE else View.GONE }
    }

    private fun selectPreset(i: Int) {
        prefs.edit().putInt("preset", i).apply()
        Sound.selectPreset(prefs, i)
        paintTiles(i)
        refreshAdsr(i)
        showTab(tabOf(i))
    }

    private fun paintTiles(selected: Int) {
        tiles.forEachIndexed { j, t ->
            if (t != null) {
                val on = j == selected
                t.background = if (on) box(Magic.goldSoft, Magic.gold) else box(Magic.surface, Magic.line)
                t.setTextColor(if (on) Magic.goldLight else Magic.ink)
            }
        }
        envSection.visibility = if (selected == Sound.SF2) View.GONE else View.VISIBLE
    }

    private fun refreshAdsr(p: Int) {
        if (p == Sound.SF2) return
        adsrRows.forEachIndexed { w, row -> row.set(Sound.adsr(prefs, p, w)) }
    }

    private val rebuildPrimes = Runnable { Sound.applyPrimes(prefs) }

    private fun refreshPrimes(rebuild: Boolean) {
        val mask = Sound.primeMask(prefs)
        primeChips.forEachIndexed { k, c ->
            val on = mask and (1 shl k) != 0
            c.background = if (on) box(Magic.goldSoft, Magic.gold) else box(Magic.bg, Magic.line)
            c.setTextColor(if (on) Magic.goldLight else Magic.muted)
        }
        val h = Sound.harmonics(mask, Sound.primeMax(prefs))
        harmList.text = h.take(28).joinToString(" ") + if (h.size > 28) " …" else ""
        if (rebuild) {
            ui.removeCallbacks(rebuildPrimes)
            ui.postDelayed(rebuildPrimes, 60)
        }
    }

    private fun playTest() {
        intArrayOf(60, 64, 67, 71, 72).forEachIndexed { i, n ->
            val ch = i + 1
            ui.postDelayed({ Engine.midi(0x90 or ch, n, 100) }, i * 140L)
            ui.postDelayed({ Engine.midi(0x80 or ch, n, 0) }, 1100L + i * 40L)
        }
    }
}
