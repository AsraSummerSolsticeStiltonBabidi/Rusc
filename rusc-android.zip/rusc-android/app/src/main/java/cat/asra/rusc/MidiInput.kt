package cat.asra.rusc

import android.content.Context
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.Looper

class MidiInput(context: Context, private val onStatus: (String) -> Unit) {
    private val manager = context.getSystemService(Context.MIDI_SERVICE) as MidiManager
    private val handler = Handler(Looper.getMainLooper())
    private val devices = mutableMapOf<Int, MidiDevice>()
    private val ports = mutableMapOf<Int, List<MidiOutputPort>>()
    private val names = mutableMapOf<Int, String>()
    private val pending = mutableSetOf<Int>()

    private val callback = object : MidiManager.DeviceCallback() {
        override fun onDeviceAdded(info: MidiDeviceInfo) = open(info)
        override fun onDeviceRemoved(info: MidiDeviceInfo) {
            if (info.id in devices) Engine.param(Engine.PANIC, 0f)   // evita notas colgadas al desenchufar
            closeDevice(info.id)
            report()
        }
    }

    @Suppress("DEPRECATION")
    fun start() {
        manager.registerDeviceCallback(callback, handler)
        manager.devices.forEach { open(it) }
        report()
    }

    fun close() {
        manager.unregisterDeviceCallback(callback)
        devices.keys.toList().forEach { closeDevice(it) }
    }

    private fun open(info: MidiDeviceInfo) {
        if (info.outputPortCount == 0 || info.id in devices || info.id in pending) return
        pending.add(info.id)
        manager.openDevice(info, { device ->
            pending.remove(info.id)
            if (device != null) {
                val opened = (0 until info.outputPortCount).mapNotNull { i ->
                    device.openOutputPort(i)?.also { it.connect(Parser()) }
                }
                devices[info.id] = device
                ports[info.id] = opened
                names[info.id] = info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "MIDI"
            }
            report()
        }, handler)
    }

    private fun closeDevice(id: Int) {
        ports.remove(id)?.forEach { runCatching { it.close() } }
        devices.remove(id)?.let { runCatching { it.close() } }
        names.remove(id)
    }

    private fun report() {
        onStatus(if (names.isEmpty()) "Sin MIDI" else names.values.joinToString(", "))
    }

    // Separa el flujo de bytes en mensajes (con running status) y los manda al motor
    private class Parser : MidiReceiver() {
        private var status = 0
        private var need = 0
        private var d1 = -1

        override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
            for (i in offset until offset + count) {
                val b = msg[i].toInt() and 0xFF
                if (b >= 0xF8) continue
                if (b >= 0x80) {
                    if (b >= 0xF0) { status = 0; continue }
                    status = b
                    d1 = -1
                    val type = b and 0xF0
                    need = if (type == 0xC0 || type == 0xD0) 1 else 2
                    continue
                }
                if (status == 0) continue
                if (need == 1) {
                    Engine.midi(status, b, 0)
                } else if (d1 < 0) {
                    d1 = b
                } else {
                    Engine.midi(status, d1, b)
                    d1 = -1
                }
            }
        }
    }
}
