#pragma once
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace rusc {

// Datos crudos de un .sf2 en memoria nativa (fuera del heap de Java)
struct SfFile {
    std::vector<uint8_t> bytes;
    const int16_t* smpl = nullptr;
    uint32_t nsmpl = 0;
};

// Zona lista para sonar: instrumento + preset ya combinados
struct SfRegion {
    uint8_t keyLo = 0, keyHi = 127, velLo = 0, velHi = 127;
    uint32_t start = 0, end = 0, loopStart = 0, loopEnd = 0;
    uint8_t loopMode = 0;        // 0 sin bucle, 1 bucle continuo, 3 bucle hasta soltar
    float scale = 100;           // cents por tecla (scaleTuning)
    float offset = 0;            // cents: afinación - scale * tecla raíz
    float srcRate = 44100;
    float gain = 1;
    float attack = .001f, hold = 0, decay = .001f, sustain = 1, release = .001f;   // s / nivel
    float keyToHold = 0, keyToDecay = 0;   // timecents por tecla
    float filterHz = 0, filterQ = .707f;   // 0 = sin filtro
};

struct SfBank {
    std::shared_ptr<SfFile> file;
    std::vector<SfRegion> regions;
};

class SoundFont {
public:
    bool open(std::vector<uint8_t>&& bytes);
    int count() const { return (int)order.size(); }
    std::string name(int i) const;      // "banco:programa Nombre", solo ASCII
    SfBank* makeBank(int i) const;      // nullptr si el preset no tiene muestras válidas

private:
    std::shared_ptr<SfFile> file;
    const uint8_t *phdr = nullptr, *pbag = nullptr, *pgen = nullptr, *inst = nullptr,
                  *ibag = nullptr, *igen = nullptr, *shdr = nullptr;
    uint32_t nPhdr = 0, nPbag = 0, nPgen = 0, nInst = 0, nIbag = 0, nIgen = 0, nShdr = 0;
    std::vector<int> order;             // presets ordenados por banco y programa
};

}  // namespace rusc
