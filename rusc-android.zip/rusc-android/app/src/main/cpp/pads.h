#pragma once
#include <atomic>
#include <cstdint>
#include <vector>

namespace rusc {

// Sample de un pad: PCM de 16 bits, mono o estéreo entrelazado
struct PadSample {
    float sr = 48000;
    int ch = 1;
    std::vector<int16_t> data;
    size_t frames() const { return data.size() / (size_t)ch; }
};

// Reverb de catedral: red de 8 líneas de retardo realimentadas (cola de unos 9 s) con difusión a la entrada
class Cathedral {
public:
    void init(float sr, float rt60);
    void clear();
    inline void process(float in, float& l, float& r);
private:
    static constexpr int NL = 8, NAP = 4;
    std::vector<float> line[NL], ap[NAP];
    int idx[NL] = {}, apIdx[NAP] = {};
    float g[NL] = {}, lp[NL] = {}, damp = .5f;
};

// Sampler de 10 pads con volumen, corte de graves, reverb de catedral y delay propios.
// No comparte nada con los efectos del sinte.
class Pads {
public:
    static constexpr int N = 10;
    static constexpr int MAXBLK = 32;
    enum What : uint8_t { TRIGGER = 0, VOLUME, REVERB, DELAY, LOWCUT, LOOP, DELAY_TIME, DELAY_FB };

    Pads();
    ~Pads();
    void init(float sampleRate);
    // hilo de audio
    void event(int pad, int what, float v);
    void stopAll();
    void render(float* L, float* R, int m);   // suma a L y R (m <= MAXBLK)
    // fuera del hilo de audio
    void publish(int pad, PadSample* s);      // el pad adopta el sample (vacío = sin sample)
    void collect();                           // libera los samples retirados
    std::atomic<uint32_t> playing{0};         // bit por pad
    std::atomic<float> progress[N];           // 0-1

private:
    struct Pad {
        PadSample* cur = nullptr;
        std::atomic<PadSample*> pending{nullptr}, retired{nullptr};
        bool on = false, stopping = false, loop = false;
        double pos = 0;
        float gain = 0, vol = .8f, rev = 0, dly = 0, cut = 0;
        float l1 = 0, l2 = 0, r1 = 0, r2 = 0;   // filtro paso alto
    };
    Pad pad[N];
    float sr = 48000;
    Cathedral hall;
    std::vector<float> dlyL, dlyR;
    int dlyIdx = 0, tail = 0;
    float dlyTime = .45f, dlyTimeS = .45f, dlyFb = .5f, dlyLpL = 0, dlyLpR = 0;
    void adopt();
};

}  // namespace rusc
