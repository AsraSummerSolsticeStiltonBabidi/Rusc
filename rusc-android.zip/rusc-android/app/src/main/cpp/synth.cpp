#include "synth.h"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <cstdlib>

extern "C" int stb_vorbis_decode_memory(const unsigned char* mem, int len, int* channels, int* sample_rate, short** output);

namespace rusc {

static constexpr int TBL = Synth::TBL;
static float tables[NWAVES][TBL + 1];
static bool tablesReady = false;

static void buildTable(float* t, const std::vector<float>& h) {
    float mx = 0;
    for (int i = 0; i <= TBL; i++) {
        double ph = 2.0 * M_PI * i / TBL, s = 0;
        for (size_t k = 0; k < h.size(); k++) s += h[k] * std::sin(ph * (double)(k + 1));
        t[i] = (float)s;
        mx = std::max(mx, std::fabs(t[i]));
    }
    for (int i = 0; i <= TBL; i++) t[i] /= mx;
}

static void initTables() {
    if (tablesReady) return;
    buildTable(tables[SINE], {1});
    std::vector<float> tri;
    for (int k = 1; k <= 31; k++)
        tri.push_back(k % 2 ? (((k / 2) % 2) ? -1.f : 1.f) / (float)(k * k) : 0.f);
    buildTable(tables[TRI], tri);
    buildTable(tables[ORGAN], {1, .7f, .45f, .35f, 0, .2f, 0, .12f});
    buildTable(tables[REED], {1, 0, .55f, 0, .32f, 0, .2f, 0, .12f, 0, .07f});
    // vocal "a": envolvente espectral con formantes alrededor de los armónicos 3, 5-6 y 11
    std::vector<float> vow;
    for (int k = 1; k <= 24; k++) {
        float w = std::pow((float)k, -.7f);
        if (k == 3 || k == 2) w *= 2.2f;
        if (k == 5 || k == 6) w *= 1.8f;
        if (k == 11 || k == 12) w *= 1.4f;
        vow.push_back(w);
    }
    buildTable(tables[VOWEL], vow);
    // principal de órgano de tubos
    std::vector<float> ch;
    for (int k = 1; k <= 20; k++) ch.push_back(std::pow((float)k, -.95f) * (k % 2 ? 1.f : .8f));
    buildTable(tables[CHURCH], ch);
    tablesReady = true;
}

// Ayudas para definir timbres: portadora/aditivo (C) y modulador FM (M)
static OscDef C(Wave w, float ratio, float level, float cents = 0, float levelTau = 0, float width = .5f) {
    OscDef o; o.w = w; o.ratio = ratio; o.level = level; o.cents = cents; o.levelTau = levelTau; o.width = width;
    return o;
}
static OscDef M(int target, float ratio, float peak, float sus, float tau, float velFm = 0, float cents = 0) {
    OscDef o; o.w = SINE; o.ratio = ratio; o.cents = cents; o.fmTarget = target;
    o.fmPeak = peak; o.fmSus = sus; o.fmTau = tau; o.velFm = velFm;
    return o;
}
static void ops(Preset& p, std::initializer_list<OscDef> l) { p.n = 0; for (auto& o : l) p.o[p.n++] = o; }
static void env(Preset& p, float a, float d, float s, float r) { p.a = a; p.d = d; p.s = s; p.r = r; }
static void filt(Preset& p, float start, float end, float tau, float q) { p.filt = true; p.fStart = start; p.fEnd = end; p.fTau = tau; p.q = q; }

// Duración de la liberación de cada instrumento sampleado (mismo orden que los archivos .rsc)
static const float SET_RELEASE[Synth::NSETS] = {
    .35f, .35f, .35f, .4f, .12f, .12f, .5f, .5f,      // pianos, TX81Z, clavecines, arpas
    1.2f, .3f, .25f, .8f, .3f, 2.f, 1.2f, .5f,        // vibráfono, marimba, xilófono, glockenspiel, balafón, campanas, campanillas, copas
    .6f, .6f, .5f, .5f, .5f, .5f, 1.f, .5f,           // kalimbas, mbira, nyunga, cítara, salterio, timbales, (libre)
    .25f, .2f, .2f, .2f, .25f, .25f, .3f, .3f};       // órganos, ocarina, flauta, armónica, saxos

// Igualación de volumen: factor medido para que todos los timbres suenen igual de fuertes
static const float LOUD[Synth::NSYNTH] = {
    .76f, .78f, .80f, .83f, .69f, 1.23f, 1.16f, .98f, 1.39f, .85f, 1.45f, .96f, .99f, .90f, .76f, .92f,
    .92f, 1.66f, .80f, 1.66f, 1.49f, 1.49f, 1.29f, .66f, 1.31f, .99f, .97f, 1.15f, .92f, .92f, 1.74f, .96f,
    1.07f, .92f, .91f, 1.19f, 1.46f, .78f, .80f, .68f};

static Preset makePreset(int i);
static Preset makePresetRaw(int i);
static Preset makePreset(int i) {
    Preset p = makePresetRaw(i);
    if (i >= 0 && i < Synth::NSYNTH) p.gain *= LOUD[i];
    return p;
}

static Preset makePresetRaw(int i) {
    Preset p;
    switch (i) {
        // ---------- Eléctricos ----------
        case 0:  // Rhodes: tine + modelo de pastilla, trémolo estéreo de maleta
            ops(p, {C(SINE, 1, 1), M(0, 1, .45f, .06f, .6f, 1), C(SINE, 7, .1f, 0, .04f), C(NOISE, 1, .025f, 0, .006f)});
            env(p, .002f, 5, 0, .35f); p.keyDecay = .55f; p.velAmp = .8f;
            p.pickDrive = 2.2f; p.pickAsym = .55f; p.panRate = 4.5f; p.panDepth = .35f;
            break;
        case 1:  // Rhodes suave
            ops(p, {C(SINE, 1, 1), M(0, 1, .3f, .05f, .5f, .6f), C(SINE, 7, .03f, 0, .03f)});
            env(p, .003f, 5.5f, 0, .4f); p.keyDecay = .5f; p.velAmp = .7f;
            p.pickDrive = 1.3f; p.pickAsym = .35f; p.chorus = .35f;
            break;
        case 2:  // Rhodes con mordida
            ops(p, {C(SINE, 1, 1), M(0, 1, .9f, .12f, .45f, 1), C(SINE, 7, .14f, 0, .035f), C(NOISE, 1, .03f, 0, .006f)});
            env(p, .002f, 4.5f, 0, .3f); p.keyDecay = .6f; p.velAmp = .85f;
            p.pickDrive = 3.6f; p.pickAsym = .8f; p.chorus = .15f; p.panRate = 3.2f; p.panDepth = .2f;
            break;
        case 3:  // Wurlitzer: lengüeta, armónicos impares
            ops(p, {C(SINE, 1, 1), M(0, 1, 1.3f, .35f, .25f, .8f), C(SINE, 2, .12f, 0, .5f)});
            env(p, .002f, 3.2f, 0, .22f); p.keyDecay = .65f; p.velAmp = .8f;
            p.pickDrive = 3.2f; p.pickAsym = .12f; p.panRate = 5.5f; p.panDepth = .12f; p.chorus = .1f;
            break;
        case 4:  // E-Piano FM clásico (estilo DX7)
            ops(p, {C(SINE, 1, 1), M(0, 1, 1, .12f, .9f, .7f), C(SINE, 1, .6f, 3), M(2, 14, 2.2f, 0, .06f, .9f)});
            env(p, .002f, 4, 0, .3f); p.keyDecay = .5f; p.chorus = .3f;
            break;
        case 5:  // Tine
            ops(p, {C(SINE, 1, 1), M(0, 1, 1.4f, .15f, .4f, .6f), C(SINE, 3, .18f, 0, .6f), M(0, 14, .7f, 0, .02f, .8f)});
            env(p, .002f, 4.5f, 0, .4f); p.keyDecay = .5f; p.chorus = .25f;
            break;
        case 6:  // Clavinet
            ops(p, {C(SQUARE, 1, 1, 0, 0, .22f), C(SAW, 1, .3f)});
            filt(p, 16, 3.5f, .12f, 1.5f); p.velFilt = .9f;
            env(p, .001f, 2.4f, 0, .06f); p.keyDecay = .55f; p.velAmp = .85f;
            p.pickDrive = 1.5f; p.pickAsym = .2f;
            break;
        case 7:  // Celesta
            ops(p, {C(SINE, 1, 1), M(0, 4, 1.6f, .08f, .22f, .6f), C(SINE, 4, .12f, 0, .35f)});
            env(p, .001f, 2.6f, 0, .5f); p.keyDecay = .55f; p.chorus = .1f;
            break;
        // ---------- Teclados ----------
        case 8:  // Órgano
            ops(p, {C(ORGAN, 1, 1)});
            env(p, .005f, .1f, 1, .06f); p.gain = .7f; p.chorus = .2f; p.panRate = 6.4f; p.panDepth = .12f;
            break;
        case 9:  // Órgano de jazz (16' 8' 5⅓', percusión y clic)
            ops(p, {C(SINE, 1, 1), C(SINE, .5f, .75f), C(SINE, 1.5f, .7f), C(SINE, 3, .5f, 0, .22f), C(NOISE, 1, .05f, 0, .004f)});
            env(p, .004f, .1f, 1, .05f); p.gain = .5f; p.panRate = 6.8f; p.panDepth = .3f; p.chorus = .15f;
            break;
        case 10:  // Órgano de iglesia
            ops(p, {C(CHURCH, 1, 1), C(CHURCH, 2, .45f), C(SINE, .5f, .4f)});
            env(p, .06f, .2f, 1, .4f); p.gain = .6f; p.chorus = .1f;
            break;
        case 11:  // Armonio
            ops(p, {C(REED, 1, 1), C(REED, 1, .7f, 6)});
            filt(p, 5, 5, 0, .7f);
            env(p, .08f, .3f, .9f, .2f); p.gain = .7f; p.chorus = .2f;
            break;
        case 12:  // Acordeón (musette)
            ops(p, {C(SAW, 1, .6f), C(SAW, 1, .5f, 9), C(SAW, 1, .4f, -9)});
            filt(p, 4.5f, 4.5f, 0, .8f);
            env(p, .03f, .2f, .95f, .1f); p.gain = .8f;
            break;
        case 13:  // EP vintage
            ops(p, {C(SINE, 1, 1), M(0, 1, 2.2f, .25f, .35f, .5f), M(0, 14, 1.2f, 0, .015f, .5f)});
            env(p, .002f, 3, 0, .3f); p.keyDecay = .4f;
            break;
        case 14:  // Pulsado
            ops(p, {C(SAW, 1, 1), C(SQUARE, 1, .4f, 4)});
            filt(p, 14, 1.6f, .12f, 1.2f); p.velFilt = .5f;
            env(p, .002f, 1.8f, 0, .15f); p.keyDecay = .4f;
            break;
        case 15:  // Seno
            ops(p, {C(SINE, 1, 1)});
            env(p, .006f, .1f, 1, .08f);
            break;
        // ---------- Pads ----------
        case 16:  // Pad cálido
            ops(p, {C(SAW, 1, 1, -7), C(SAW, 1, 1, 7), C(TRI, .5f, .5f)});
            filt(p, 3, 3, 0, .6f);
            env(p, .45f, 1.5f, .8f, 1.4f); p.gain = .8f; p.chorus = .3f;
            break;
        case 17:  // Pad ancho
            ops(p, {C(SAW, 1, .28f, -18), C(SAW, 1, .28f, -9), C(SAW, 1, .28f, -3), C(SAW, 1, .28f, 3), C(SAW, 1, .28f, 9), C(SAW, 1, .28f, 18)});
            filt(p, 3.5f, 3.5f, 0, .6f);
            env(p, .6f, 1.5f, .85f, 1.8f); p.gain = .8f; p.chorus = .5f;
            break;
        case 18:  // Pad cristal
            ops(p, {C(SINE, 1, 1), C(SINE, 2.003f, .3f), M(0, 3.5f, .8f, .4f, 2), C(SINE, 1, .6f, 7)});
            env(p, .9f, 2, .7f, 2.5f); p.gain = .8f; p.chorus = .4f;
            break;
        case 19:  // Coro
            ops(p, {C(VOWEL, 1, .7f, -6), C(VOWEL, 1, .7f, 6), C(VOWEL, 1, .5f)});
            filt(p, 6, 6, 0, .5f);
            env(p, .35f, 1, .9f, 1.2f); p.gain = .8f; p.chorus = .5f;
            break;
        case 20:  // Cuerdas
            ops(p, {C(SAW, 1, .45f, -11), C(SAW, 1, .45f), C(SAW, 1, .45f, 9)});
            filt(p, 2, 5, .25f, .65f);
            env(p, .14f, .6f, .9f, .45f); p.gain = .8f; p.chorus = .2f;
            break;
        case 21:  // Cuerdas lentas
            ops(p, {C(SAW, 1, .38f, -12), C(SAW, 1, .38f, -4), C(SAW, 1, .38f, 4), C(SAW, 1, .38f, 12)});
            filt(p, 1.6f, 4, .6f, .6f);
            env(p, .9f, 1, .9f, 1.6f); p.gain = .8f; p.chorus = .3f;
            break;
        case 22:  // Atmósfera
            ops(p, {C(TRI, 1, .9f), C(SINE, 1.5f, .25f), C(SINE, 2.01f, .25f), C(NOISE, 1, .04f)});
            filt(p, 6, 6, 0, .6f);
            env(p, 1.2f, 2, .8f, 3); p.gain = .8f; p.chorus = .6f;
            break;
        case 23:  // Pad seno
            ops(p, {C(SINE, 1, .7f, -4), C(SINE, 1, .7f, 4), C(SINE, 2, .2f)});
            env(p, .5f, 1, .9f, 1.5f); p.chorus = .3f;
            break;
        // ---------- Pulsados ----------
        case 24:  // Arpa sintética
            ops(p, {C(SAW, 1, .6f), C(SINE, 1, .6f)});
            filt(p, 10, 1.4f, .2f, 1); p.velFilt = .6f;
            env(p, .001f, 2.8f, 0, .4f); p.keyDecay = .5f;
            break;
        case 25:  // Kalimba FM
            ops(p, {C(SINE, 1, 1), M(0, 7, 1.6f, 0, .012f, .5f), C(SINE, 5.4f, .15f, 0, .08f)});
            env(p, .001f, 1.6f, 0, .2f); p.keyDecay = .4f;
            break;
        case 26:  // Marimba FM
            ops(p, {C(SINE, 1, 1), C(SINE, 3.93f, .35f, 0, .04f), C(SINE, 9.2f, .12f, 0, .015f)});
            env(p, .001f, 1.2f, 0, .15f); p.keyDecay = .5f;
            break;
        case 27:  // Campana
            ops(p, {C(SINE, 1, 1), M(0, 3.5f, 3, .3f, .8f, .4f), C(SINE, 2.01f, .25f)});
            env(p, .002f, 6, 0, 1.5f); p.gain = .8f; p.keyDecay = .3f;
            break;
        case 28:  // Vidrio
            ops(p, {C(SINE, 1, 1), C(SINE, 2.76f, .3f, 0, 1.2f), C(SINE, 5.4f, .15f, 0, .6f)});
            env(p, .002f, 4, 0, 1.2f); p.chorus = .2f; p.keyDecay = .4f;
            break;
        case 29:  // Steel drum
            ops(p, {C(SINE, 1, 1), M(0, 1, 1.4f, .2f, .15f, .5f), C(SINE, 2, .35f, 0, .5f), C(SINE, 3, .2f, 0, .3f)});
            env(p, .002f, 2, 0, .3f); p.keyDecay = .5f;
            break;
        case 30:  // Koto
            ops(p, {C(SAW, 1, .5f), C(SQUARE, 1, .4f, 0, 0, .2f)});
            filt(p, 12, 2, .08f, 1.6f); p.velFilt = .5f;
            env(p, .001f, 2.5f, 0, .3f); p.keyDecay = .6f;
            break;
        case 31:  // Caja de música
            ops(p, {C(SINE, 1, 1), C(SINE, 5.4f, .25f, 0, .15f), M(0, 4, .5f, 0, .05f, .5f)});
            env(p, .001f, 2, 0, .6f); p.keyDecay = .7f;
            break;
        // ---------- Viento y graves ----------
        case 32:  // Caña
            ops(p, {C(REED, 1, 1)});
            filt(p, 2, 6, .04f, .7f);
            env(p, .035f, .2f, .85f, .08f);
            break;
        case 33:  // Flauta
            ops(p, {C(SINE, 1, 1), C(SINE, 2, .12f), C(SINE, 3, .05f), C(NOISE, 1, .03f)});
            filt(p, 8, 8, 0, .7f);
            env(p, .06f, .3f, .9f, .12f);
            break;
        case 34:  // Clarinete
            ops(p, {C(SQUARE, 1, 1)});
            filt(p, 2, 4, .05f, .7f);
            env(p, .04f, .2f, .9f, .08f); p.gain = .8f;
            break;
        case 35:  // Metales
            ops(p, {C(SAW, 1, 1), C(SAW, 1, .7f, 5)});
            filt(p, 1.5f, 6, .07f, .8f); p.velFilt = .7f;
            env(p, .03f, .4f, .8f, .12f); p.gain = .7f;
            break;
        case 36:  // Sierra
            ops(p, {C(SAW, 1, 1)});
            env(p, .004f, .1f, 1, .06f); p.gain = .75f;
            break;
        case 37:  // Cuadrada
            ops(p, {C(SQUARE, 1, .8f), C(SQUARE, 1, .5f, 7)});
            filt(p, 7, 7, 0, 1);
            env(p, .005f, .1f, .9f, .08f); p.gain = .7f;
            break;
        case 38:  // Bajo
            ops(p, {C(SAW, 1, 1), C(SQUARE, .5f, .5f)});
            filt(p, 6, 2, .08f, .9f);
            env(p, .003f, .6f, .6f, .12f);
            break;
        case 39:  // Bajo sub
            ops(p, {C(SINE, 1, 1), C(TRI, 1, .3f), C(SINE, 2, .15f, 0, .3f)});
            env(p, .004f, .5f, .8f, .1f); p.gain = 1.1f;
            break;
        case Synth::PRIMES_PRESET:
            ops(p, {C(PRIMES, 1, 1)});
            env(p, .01f, .4f, .8f, .3f); p.gain = .9f;
            break;
        case Synth::SF2_PRESET:
            p.sf2 = true;
            env(p, .001f, 1, 1, .05f);
            break;
        default:  // instrumentos sampleados
            p.sampleSet = i - Synth::FIRST_SET;
            env(p, .001f, 30, 1, SET_RELEASE[p.sampleSet]);
            p.gain = 1.3f;
            break;
    }
    return p;
}

static Preset PRESETS[Synth::NPRESETS];
static Preset DEFAULTS[Synth::NPRESETS];

float Synth::presetDefault(int preset, int which) {
    const Preset p = makePreset(std::clamp(preset, 0, NPRESETS - 1));
    switch (which) { case 0: return p.a; case 1: return p.d; case 2: return p.s; default: return p.r; }
}

static inline float blep(float t, float dt) {
    dt = std::fabs(dt);
    if (dt <= 0.f) return 0.f;
    if (t < dt) { t /= dt; return t + t - t * t - 1.f; }
    if (t > 1.f - dt) { t = (t - 1.f) / dt; return t * t + t + t + 1.f; }
    return 0.f;
}

static inline float tableRead(const float* t, float p) {
    float x = p * TBL;
    int i = std::min((int)x, TBL - 1);
    float fr = x - (float)i;
    return t[i] + (t[i + 1] - t[i]) * fr;
}

static inline float wave(Wave w, double& ph, float inc, const float* primeTable, float width) {
    float p = (float)ph, y;
    switch (w) {
        case SAW:
            y = 2.f * p - 1.f - blep(p, inc);
            break;
        case SQUARE: {
            float p2 = p + 1.f - width; if (p2 >= 1.f) p2 -= 1.f;
            y = (p < width ? 1.f : -1.f) + blep(p, inc) - blep(p2, inc) - (2.f * width - 1.f);
            break;
        }
        case PRIMES:
            y = tableRead(primeTable, p);
            break;
        default:
            y = tableRead(tables[w], p);
    }
    ph += inc;
    ph -= std::floor(ph);
    return y;
}

Synth::Synth() {
    for (int i = 0; i < 16; i++) { range[i] = i == 0 ? 2.f : 48.f; rpnM[i] = rpnL[i] = 127; }
    for (auto& s : sets) s.store(nullptr);
    for (auto& f : toFree) f.store(nullptr);
    for (auto& h : heldBuf) h.store(0.f);
    for (auto& k : heldKey) k.store(0);
    for (int i = 0; i < NPRESETS; i++) PRESETS[i] = DEFAULTS[i] = makePreset(i);
    buildPrimes(0b111, 32, 1.f);
}

void Synth::init(float sampleRate) {
    initTables();
    sr = sampleRate;
    dt = 1.f / sr;
    for (auto& x : v) x = Voice();
    const int cl[4] = {1116, 1188, 1277, 1356}, al[2] = {556, 441};
    const float sc = sr / 44100.f;
    for (int i = 0; i < 8; i++) comb[i].assign((size_t)((cl[i % 4] + (i >= 4 ? 23 : 0)) * sc), 0.f);
    for (int i = 0; i < 4; i++) ap[i].assign((size_t)((al[i % 2] + (i >= 2 ? 23 : 0)) * sc), 0.f);
    clearReverb();
    dlyL.assign((size_t)(sr * 2.1f), 0.f);
    dlyR.assign((size_t)(sr * 2.1f), 0.f);
    dlyIdx = 0; dlyLpL = dlyLpR = 0;
    mlpL = mlpB = 0;
    chBuf.assign((size_t)(sr * .03f), 0.f);
    chIdx = 0;
    levEnv = 0; levGain = 1; gRel = 1; mSum = BLK; lookIdx = qIdx = mIdx = 0;
    for (auto& q : qRing) q = 1.f;
    for (auto& q : mRing) q = 1.f;
    for (int i = 0; i < BLK; i++) lookL[i] = lookR[i] = 0;
}

void Synth::clearReverb() {
    for (int i = 0; i < 8; i++) { std::fill(comb[i].begin(), comb[i].end(), 0.f); combIdx[i] = 0; combStore[i] = 0; }
    for (int i = 0; i < 4; i++) { std::fill(ap[i].begin(), ap[i].end(), 0.f); apIdx[i] = 0; }
}

// ---------- samples ----------
bool Synth::loadSamples(int set, const uint8_t* d, int len) {
    if (set < 0 || set >= NSETS || len < 12 || sets[set].load()) return false;
    const bool v3 = std::memcmp(d, "RSC3", 4) == 0;
    if (!v3 && std::memcmp(d, "RSC1", 4) != 0) return false;
    auto* s = new SampleSet();
    uint32_t rate, count;
    std::memcpy(&rate, d + 4, 4);
    std::memcpy(&count, d + 8, 4);
    if (rate < 8000 || rate > 192000 || count > 512) { delete s; return false; }
    s->sr = (float)rate;
    size_t off = 12;
    auto fail = [&]() { delete s; return false; };
    for (uint32_t i = 0; i < count; i++) {
        Zone z;
        if (v3) {
            uint32_t ogg;
            if (off + 16 > (size_t)len) return fail();
            std::memcpy(&z.freq, d + off, 4);
            std::memcpy(&z.loopStart, d + off + 4, 4);
            std::memcpy(&z.loopEnd, d + off + 8, 4);
            std::memcpy(&ogg, d + off + 12, 4);
            off += 16;
            if (off + ogg > (size_t)len) return fail();
            int ch = 0, sr2 = 0;
            short* pcm = nullptr;
            const int n = stb_vorbis_decode_memory(d + off, (int)ogg, &ch, &sr2, &pcm);
            off += ogg;
            if (n <= 8 || ch < 1 || !pcm) { std::free(pcm); return fail(); }
            z.data.resize((size_t)n);
            for (int k = 0; k < n; k++) z.data[k] = pcm[(size_t)k * ch];
            std::free(pcm);
        } else {
            uint32_t n;
            if (off + 8 > (size_t)len) return fail();
            std::memcpy(&z.freq, d + off, 4);
            std::memcpy(&n, d + off + 4, 4);
            off += 8;
            if (off + (size_t)n * 2 > (size_t)len) return fail();
            z.data.resize(n);
            std::memcpy(z.data.data(), d + off, (size_t)n * 2);
            off += (size_t)n * 2;
        }
        if (!(z.freq > 1.f && z.freq < 20000.f)) return fail();
        if (z.loopEnd > z.data.size()) z.loopStart = z.loopEnd = 0;
        s->zones.push_back(std::move(z));
    }
    if (s->zones.empty()) return fail();
    SampleSet* expected = nullptr;
    if (!sets[set].compare_exchange_strong(expected, s)) { delete s; return false; }
    return true;
}

// ---------- sinte de primos: armónicos n cuyos factores primos están todos en la selección ----------
void Synth::buildPrimes(uint32_t primeMask, int maxHarm, float slope) {
    static const int PR[11] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31};
    maxHarm = std::clamp(maxHarm, 1, 256);
    std::vector<int> harm;
    for (int n = 1; n <= maxHarm; n++) {
        int m = n;
        for (int k = 0; k < 11; k++)
            if (primeMask & (1u << k)) while (m % PR[k] == 0) m /= PR[k];
        if (m == 1) harm.push_back(n);
    }
    const int target = 1 - primeActive.load();
    float (*T)[TBL + 1] = primeTables[target];
    float norm = 0;
    for (int L = 0; L < NLEV; L++) {
        const double ftop = 40.0 * std::pow(2.0, L);
        for (int i = 0; i <= TBL; i++) {
            const double ph = 2.0 * M_PI * i / TBL;
            double s = 0;
            for (int n : harm) {
                if (n * ftop > 20000.0 && n > 1) break;
                s += std::pow((double)n, -slope) * std::sin(n * ph + 0.61803 * n * n);
            }
            T[L][i] = (float)s;
        }
        if (L == 0) for (int i = 0; i <= TBL; i++) norm = std::max(norm, std::fabs(T[0][i]));
    }
    if (norm <= 0) norm = 1;
    for (int L = 0; L < NLEV; L++) for (int i = 0; i <= TBL; i++) T[L][i] /= norm;
    primeActive.store(target);
}

float Synth::rnd() {
    rng = rng * 1664525u + 1013904223u;
    return (float)(rng >> 8) / 16777216.f;
}

void Synth::handle(const Ev& e) {
    if (e.kind == 0) { midi(e.a, e.b, e.c); return; }
    Preset& cur = PRESETS[preset];
    switch (e.a) {
        case P_PRESET: preset = std::clamp((int)e.v, 0, NPRESETS - 1); break;
        case P_VOLUME: volume = e.v; break;
        case P_REVERB_MIX: if (revMix == 0 && e.v > 0) clearReverb(); revMix = e.v; break;
        case P_REVERB_SIZE: revFb = .70f + std::clamp(e.v, 0.f, 1.f) * .25f; break;
        case P_BEND_NOTE: for (int c = 1; c < 16; c++) { range[c] = e.v; updBend(c); } break;
        case P_BEND_GLOBAL: range[0] = e.v; updBend(0); break;
        case P_PANIC: sustain = false; allOff(-1); break;
        case P_ATTACK: cur.a = std::max(.001f, e.v); break;
        case P_DECAY: cur.d = std::max(.01f, e.v); break;
        case P_SUSTAIN: cur.s = std::clamp(e.v, 0.f, 1.f); break;
        case P_RELEASE: cur.r = std::max(.005f, e.v); break;
        case P_MOD_DEST: modDest = (int)e.v; break;
        case P_LFO_RATE: lfoRate = e.v; break;
        case P_VIB_DEPTH: vibDepth = e.v; break;
        case P_DELAY_MIX:
            if (dlyMix == 0 && e.v > 0) { std::fill(dlyL.begin(), dlyL.end(), 0.f); std::fill(dlyR.begin(), dlyR.end(), 0.f); }
            dlyMix = e.v; break;
        case P_DELAY_TIME: dlyTime = std::clamp(e.v, .02f, 2.f); break;
        case P_DELAY_FB: dlyFb = std::clamp(e.v, 0.f, .92f); break;
    }
}

void Synth::midi(uint8_t s, uint8_t a, uint8_t b) {
    const int st = s & 0xF0, ch = s & 0x0F;
    switch (st) {
        case 0x90: if (b) noteOn(ch, a, b); else noteOff(ch, a); break;
        case 0x80: noteOff(ch, a); break;
        case 0xE0: bendRaw[ch] = ((b << 7) | a) - 8192; updBend(ch); break;
        case 0xB0: cc(ch, a, b); break;
    }
}

void Synth::updBend(int ch) { bend[ch] = bendRaw[ch] / 8192.f * range[ch] * 100.f; }

void Synth::cc(int ch, int n, int val) {
    switch (n) {
        case 1: mod = val / 127.f; break;
        case 64: {
            const bool on = val >= 64;
            if (sustain && !on)
                for (auto& x : v) if (x.on && x.sus) { x.sus = false; x.rel = true; }
            sustain = on;
            break;
        }
        case 101: rpnM[ch] = (uint8_t)val; break;
        case 100: rpnL[ch] = (uint8_t)val; break;
        case 6:
            if (rpnM[ch] == 0 && rpnL[ch] == 0) {
                range[ch] = (float)val;
                updBend(ch);
                if (ch != 0 || rpnSeen.load() < 0) rpnSeen.store(val);
            }
            break;
        case 121: bendRaw[ch] = 0; updBend(ch); if (ch == 0) mod = 0; break;
        case 120: case 123: allOff(ch); break;
    }
}

Voice& Synth::allocVoice() {
    Voice* s = nullptr;
    for (auto& x : v) if (!x.on) { s = &x; break; }
    if (!s) for (auto& x : v) if (x.rel && (!s || x.env < s->env)) s = &x;
    if (!s) for (auto& x : v) if (!s || x.age < s->age) s = &x;
    *s = Voice();
    return *s;
}

void Synth::noteOn(int ch, int note, int vel) {
    const Preset& p = PRESETS[preset];
    SampleSet* set = p.sampleSet >= 0 ? sets[p.sampleSet].load() : nullptr;
    if (p.sampleSet >= 0 && (!set || set->zones.empty())) return;   // samples aún cargando
    if (p.sf2 && !sfCur) return;                                     // ningún SoundFont elegido

    for (auto& x : v) if (x.on && !x.rel && x.ch == ch && x.note == note) { x.rel = true; x.sus = false; }
    const float velCurve = .35f + .65f * std::pow(vel / 127.f, 1.4f);   // SoundFont
    const float chanCents = ch != 0 ? bend[ch] : 0.f;

    if (p.sf2) {   // una voz por cada zona que cubre la tecla y la velocidad (capas, estéreo…)
        int made = 0;
        for (const SfRegion& r : sfCur->regions) {
            if (note < r.keyLo || note > r.keyHi || vel < r.velLo || vel > r.velHi) continue;
            if (++made > 6) break;
            Voice& x = allocVoice();
            x.on = true; x.ch = (uint8_t)ch; x.note = (uint8_t)note; x.age = ++ageCounter; x.p = &p;
            x.reg = &r; x.bank = sfCur;
            x.f = 440.f;
            x.chanCents = chanCents;
            x.sfCents = r.scale * note + r.offset;
            x.pos = r.start;
            x.peak = .2f * velCurve * r.gain * 1.4f;
            x.va = std::max(r.attack, .0015f);
            x.vh = r.hold > 0 ? r.hold * std::exp2(r.keyToHold * (60 - note) / 1200.f) : 0.f;
            x.vs = r.sustain;
            const float dec = r.decay * std::exp2(r.keyToDecay * (60 - note) / 1200.f);
            x.dCoef = std::exp(-11.05f / (sr * std::max(dec, .001f)));
            x.rCoef = std::exp(-11.05f / (sr * std::max(r.release, .005f)));
        }
        return;
    }

    Voice& x = allocVoice();
    const float v = vel / 127.f;
    const float kd = std::exp2(-p.keyDecay * (note - 60) / 12.f);   // agudos: caída más corta
    x.on = true; x.ch = (uint8_t)ch; x.note = (uint8_t)note; x.age = ++ageCounter; x.p = &p;
    x.f = 440.f * std::exp2((note - 69) / 12.f);
    x.chanCents = chanCents;
    x.vel = v;
    x.peak = .2f * ((1.f - p.velAmp) + p.velAmp * std::pow(v, 1.4f)) * p.gain;
    x.va = p.a; x.vh = 0; x.vs = p.s;
    x.dCoef = std::exp(-1.f / (sr * p.d * kd / 3.f));
    x.rCoef = std::exp(-1.f / (sr * p.r / 4.f));
    x.filtMul = std::exp2(p.velFilt * (v - .7f) * 2.f);
    x.noise = ageCounter * 2654435761u + 12345u;

    if (set) {
        // zona más cercana a la frecuencia que va a sonar
        const float target = x.f * std::exp2((x.chanCents + globalCents()) / 1200.f);
        float best = 1e9f;
        for (const Zone& z : set->zones) {
            float dist = std::fabs(std::log2(target / z.freq));
            if (dist < best) { best = dist; x.zone = &z; }
        }
        x.zoneSr = set->sr;
        return;
    }
    for (int k = 0; k < p.n; k++) {
        const OscDef& d = p.o[k];
        OscState& o = x.o[k];
        o.ph = (d.w == SAW || d.w == SQUARE) ? rnd() : 0.0;
        o.ratioMul = d.ratio * std::exp2(d.cents / 1200.f);
        o.level = d.level;
        o.lvlCoef = d.levelTau > 0 ? std::exp(-1.f / (sr * d.levelTau * kd)) : 1.f;
        const float vf = std::max(.05f, 1.f + d.velFm * (v - .67f) * 1.5f);   // más fuerte, más brillo
        o.fm = d.fmPeak * vf;
        o.fmSus = d.fmSus * vf;
        o.fmCoef = d.fmTau > 0 ? std::exp(-1.f / (sr * d.fmTau * kd)) : 1.f;
    }
}

void Synth::noteOff(int ch, int note) {
    for (auto& x : v)   // todas las voces de la nota (un SoundFont puede usar varias)
        if (x.on && !x.rel && !x.sus && x.ch == ch && x.note == note) {
            if (sustain) x.sus = true; else x.rel = true;
        }
}

void Synth::allOff(int ch) {
    const float fast = std::exp(-1.f / (sr * .004f));
    for (auto& x : v)
        if (x.on && (ch < 0 || x.ch == ch)) { x.rel = true; x.sus = false; x.rCoef = std::min(x.rCoef, fast); }
}

void Synth::reverb(float x, float& l, float& r) {
    const float in = x * .05f, damp = .3f;
    float o[2] = {0, 0};
    for (int i = 0; i < 8; i++) {
        auto& b = comb[i];
        float y = b[combIdx[i]];
        combStore[i] = y * (1 - damp) + combStore[i] * damp;
        b[combIdx[i]] = in + combStore[i] * revFb;
        if (++combIdx[i] >= (int)b.size()) combIdx[i] = 0;
        o[i >= 4] += y;
    }
    for (int i = 0; i < 4; i++) {
        auto& b = ap[i];
        float& s = o[i >= 2];
        float bo = b[apIdx[i]];
        b[apIdx[i]] = s + bo * .5f;
        s = bo - s;
        if (++apIdx[i] >= (int)b.size()) apIdx[i] = 0;
    }
    l = o[0]; r = o[1];
}

static inline void flushDenormals() {
#if defined(__aarch64__)
    uint64_t fpcr;
    asm volatile("mrs %0, fpcr" : "=r"(fpcr));
    asm volatile("msr fpcr, %0" :: "r"(fpcr | (1ull << 24)));
#elif defined(__arm__) && defined(__ARM_FP)
    uint32_t fpscr;
    asm volatile("vmrs %0, fpscr" : "=r"(fpscr));
    asm volatile("vmsr fpscr, %0" :: "r"(fpscr | (1u << 24)));
#endif
}

// ---------- SoundFont: intercambio de bancos sin bloqueos ----------
void Synth::publishBank(SfBank* b) {
    if (SfBank* old = sfPending.exchange(b)) delete old;   // nunca llegó al hilo de audio
}

void Synth::collectBanks() {
    for (auto& f : toFree) if (SfBank* b = f.exchange(nullptr)) delete b;
}

bool Synth::queueFree(SfBank* b) {
    for (auto& f : toFree) { SfBank* e = nullptr; if (f.compare_exchange_strong(e, b)) return true; }
    return false;
}

// Adopta el banco pendiente solo si hay sitio garantizado para retirar el actual:
// ningún banco se pierde sin liberar, aunque se cambie de preset muy deprisa.
void Synth::adoptBank() {
    if (!sfPending.load(std::memory_order_acquire)) return;
    int slot = -1;
    if (sfCur) {
        retireBanks();
        for (int i = 0; i < NRETIRE; i++) if (!retiring[i]) { slot = i; break; }
        if (slot < 0) {   // todos ocupados: corta las voces del más antiguo y lo manda a liberar
            if (!queueFree(retiring[0])) return;   // la interfaz aún no ha recogido: se reintenta en el siguiente bloque
            for (auto& x : v) if (x.on && x.bank == retiring[0]) x.on = false;
            retiring[0] = nullptr;
            slot = 0;
        }
    }
    SfBank* p = sfPending.exchange(nullptr);
    if (!p) return;
    if (sfCur) retiring[slot] = sfCur;
    sfCur = p;
}

void Synth::retireBanks() {
    for (auto& r : retiring) {
        if (!r) continue;
        bool used = false;
        for (auto& x : v) if (x.on && x.bank == r) { used = true; break; }
        if (!used && queueFree(r)) r = nullptr;
    }
}

Synth::~Synth() {
    delete sfPending.exchange(nullptr);
    delete sfCur;
    for (auto r : retiring) delete r;
    collectBanks();
}

// ---------- notas pulsadas para la interfaz (seqlock) ----------
void Synth::publishHeld() {
    int n = 0;
    float tmp[MAXHELD];
    uint16_t seen[MAXHELD];
    for (auto& x : v) {
        if (!x.on || x.rel || x.sus || n >= MAXHELD) continue;
        const uint16_t key = (uint16_t)(x.ch << 8 | x.note);
        bool dup = false;
        for (int i = 0; i < n; i++) if (seen[i] == key) { dup = true; break; }
        if (dup) continue;
        seen[n] = key;
        tmp[n++] = x.note * 100.f + x.chanCents + bend[0];
    }
    heldSeq.fetch_add(1, std::memory_order_acq_rel);
    for (int i = 0; i < n; i++) {
        heldBuf[i].store(tmp[i], std::memory_order_relaxed);
        heldKey[i].store(seen[i], std::memory_order_relaxed);
    }
    heldN.store(n, std::memory_order_relaxed);
    heldSeq.fetch_add(1, std::memory_order_release);
}

int Synth::readHeld(float* out, int* keys, int max) {
    for (int tries = 0; tries < 8; tries++) {
        const uint32_t s1 = heldSeq.load(std::memory_order_acquire);
        if (s1 & 1) continue;
        int n = std::min(heldN.load(std::memory_order_relaxed), max);
        for (int i = 0; i < n; i++) {
            out[i] = heldBuf[i].load(std::memory_order_relaxed);
            if (keys) keys[i] = heldKey[i].load(std::memory_order_relaxed);
        }
        std::atomic_thread_fence(std::memory_order_acquire);
        if (heldSeq.load(std::memory_order_relaxed) == s1) return n;
    }
    return 0;
}

void Synth::render(float* out, int frames) {
    flushDenormals();
    adoptBank();
    Ev e;
    while (q.pop(e)) handle(e);
    int done = 0;
    while (done < frames) {
        const int m = std::min(BLK, frames - done);
        block(out + 2 * done, m);
        done += m;
    }
    uint32_t mask = 0;
    int count = 0;
    for (auto& x : v) {
        if (!x.on) continue;
        count++;
        if (!x.rel) mask |= 1u << x.ch;
    }
    chanMask.store(mask, std::memory_order_relaxed);
    voicesOn.store(count, std::memory_order_relaxed);
    wheelOut.store(bend[0], std::memory_order_relaxed);
    modOut.store(mod, std::memory_order_relaxed);
    retireBanks();
    publishHeld();
}

static inline float hermite(const int16_t* d, int i, float fr) {
    const float k = 1.f / 32768.f;
    float y0 = d[i - 1] * k, y1 = d[i] * k, y2 = d[i + 1] * k, y3 = d[i + 2] * k;
    float c1 = .5f * (y2 - y0);
    float c2 = y0 - 2.5f * y1 + 2.f * y2 - .5f * y3;
    float c3 = .5f * (y3 - y0) + 1.5f * (y1 - y2);
    return ((c3 * fr + c2) * fr + c1) * fr + y1;
}

static inline void svfCoefs(float fc, float q, float sr, float& a1, float& a2, float& a3) {
    float g = std::tan((float)M_PI * std::min(fc, sr * .45f) / sr), k = 1.f / q;
    a1 = 1.f / (1.f + g * (g + k)); a2 = g * a1; a3 = g * a2;
}

// Envolvente común: ataque lineal, mantenimiento, caída exponencial hacia el sostenido
static inline void envStep(Voice& x, float target) {
    if (x.rel) x.env *= x.rCoef;
    else if (x.t < x.va) x.env = x.peak * (x.t / x.va);
    else if (x.t < x.va + x.vh) x.env = x.peak;
    else x.env = target + (x.env - target) * x.dCoef;
}

void Synth::block(float* out, int m) {
    float mix[BLK] = {0};
    const float bdt = dt * m;
    const float smooth = 1.f - std::exp(-bdt / .003f);
    const float lfo = std::sin((float)(lfoPh * 2.0 * M_PI));
    lfoPh += lfoRate * bdt;
    if (lfoPh >= 1.0) lfoPh -= 1.0;
    const float vib = modDest == 0 ? lfo * vibDepth * mod : 0.f;
    const float trem = modDest == 1 ? 1.f - mod * .6f * (.5f + .5f * lfo) : 1.f;
    const float gCents = globalCents();
    const float* primeTable = nullptr;
    const int pa = primeActive.load(std::memory_order_acquire);

    for (auto& x : v) {
        if (!x.on) continue;
        const Preset& p = *x.p;

        // Parte de la nota: sigue su canal mientras está pulsada, se congela al soltar.
        // La rueda de pitch bend (canal 1, gestor MPE) afecta siempre a todas las notas.
        if (!x.rel && !x.sus && x.ch != 0) {
            if (x.t < .01f) x.chanCents = bend[x.ch];
            else x.chanCents += (bend[x.ch] - x.chanCents) * smooth;
        }
        const float target = x.peak * x.vs;

        if (x.reg) {  // ---- voz de SoundFont
            const SfRegion& r = *x.reg;
            const int16_t* d = x.bank->file->smpl;
            double step = std::exp2((double)(x.sfCents + x.chanCents + gCents + vib) / 1200.0) * (r.srcRate / sr);
            if (!(step > 1e-4 && step < 64.0)) step = step >= 64.0 ? 64.0 : 1e-4;   // incluye NaN
            float a1 = 0, a2 = 0, a3 = 0;
            if (r.filterHz > 0) svfCoefs(r.filterHz, r.filterQ, sr, a1, a2, a3);
            const bool looping = r.loopMode == 1 || (r.loopMode == 3 && !x.rel);
            const double loopLen = (double)r.loopEnd - r.loopStart;
            for (int i = 0; i < m; i++) {
                // en bucle se vuelve atrás antes de llegar al final; sin bucle, la muestra termina
                if (looping) { while (x.pos >= r.loopEnd) x.pos -= loopLen; }
                else if (x.pos >= r.end - 1) { x.on = false; break; }
                const int ip = (int)x.pos;
                const float fr = (float)(x.pos - ip);
                float y = ip >= 1 ? hermite(d, ip, fr) : (d[ip] + (d[ip + 1] - d[ip]) * fr) * (1.f / 32768.f);
                x.pos += step;
                if (r.filterHz > 0) {
                    float v3 = y - x.ic2;
                    float v1 = a1 * x.ic1 + a2 * v3;
                    float v2 = x.ic2 + a2 * x.ic1 + a3 * v3;
                    x.ic1 = 2 * v1 - x.ic1;
                    x.ic2 = 2 * v2 - x.ic2;
                    y = v2;
                }
                envStep(x, target);
                mix[i] += y * x.env;
                x.t += dt;
            }
            if ((x.rel || x.vs <= 0) && x.t > x.va + x.vh && x.env < 1e-5f) x.on = false;
            continue;
        }

        const float base = x.f * std::exp2((x.chanCents + gCents + vib) / 1200.f);

        if (x.zone) {  // ---- voz sampleada
            const Zone& z = *x.zone;
            const int n = (int)z.data.size();
            double step = (double)(base / z.freq) * (x.zoneSr / sr);
            if (!(step > 1e-4 && step < 64.0)) step = step >= 64.0 ? 64.0 : 1e-4;
            const int16_t* d = z.data.data();
            const bool looped = z.loopEnd > z.loopStart + 8 && z.loopEnd <= (uint32_t)n - 3;
            const double loopLen = (double)z.loopEnd - z.loopStart;
            for (int i = 0; i < m; i++) {
                if (looped) { while (x.pos >= z.loopEnd) x.pos -= loopLen; }
                int ip = (int)x.pos;
                if (ip >= n - 3) { x.on = false; break; }
                float y = ip >= 1 ? hermite(d, ip, (float)(x.pos - ip)) : d[ip] * (1.f / 32768.f);
                x.pos += step;
                envStep(x, target);
                mix[i] += y * x.env;
                x.t += dt;
            }
            if (x.rel && x.env < 1e-5f) x.on = false;
            continue;
        }

        // ---- voz sintetizada
        if (p.o[0].w == PRIMES) {
            int L = (int)std::ceil(std::log2(std::max(base, 1.f) / 40.f));
            primeTable = primeTables[pa][std::clamp(L, 0, NLEV - 1)];
        }
        float a1 = 0, a2 = 0, a3 = 0;
        if (p.filt) {
            float r = p.fTau > 0 ? p.fEnd + (p.fStart - p.fEnd) * std::exp(-x.t / p.fTau) : p.fEnd;
            svfCoefs(base * r * x.filtMul, p.q, sr, a1, a2, a3);
        }
        const bool pickup = p.pickDrive > 0;
        const float pickNorm = pickup ? 1.f / std::tanh(p.pickDrive) : 0.f;
        const float tineScale = pickup ? (.1f + .9f * x.vel * std::sqrt(x.vel)) / std::max(x.peak, 1e-6f) : 0.f;
        const float baseInc = base * dt;
        float inc[MAXOSC];
        for (int k = 0; k < p.n; k++) inc[k] = baseInc * x.o[k].ratioMul;

        for (int i = 0; i < m; i++) {
            float fmIn[MAXOSC] = {}, sum = 0;
            for (int k = 0; k < p.n; k++) {
                const OscDef& d = p.o[k];
                if (d.fmTarget < 0) continue;
                OscState& o = x.o[k];
                fmIn[d.fmTarget] += wave(d.w, o.ph, inc[k], primeTable, d.width) * o.fm * baseInc;
                o.fm = o.fmSus + (o.fm - o.fmSus) * o.fmCoef;
            }
            for (int k = 0; k < p.n; k++) {
                const OscDef& d = p.o[k];
                if (d.fmTarget >= 0) continue;
                OscState& o = x.o[k];
                float y;
                if (d.w == NOISE) { x.noise = x.noise * 1664525u + 1013904223u; y = (float)(int32_t)x.noise * (1.f / 2147483648.f); }
                else y = wave(d.w, o.ph, inc[k] + fmIn[k], primeTable, d.width);
                sum += y * o.level;
                o.level *= o.lvlCoef;
            }
            if (p.filt) {
                float v3 = sum - x.ic2;
                float v1 = a1 * x.ic1 + a2 * v3;
                float v2 = x.ic2 + a2 * x.ic1 + a3 * v3;
                x.ic1 = 2 * v1 - x.ic1;
                x.ic2 = 2 * v2 - x.ic2;
                sum = v2;
            }
            envStep(x, target);
            if (pickup) {
                // pastilla magnética: la lámina se mueve con la envolvente y la no linealidad
                // añade armónicos que crecen con la fuerza del golpe y se apagan con la nota
                const float tine = sum * x.env * tineScale;
                float y = std::tanh(p.pickDrive * (tine + p.pickAsym * tine * tine)) * pickNorm;
                const float dc = y - x.dcX + .995f * x.dcY;
                x.dcX = y; x.dcY = dc;
                mix[i] += dc * x.peak;
            } else {
                mix[i] += sum * x.env;
            }
            x.t += dt;
        }
        if ((x.rel || x.vs == 0) && x.t > x.va && x.env < 1e-5f) x.on = false;
    }

    // Filtro de la rueda de modulación (cierra hasta ~280 Hz con la rueda al máximo)
    const float wantCut = modDest == 2 ? std::exp2(-mod * 6.f) : 1.f;
    modCut += (wantCut - modCut) * smooth;
    const bool useLp = modCut < .999f;
    float la1 = 0, la2 = 0, la3 = 0;
    if (useLp) svfCoefs(18000.f * modCut, .7071f, sr, la1, la2, la3);

    // efectos propios del timbre activo (se mueven suavemente al cambiar de timbre)
    const Preset& cur = PRESETS[preset];
    const float fxk = 1.f - std::exp(-bdt / .15f);
    chAmt += (cur.chorus - chAmt) * fxk;
    panDp += (cur.panDepth - panDp) * fxk;
    if (cur.panRate > 0) panRt = cur.panRate;
    const int chN = (int)chBuf.size();

    // nivelador lento: sube con la densidad, pero cada vez menos
    // relación 3:1 con rodilla suave de 6 dB
    float gWant = 1.f;
    {
        const float lvl = 10.f * std::log10(levEnv + 1e-12f);
        const float over = lvl + 7.f, knee = 6.f, slope = 1.f / 3.f - 1.f;   // umbral -7 dBFS RMS
        float gr = 0.f;
        if (over > knee / 2) gr = slope * over;
        else if (over > -knee / 2) gr = slope * (over + knee / 2) * (over + knee / 2) / (2 * knee);
        gWant = std::pow(10.f, gr / 20.f);
    }
    const float g0 = levGain;
    levGain += (gWant - levGain) * (1.f - std::exp(-bdt / (gWant < levGain ? .03f : .3f)));
    const float aAvg = 1.f - std::exp(-dt / .05f);   // potencia media real (no sigue los picos)

    const float dlyS = 1.f - std::exp(-bdt / .08f);
    const float makeup = 3.7f;
    for (int i = 0; i < m; i++) {
        float s = mix[i] * volume * makeup * trem;
        if (useLp) {
            float v3 = s - mlpB;
            float v1 = la1 * mlpL + la2 * v3;
            float v2 = mlpB + la2 * mlpL + la3 * v3;
            mlpL = 2 * v1 - mlpL;
            mlpB = 2 * v2 - mlpB;
            s = v2;
        } else { mlpL = mlpB = 0; }

        float L = s, R = s;
        if (chAmt > .002f && chN > 0) {   // chorus estéreo: dos líneas de retardo moduladas
            chBuf[chIdx] = s;
            const float lfoA = (float)std::sin(chPh * 2.0 * M_PI), lfoB = (float)std::sin(chPh * 2.0 * M_PI * 1.37 + 1.7);
            auto tap = [&](float ms) {
                float rp = (float)chIdx - ms * .001f * sr;
                while (rp < 0) rp += chN;
                int i0 = (int)rp; float fr = rp - i0;
                if (i0 >= chN) { i0 -= chN; fr = 0; }   // redondeo de coma flotante en el borde
                int i1 = i0 + 1 >= chN ? 0 : i0 + 1;
                return chBuf[i0] + (chBuf[i1] - chBuf[i0]) * fr;
            };
            const float ta = tap(11.f + 3.f * lfoA), tb = tap(13.f + 3.f * lfoB);
            L = s * (1.f - .35f * chAmt) + ta * .75f * chAmt;
            R = s * (1.f - .35f * chAmt) + tb * .75f * chAmt;
            if (++chIdx >= chN) chIdx = 0;
            chPh += .55 * dt;
            if (chPh >= 1.0) chPh -= 1.0;
        }
        if (panDp > .002f) {   // trémolo estéreo (vaivén del Rhodes de maleta)
            const float sp = (float)std::sin(panPh * 2.0 * M_PI) * panDp;
            L *= 1.f + sp; R *= 1.f - sp;
            panPh += panRt * dt;
            if (panPh >= 1.0) panPh -= 1.0;
        }
        if (dlyMix > 0) {  // delay ping-pong estéreo
            dlyTimeS += (dlyTime - dlyTimeS) * dlyS / m;
            const int n = (int)dlyL.size();
            float rp = (float)dlyIdx - dlyTimeS * sr;
            while (rp < 0) rp += n;
            int i0 = (int)rp; float fr = rp - i0;
            if (i0 >= n) { i0 -= n; fr = 0; }   // redondeo de coma flotante en el borde
            int i1 = i0 + 1 >= n ? 0 : i0 + 1;
            float yl = dlyL[i0] + (dlyL[i1] - dlyL[i0]) * fr;
            float yr = dlyR[i0] + (dlyR[i1] - dlyR[i0]) * fr;
            dlyLpL += (yl - dlyLpL) * .45f;
            dlyLpR += (yr - dlyLpR) * .45f;
            dlyL[dlyIdx] = s + dlyLpR * dlyFb;
            dlyR[dlyIdx] = dlyLpL * dlyFb;
            if (++dlyIdx >= n) dlyIdx = 0;
            L += yl * dlyMix;
            R += yr * dlyMix;
        }
        if (revMix > 0) {
            float rl, rr;
            reverb(s, rl, rr);
            L += rl * revMix;
            R += rr * revMix;
        }
        // detector de energía del nivelador
        const float pw = .5f * (L * L + R * R);
        levEnv += (pw - levEnv) * aAvg;
        const float g = g0 + (levGain - g0) * (i + 1) / m;
        master(L * g, R * g, out[2 * i], out[2 * i + 1]);
    }
}

// Control de picos con anticipación: la salida va retrasada BLK muestras y la ganancia empieza a
// bajar antes de que llegue el pico. Garantiza |salida| <= techo sin recortar la forma de onda.
void Synth::master(float L, float R, float& outL, float& outR) {
    const float ceiling = .97f;
    float pk = std::max(std::fabs(L), std::fabs(R));
    if (!(pk == pk)) { L = R = 0; pk = 0; }   // NaN: silencio
    qRing[qIdx] = pk > ceiling ? ceiling / pk : 1.f;
    if (++qIdx > BLK) qIdx = 0;
    float q = 1.f;
    for (float v : qRing) q = std::min(q, v);              // mínimo de la ventana
    mSum += q - mRing[mIdx];                                // media móvil del mínimo
    mRing[mIdx] = q;
    if (++mIdx >= BLK) mIdx = 0;
    const float gm = std::min(1.f, mSum / BLK);
    gRel = gm < gRel ? gm : gRel + (gm - gRel) * .0000208f;   // recuperación lenta (~1 s): sin bombeo
    const float dl = lookL[lookIdx], dr = lookR[lookIdx];
    lookL[lookIdx] = L; lookR[lookIdx] = R;
    if (++lookIdx >= BLK) lookIdx = 0;
    outL = std::clamp(dl * gRel, -ceiling, ceiling);
    outR = std::clamp(dr * gRel, -ceiling, ceiling);
}

}  // namespace rusc
