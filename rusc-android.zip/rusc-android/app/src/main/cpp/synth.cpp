#include "synth.h"
#include <algorithm>
#include <cmath>
#include <cstring>

namespace rusc {

static constexpr int TBL = Synth::TBL;
static float tables[6][TBL + 1];
static bool tablesReady = false;

static void buildTable(float* t, const std::vector<float>& h) {
    float mx = 0;
    for (int i = 0; i <= TBL; i++) {
        double ph = 2.0 * M_PI * i / TBL, s = 0;
        for (size_t k = 0; k < h.size(); k++) s += h[k] * std::sin(ph * (double)(k + 1));
        t[i] = (float)s;
        mx = std::max(mx, std::fabs(t[i]));
    }
    for (int i = 0; i <= TBL; i++) t[i] /= mx;
}

static void initTables() {
    if (tablesReady) return;
    buildTable(tables[SINE], {1});
    std::vector<float> tri;
    for (int k = 1; k <= 31; k++)
        tri.push_back(k % 2 ? (((k / 2) % 2) ? -1.f : 1.f) / (float)(k * k) : 0.f);
    buildTable(tables[TRI], tri);
    buildTable(tables[ORGAN], {1, .7f, .45f, .35f, 0, .2f, 0, .12f});
    buildTable(tables[REED], {1, 0, .55f, 0, .32f, 0, .2f, 0, .12f, 0, .07f});
    tablesReady = true;
}

static Preset makePreset(int i) {
    Preset p;
    switch (i) {
        case 0:  // piano eléctrico
            p.n = 3;
            p.o[0] = {SINE, 1, 0, 1};
            p.o[1] = {SINE, 1, 0, 0, 0, 0, 2.2f, .25f, .35f};
            p.o[2] = {SINE, 14, 0, 0, 0, 0, 1.2f, 0, .015f};
            p.a = .002f; p.d = 3; p.s = 0; p.r = .3f;
            break;
        case 1:  // órgano
            p.o[0] = {ORGAN, 1, 0, 1};
            p.a = .005f; p.d = .1f; p.s = 1; p.r = .06f; p.gain = .7f;
            break;
        case 2:  // pulsado
            p.n = 2;
            p.o[0] = {SAW, 1, 0, 1};
            p.o[1] = {SQUARE, 1, 4, .4f};
            p.filt = true; p.fStart = 14; p.fEnd = 1.6f; p.fTau = .12f; p.q = 1.2f;
            p.a = .002f; p.d = 1.8f; p.s = 0; p.r = .15f;
            break;
        case 3:  // pad cálido
            p.n = 3;
            p.o[0] = {SAW, 1, -7, 1};
            p.o[1] = {SAW, 1, 7, 1};
            p.o[2] = {TRI, .5f, 0, .5f};
            p.filt = true; p.fStart = 3; p.fEnd = 3; p.q = .6f;
            p.a = .45f; p.d = 1.5f; p.s = .8f; p.r = 1.4f; p.gain = .8f;
            break;
        case 4:  // cuerdas
            p.n = 3;
            p.o[0] = {SAW, 1, -11, .45f};
            p.o[1] = {SAW, 1, 0, .45f};
            p.o[2] = {SAW, 1, 9, .45f};
            p.filt = true; p.fStart = 2; p.fEnd = 5; p.fTau = .25f; p.q = .65f;
            p.a = .14f; p.d = .6f; p.s = .9f; p.r = .45f; p.gain = .8f;
            break;
        case 5:  // caña
            p.o[0] = {REED, 1, 0, 1};
            p.filt = true; p.fStart = 2; p.fEnd = 6; p.fTau = .04f; p.q = .7f;
            p.a = .035f; p.d = .2f; p.s = .85f; p.r = .08f;
            break;
        case 6:  // campana
            p.n = 3;
            p.o[0] = {SINE, 1, 0, 1};
            p.o[1] = {SINE, 3.5f, 0, 0, 0, 0, 3, .3f, .8f};
            p.o[2] = {SINE, 2.01f, 0, .25f};
            p.a = .002f; p.d = 6; p.s = 0; p.r = 1.5f; p.gain = .8f;
            break;
        case 7:  // marimba
            p.n = 3;
            p.o[0] = {SINE, 1, 0, 1};
            p.o[1] = {SINE, 3.93f, 0, .35f, .04f};
            p.o[2] = {SINE, 9.2f, 0, .12f, .015f};
            p.a = .001f; p.d = 1.2f; p.s = 0; p.r = .15f;
            break;
        case 8:  // kalimba
            p.n = 3;
            p.o[0] = {SINE, 1, 0, 1};
            p.o[1] = {SINE, 7, 0, 0, 0, 0, 1.6f, 0, .012f};
            p.o[2] = {SINE, 5.4f, 0, .15f, .08f};
            p.a = .001f; p.d = 1.6f; p.s = 0; p.r = .2f;
            break;
        case 9:  // sierra
            p.o[0] = {SAW, 1, 0, 1};
            p.a = .004f; p.d = .1f; p.s = 1; p.r = .06f; p.gain = .75f;
            break;
        case 10:  // bajo
            p.n = 2;
            p.o[0] = {SAW, 1, 0, 1};
            p.o[1] = {SQUARE, .5f, 0, .5f};
            p.filt = true; p.fStart = 6; p.fEnd = 2; p.fTau = .08f; p.q = .9f;
            p.a = .003f; p.d = .6f; p.s = .6f; p.r = .12f;
            break;
        case 11:  // seno
            p.o[0] = {SINE, 1, 0, 1};
            p.a = .006f; p.d = .1f; p.s = 1; p.r = .08f;
            break;
        case 12:  // sinte de primos
            p.o[0] = {PRIMES, 1, 0, 1};
            p.a = .01f; p.d = .4f; p.s = .8f; p.r = .3f; p.gain = .9f;
            break;
        case Synth::SF2_PRESET:
            p.sf2 = true;
            p.a = .001f; p.d = 1; p.s = 1; p.r = .05f;
            break;
        default: {  // sampleados: piano, arpa, clavecín, vibráfono, marimba, kalimba, campanas, đàn tranh
            static const float rel[Synth::NSETS] = {.35f, .5f, .12f, 1.2f, .3f, .6f, 2.f, .5f};
            p.sampleSet = i - 13;
            p.a = .001f; p.d = 20; p.s = 1; p.r = rel[p.sampleSet]; p.gain = 1.3f;
            break;
        }
    }
    return p;
}

static Preset PRESETS[Synth::NPRESETS];
static Preset DEFAULTS[Synth::NPRESETS];

float Synth::presetDefault(int preset, int which) {
    const Preset p = makePreset(std::clamp(preset, 0, NPRESETS - 1));
    switch (which) { case 0: return p.a; case 1: return p.d; case 2: return p.s; default: return p.r; }
}

static inline float blep(float t, float dt) {
    dt = std::fabs(dt);
    if (dt <= 0.f) return 0.f;
    if (t < dt) { t /= dt; return t + t - t * t - 1.f; }
    if (t > 1.f - dt) { t = (t - 1.f) / dt; return t * t + t + t + 1.f; }
    return 0.f;
}

static inline float tableRead(const float* t, float p) {
    float x = p * TBL;
    int i = std::min((int)x, TBL - 1);
    float fr = x - (float)i;
    return t[i] + (t[i + 1] - t[i]) * fr;
}

static inline float wave(Wave w, double& ph, float inc, const float* primeTable) {
    float p = (float)ph, y;
    switch (w) {
        case SAW:
            y = 2.f * p - 1.f - blep(p, inc);
            break;
        case SQUARE: {
            float p2 = p + .5f; if (p2 >= 1.f) p2 -= 1.f;
            y = (p < .5f ? 1.f : -1.f) + blep(p, inc) - blep(p2, inc);
            break;
        }
        case PRIMES:
            y = tableRead(primeTable, p);
            break;
        default:
            y = tableRead(tables[w], p);
    }
    ph += inc;
    ph -= std::floor(ph);
    return y;
}

Synth::Synth() {
    for (int i = 0; i < 16; i++) { range[i] = i == 0 ? 2.f : 48.f; rpnM[i] = rpnL[i] = 127; }
    for (auto& s : sets) s.store(nullptr);
    for (auto& f : toFree) f.store(nullptr);
    for (auto& h : heldBuf) h.store(0.f);
    for (int i = 0; i < NPRESETS; i++) PRESETS[i] = DEFAULTS[i] = makePreset(i);
    buildPrimes(0b111, 32, 1.f);
}

void Synth::init(float sampleRate) {
    initTables();
    sr = sampleRate;
    dt = 1.f / sr;
    for (auto& x : v) x = Voice();
    const int cl[4] = {1116, 1188, 1277, 1356}, al[2] = {556, 441};
    const float sc = sr / 44100.f;
    for (int i = 0; i < 8; i++) comb[i].assign((size_t)((cl[i % 4] + (i >= 4 ? 23 : 0)) * sc), 0.f);
    for (int i = 0; i < 4; i++) ap[i].assign((size_t)((al[i % 2] + (i >= 2 ? 23 : 0)) * sc), 0.f);
    clearReverb();
    dlyL.assign((size_t)(sr * 2.1f), 0.f);
    dlyR.assign((size_t)(sr * 2.1f), 0.f);
    dlyIdx = 0; dlyLpL = dlyLpR = 0;
    mlpL = mlpB = 0;
}

void Synth::clearReverb() {
    for (int i = 0; i < 8; i++) { std::fill(comb[i].begin(), comb[i].end(), 0.f); combIdx[i] = 0; combStore[i] = 0; }
    for (int i = 0; i < 4; i++) { std::fill(ap[i].begin(), ap[i].end(), 0.f); apIdx[i] = 0; }
}

// ---------- samples ----------
bool Synth::loadSamples(int set, const uint8_t* d, int len) {
    if (set < 0 || set >= NSETS || len < 12 || std::memcmp(d, "RSC1", 4) != 0) return false;
    auto* s = new SampleSet();
    uint32_t rate, count;
    std::memcpy(&rate, d + 4, 4);
    std::memcpy(&count, d + 8, 4);
    s->sr = (float)rate;
    int off = 12;
    for (uint32_t i = 0; i < count; i++) {
        if (off + 8 > len) { delete s; return false; }
        Zone z;
        uint32_t n;
        std::memcpy(&z.freq, d + off, 4);
        std::memcpy(&n, d + off + 4, 4);
        off += 8;
        if (off + (int)n * 2 > len) { delete s; return false; }
        z.data.resize(n + 4, 0);   // margen para la interpolación
        std::memcpy(z.data.data(), d + off, n * 2);
        z.data.resize(n);
        off += n * 2;
        s->zones.push_back(std::move(z));
    }
    SampleSet* old = sets[set].exchange(s);
    (void)old;   // solo se carga una vez; nunca se libera mientras suena
    return true;
}

// ---------- sinte de primos: armónicos n cuyos factores primos están todos en la selección ----------
void Synth::buildPrimes(uint32_t primeMask, int maxHarm, float slope) {
    static const int PR[11] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31};
    maxHarm = std::clamp(maxHarm, 1, 256);
    std::vector<int> harm;
    for (int n = 1; n <= maxHarm; n++) {
        int m = n;
        for (int k = 0; k < 11; k++)
            if (primeMask & (1u << k)) while (m % PR[k] == 0) m /= PR[k];
        if (m == 1) harm.push_back(n);
    }
    const int target = 1 - primeActive.load();
    float (*T)[TBL + 1] = primeTables[target];
    float norm = 0;
    for (int L = 0; L < NLEV; L++) {
        const double ftop = 40.0 * std::pow(2.0, L);
        for (int i = 0; i <= TBL; i++) {
            const double ph = 2.0 * M_PI * i / TBL;
            double s = 0;
            for (int n : harm) {
                if (n * ftop > 20000.0 && n > 1) break;
                s += std::pow((double)n, -slope) * std::sin(n * ph + 0.61803 * n * n);
            }
            T[L][i] = (float)s;
        }
        if (L == 0) for (int i = 0; i <= TBL; i++) norm = std::max(norm, std::fabs(T[0][i]));
    }
    if (norm <= 0) norm = 1;
    for (int L = 0; L < NLEV; L++) for (int i = 0; i <= TBL; i++) T[L][i] /= norm;
    primeActive.store(target);
}

float Synth::rnd() {
    rng = rng * 1664525u + 1013904223u;
    return (float)(rng >> 8) / 16777216.f;
}

void Synth::handle(const Ev& e) {
    if (e.kind == 0) { midi(e.a, e.b, e.c); return; }
    Preset& cur = PRESETS[preset];
    switch (e.a) {
        case P_PRESET: preset = std::clamp((int)e.v, 0, NPRESETS - 1); break;
        case P_VOLUME: volume = e.v; break;
        case P_REVERB_MIX: if (revMix == 0 && e.v > 0) clearReverb(); revMix = e.v; break;
        case P_REVERB_SIZE: revFb = .70f + std::clamp(e.v, 0.f, 1.f) * .25f; break;
        case P_BEND_NOTE: for (int c = 1; c < 16; c++) { range[c] = e.v; updBend(c); } break;
        case P_BEND_GLOBAL: range[0] = e.v; updBend(0); break;
        case P_PANIC: sustain = false; allOff(-1); break;
        case P_ATTACK: cur.a = std::max(.001f, e.v); break;
        case P_DECAY: cur.d = std::max(.01f, e.v); break;
        case P_SUSTAIN: cur.s = std::clamp(e.v, 0.f, 1.f); break;
        case P_RELEASE: cur.r = std::max(.005f, e.v); break;
        case P_MOD_DEST: modDest = (int)e.v; break;
        case P_LFO_RATE: lfoRate = e.v; break;
        case P_VIB_DEPTH: vibDepth = e.v; break;
        case P_DELAY_MIX:
            if (dlyMix == 0 && e.v > 0) { std::fill(dlyL.begin(), dlyL.end(), 0.f); std::fill(dlyR.begin(), dlyR.end(), 0.f); }
            dlyMix = e.v; break;
        case P_DELAY_TIME: dlyTime = std::clamp(e.v, .02f, 2.f); break;
        case P_DELAY_FB: dlyFb = std::clamp(e.v, 0.f, .92f); break;
    }
}

void Synth::midi(uint8_t s, uint8_t a, uint8_t b) {
    const int st = s & 0xF0, ch = s & 0x0F;
    switch (st) {
        case 0x90: if (b) noteOn(ch, a, b); else noteOff(ch, a); break;
        case 0x80: noteOff(ch, a); break;
        case 0xE0: bendRaw[ch] = ((b << 7) | a) - 8192; updBend(ch); break;
        case 0xB0: cc(ch, a, b); break;
    }
}

void Synth::updBend(int ch) { bend[ch] = bendRaw[ch] / 8192.f * range[ch] * 100.f; }

void Synth::cc(int ch, int n, int val) {
    switch (n) {
        case 1: mod = val / 127.f; break;
        case 64: {
            const bool on = val >= 64;
            if (sustain && !on)
                for (auto& x : v) if (x.on && x.sus) { x.sus = false; x.rel = true; }
            sustain = on;
            break;
        }
        case 101: rpnM[ch] = (uint8_t)val; break;
        case 100: rpnL[ch] = (uint8_t)val; break;
        case 6:
            if (rpnM[ch] == 0 && rpnL[ch] == 0) {
                range[ch] = (float)val;
                updBend(ch);
                if (ch != 0 || rpnSeen.load() < 0) rpnSeen.store(val);
            }
            break;
        case 121: bendRaw[ch] = 0; updBend(ch); if (ch == 0) mod = 0; break;
        case 120: case 123: allOff(ch); break;
    }
}

Voice& Synth::allocVoice() {
    Voice* s = nullptr;
    for (auto& x : v) if (!x.on) { s = &x; break; }
    if (!s) for (auto& x : v) if (x.rel && (!s || x.env < s->env)) s = &x;
    if (!s) for (auto& x : v) if (!s || x.age < s->age) s = &x;
    *s = Voice();
    return *s;
}

void Synth::noteOn(int ch, int note, int vel) {
    const Preset& p = PRESETS[preset];
    SampleSet* set = p.sampleSet >= 0 ? sets[p.sampleSet].load() : nullptr;
    if (p.sampleSet >= 0 && (!set || set->zones.empty())) return;   // samples aún cargando
    if (p.sf2 && !sfCur) return;                                     // ningún SoundFont elegido

    for (auto& x : v) if (x.on && !x.rel && x.ch == ch && x.note == note) { x.rel = true; x.sus = false; }
    const float velCurve = .35f + .65f * std::pow(vel / 127.f, 1.4f);
    const float chanCents = ch != 0 ? bend[ch] : 0.f;

    if (p.sf2) {   // una voz por cada zona que cubre la tecla y la velocidad (capas, estéreo…)
        int made = 0;
        for (const SfRegion& r : sfCur->regions) {
            if (note < r.keyLo || note > r.keyHi || vel < r.velLo || vel > r.velHi) continue;
            if (++made > 6) break;
            Voice& x = allocVoice();
            x.on = true; x.ch = (uint8_t)ch; x.note = (uint8_t)note; x.age = ++ageCounter; x.p = &p;
            x.reg = &r; x.bank = sfCur;
            x.f = 440.f;
            x.chanCents = chanCents;
            x.sfCents = r.scale * note + r.offset;
            x.pos = r.start;
            x.peak = .2f * velCurve * r.gain * 1.4f;
            x.va = std::max(r.attack, .0015f);
            x.vh = r.hold > 0 ? r.hold * std::exp2(r.keyToHold * (60 - note) / 1200.f) : 0.f;
            x.vs = r.sustain;
            const float dec = r.decay * std::exp2(r.keyToDecay * (60 - note) / 1200.f);
            x.dCoef = std::exp(-11.05f / (sr * std::max(dec, .001f)));
            x.rCoef = std::exp(-11.05f / (sr * std::max(r.release, .005f)));
        }
        return;
    }

    Voice& x = allocVoice();
    x.on = true; x.ch = (uint8_t)ch; x.note = (uint8_t)note; x.age = ++ageCounter; x.p = &p;
    x.f = 440.f * std::exp2((note - 69) / 12.f);
    x.chanCents = chanCents;
    x.peak = .2f * velCurve * p.gain;
    x.va = p.a; x.vh = 0; x.vs = p.s;
    x.dCoef = std::exp(-1.f / (sr * p.d / 3.f));
    x.rCoef = std::exp(-1.f / (sr * p.r / 4.f));

    if (set) {
        // zona más cercana a la frecuencia que va a sonar
        const float target = x.f * std::exp2((x.chanCents + globalCents()) / 1200.f);
        float best = 1e9f;
        for (const Zone& z : set->zones) {
            float dist = std::fabs(std::log2(target / z.freq));
            if (dist < best) { best = dist; x.zone = &z; }
        }
        x.zoneSr = set->sr;
        return;
    }
    for (int k = 0; k < p.n; k++) {
        const OscDef& d = p.o[k];
        OscState& o = x.o[k];
        o.ph = (d.w == SAW || d.w == SQUARE) ? rnd() : 0.0;
        o.ratioMul = d.ratio * std::exp2(d.cents / 1200.f);
        o.level = d.level;
        o.lvlCoef = d.levelTau > 0 ? std::exp(-1.f / (sr * d.levelTau)) : 1.f;
        o.fm = d.fmPeak;
        o.fmSus = d.fmSus;
        o.fmCoef = d.fmTau > 0 ? std::exp(-1.f / (sr * d.fmTau)) : 1.f;
    }
}

void Synth::noteOff(int ch, int note) {
    for (auto& x : v)   // todas las voces de la nota (un SoundFont puede usar varias)
        if (x.on && !x.rel && !x.sus && x.ch == ch && x.note == note) {
            if (sustain) x.sus = true; else x.rel = true;
        }
}

void Synth::allOff(int ch) {
    const float fast = std::exp(-1.f / (sr * .004f));
    for (auto& x : v)
        if (x.on && (ch < 0 || x.ch == ch)) { x.rel = true; x.sus = false; x.rCoef = std::min(x.rCoef, fast); }
}

void Synth::reverb(float x, float& l, float& r) {
    const float in = x * .05f, damp = .3f;
    float o[2] = {0, 0};
    for (int i = 0; i < 8; i++) {
        auto& b = comb[i];
        float y = b[combIdx[i]];
        combStore[i] = y * (1 - damp) + combStore[i] * damp;
        b[combIdx[i]] = in + combStore[i] * revFb;
        if (++combIdx[i] >= (int)b.size()) combIdx[i] = 0;
        o[i >= 4] += y;
    }
    for (int i = 0; i < 4; i++) {
        auto& b = ap[i];
        float& s = o[i >= 2];
        float bo = b[apIdx[i]];
        b[apIdx[i]] = s + bo * .5f;
        s = bo - s;
        if (++apIdx[i] >= (int)b.size()) apIdx[i] = 0;
    }
    l = o[0]; r = o[1];
}

static inline void flushDenormals() {
#if defined(__aarch64__)
    uint64_t fpcr;
    asm volatile("mrs %0, fpcr" : "=r"(fpcr));
    asm volatile("msr fpcr, %0" :: "r"(fpcr | (1ull << 24)));
#elif defined(__arm__) && defined(__ARM_FP)
    uint32_t fpscr;
    asm volatile("vmrs %0, fpscr" : "=r"(fpscr));
    asm volatile("vmsr fpscr, %0" :: "r"(fpscr | (1u << 24)));
#endif
}

// ---------- SoundFont: intercambio de bancos sin bloqueos ----------
void Synth::publishBank(SfBank* b) {
    if (SfBank* old = sfPending.exchange(b)) delete old;   // nunca llegó al hilo de audio
}

void Synth::collectBanks() {
    for (auto& f : toFree) if (SfBank* b = f.exchange(nullptr)) delete b;
}

bool Synth::queueFree(SfBank* b) {
    for (auto& f : toFree) { SfBank* e = nullptr; if (f.compare_exchange_strong(e, b)) return true; }
    return false;
}

// Adopta el banco pendiente solo si hay sitio garantizado para retirar el actual:
// ningún banco se pierde sin liberar, aunque se cambie de preset muy deprisa.
void Synth::adoptBank() {
    if (!sfPending.load(std::memory_order_acquire)) return;
    int slot = -1;
    if (sfCur) {
        retireBanks();
        for (int i = 0; i < NRETIRE; i++) if (!retiring[i]) { slot = i; break; }
        if (slot < 0) {   // todos ocupados: corta las voces del más antiguo y lo manda a liberar
            if (!queueFree(retiring[0])) return;   // la interfaz aún no ha recogido: se reintenta en el siguiente bloque
            for (auto& x : v) if (x.on && x.bank == retiring[0]) x.on = false;
            retiring[0] = nullptr;
            slot = 0;
        }
    }
    SfBank* p = sfPending.exchange(nullptr);
    if (!p) return;
    if (sfCur) retiring[slot] = sfCur;
    sfCur = p;
}

void Synth::retireBanks() {
    for (auto& r : retiring) {
        if (!r) continue;
        bool used = false;
        for (auto& x : v) if (x.on && x.bank == r) { used = true; break; }
        if (!used && queueFree(r)) r = nullptr;
    }
}

Synth::~Synth() {
    delete sfPending.exchange(nullptr);
    delete sfCur;
    for (auto r : retiring) delete r;
    collectBanks();
}

// ---------- notas pulsadas para la interfaz (seqlock) ----------
void Synth::publishHeld() {
    int n = 0;
    float tmp[MAXHELD];
    uint16_t seen[MAXHELD];
    for (auto& x : v) {
        if (!x.on || x.rel || x.sus || n >= MAXHELD) continue;
        const uint16_t key = (uint16_t)(x.ch << 8 | x.note);
        bool dup = false;
        for (int i = 0; i < n; i++) if (seen[i] == key) { dup = true; break; }
        if (dup) continue;
        seen[n] = key;
        tmp[n++] = x.note * 100.f + x.chanCents + bend[0];
    }
    heldSeq.fetch_add(1, std::memory_order_acq_rel);
    for (int i = 0; i < n; i++) heldBuf[i].store(tmp[i], std::memory_order_relaxed);
    heldN.store(n, std::memory_order_relaxed);
    heldSeq.fetch_add(1, std::memory_order_release);
}

int Synth::readHeld(float* out, int max) {
    for (int tries = 0; tries < 8; tries++) {
        const uint32_t s1 = heldSeq.load(std::memory_order_acquire);
        if (s1 & 1) continue;
        int n = std::min(heldN.load(std::memory_order_relaxed), max);
        for (int i = 0; i < n; i++) out[i] = heldBuf[i].load(std::memory_order_relaxed);
        std::atomic_thread_fence(std::memory_order_acquire);
        if (heldSeq.load(std::memory_order_relaxed) == s1) return n;
    }
    return 0;
}

void Synth::render(float* out, int frames) {
    flushDenormals();
    adoptBank();
    Ev e;
    while (q.pop(e)) handle(e);
    int done = 0;
    while (done < frames) {
        const int m = std::min(BLK, frames - done);
        block(out + 2 * done, m);
        done += m;
    }
    uint32_t mask = 0;
    int count = 0;
    for (auto& x : v) {
        if (!x.on) continue;
        count++;
        if (!x.rel) mask |= 1u << x.ch;
    }
    chanMask.store(mask, std::memory_order_relaxed);
    voicesOn.store(count, std::memory_order_relaxed);
    wheelOut.store(bend[0], std::memory_order_relaxed);
    modOut.store(mod, std::memory_order_relaxed);
    retireBanks();
    publishHeld();
}

static inline float hermite(const int16_t* d, int i, float fr) {
    const float k = 1.f / 32768.f;
    float y0 = d[i - 1] * k, y1 = d[i] * k, y2 = d[i + 1] * k, y3 = d[i + 2] * k;
    float c1 = .5f * (y2 - y0);
    float c2 = y0 - 2.5f * y1 + 2.f * y2 - .5f * y3;
    float c3 = .5f * (y3 - y0) + 1.5f * (y1 - y2);
    return ((c3 * fr + c2) * fr + c1) * fr + y1;
}

static inline void svfCoefs(float fc, float q, float sr, float& a1, float& a2, float& a3) {
    float g = std::tan((float)M_PI * std::min(fc, sr * .45f) / sr), k = 1.f / q;
    a1 = 1.f / (1.f + g * (g + k)); a2 = g * a1; a3 = g * a2;
}

// Envolvente común: ataque lineal, mantenimiento, caída exponencial hacia el sostenido
static inline void envStep(Voice& x, float target) {
    if (x.rel) x.env *= x.rCoef;
    else if (x.t < x.va) x.env = x.peak * (x.t / x.va);
    else if (x.t < x.va + x.vh) x.env = x.peak;
    else x.env = target + (x.env - target) * x.dCoef;
}

void Synth::block(float* out, int m) {
    float mix[BLK] = {0};
    const float bdt = dt * m;
    const float smooth = 1.f - std::exp(-bdt / .003f);
    const float lfo = std::sin((float)(lfoPh * 2.0 * M_PI));
    lfoPh += lfoRate * bdt;
    if (lfoPh >= 1.0) lfoPh -= 1.0;
    const float vib = modDest == 0 ? lfo * vibDepth * mod : 0.f;
    const float trem = modDest == 1 ? 1.f - mod * .6f * (.5f + .5f * lfo) : 1.f;
    const float gCents = globalCents();
    const float* primeTable = nullptr;
    const int pa = primeActive.load(std::memory_order_acquire);

    for (auto& x : v) {
        if (!x.on) continue;
        const Preset& p = *x.p;

        // Parte de la nota: sigue su canal mientras está pulsada, se congela al soltar.
        // La rueda de pitch bend (canal 1, gestor MPE) afecta siempre a todas las notas.
        if (!x.rel && !x.sus && x.ch != 0) {
            if (x.t < .01f) x.chanCents = bend[x.ch];
            else x.chanCents += (bend[x.ch] - x.chanCents) * smooth;
        }
        const float target = x.peak * x.vs;

        if (x.reg) {  // ---- voz de SoundFont
            const SfRegion& r = *x.reg;
            const int16_t* d = x.bank->file->smpl;
            double step = std::exp2((double)(x.sfCents + x.chanCents + gCents + vib) / 1200.0) * (r.srcRate / sr);
            if (!(step > 1e-4 && step < 64.0)) step = step >= 64.0 ? 64.0 : 1e-4;   // incluye NaN
            float a1 = 0, a2 = 0, a3 = 0;
            if (r.filterHz > 0) svfCoefs(r.filterHz, r.filterQ, sr, a1, a2, a3);
            const bool looping = r.loopMode == 1 || (r.loopMode == 3 && !x.rel);
            const double loopLen = (double)r.loopEnd - r.loopStart;
            for (int i = 0; i < m; i++) {
                // en bucle se vuelve atrás antes de llegar al final; sin bucle, la muestra termina
                if (looping) { while (x.pos >= r.loopEnd) x.pos -= loopLen; }
                else if (x.pos >= r.end - 1) { x.on = false; break; }
                const int ip = (int)x.pos;
                const float fr = (float)(x.pos - ip);
                float y = ip >= 1 ? hermite(d, ip, fr) : (d[ip] + (d[ip + 1] - d[ip]) * fr) * (1.f / 32768.f);
                x.pos += step;
                if (r.filterHz > 0) {
                    float v3 = y - x.ic2;
                    float v1 = a1 * x.ic1 + a2 * v3;
                    float v2 = x.ic2 + a2 * x.ic1 + a3 * v3;
                    x.ic1 = 2 * v1 - x.ic1;
                    x.ic2 = 2 * v2 - x.ic2;
                    y = v2;
                }
                envStep(x, target);
                mix[i] += y * x.env;
                x.t += dt;
            }
            if ((x.rel || x.vs <= 0) && x.t > x.va + x.vh && x.env < 1e-5f) x.on = false;
            continue;
        }

        const float base = x.f * std::exp2((x.chanCents + gCents + vib) / 1200.f);

        if (x.zone) {  // ---- voz sampleada
            const Zone& z = *x.zone;
            const int n = (int)z.data.size();
            double step = (double)(base / z.freq) * (x.zoneSr / sr);
            if (!(step > 1e-4 && step < 64.0)) step = step >= 64.0 ? 64.0 : 1e-4;
            const int16_t* d = z.data.data();
            for (int i = 0; i < m; i++) {
                int ip = (int)x.pos;
                if (ip >= n - 3) { x.on = false; break; }
                float y = ip >= 1 ? hermite(d, ip, (float)(x.pos - ip)) : d[ip] * (1.f / 32768.f);
                x.pos += step;
                envStep(x, target);
                mix[i] += y * x.env;
                x.t += dt;
            }
            if (x.rel && x.env < 1e-5f) x.on = false;
            continue;
        }

        // ---- voz sintetizada
        if (p.o[0].w == PRIMES) {
            int L = (int)std::ceil(std::log2(std::max(base, 1.f) / 40.f));
            primeTable = primeTables[pa][std::clamp(L, 0, NLEV - 1)];
        }
        float a1 = 0, a2 = 0, a3 = 0;
        if (p.filt) {
            float r = p.fTau > 0 ? p.fEnd + (p.fStart - p.fEnd) * std::exp(-x.t / p.fTau) : p.fEnd;
            svfCoefs(base * r, p.q, sr, a1, a2, a3);
        }
        const float baseInc = base * dt;
        float inc[4];
        for (int k = 0; k < p.n; k++) inc[k] = baseInc * x.o[k].ratioMul;

        for (int i = 0; i < m; i++) {
            float fmIn[4] = {0, 0, 0, 0}, sum = 0;
            for (int k = 0; k < p.n; k++) {
                const OscDef& d = p.o[k];
                if (d.fmTarget < 0) continue;
                OscState& o = x.o[k];
                fmIn[d.fmTarget] += wave(d.w, o.ph, inc[k], primeTable) * o.fm * baseInc;
                o.fm = o.fmSus + (o.fm - o.fmSus) * o.fmCoef;
            }
            for (int k = 0; k < p.n; k++) {
                const OscDef& d = p.o[k];
                if (d.fmTarget >= 0) continue;
                OscState& o = x.o[k];
                sum += wave(d.w, o.ph, inc[k] + fmIn[k], primeTable) * o.level;
                o.level *= o.lvlCoef;
            }
            if (p.filt) {
                float v3 = sum - x.ic2;
                float v1 = a1 * x.ic1 + a2 * v3;
                float v2 = x.ic2 + a2 * x.ic1 + a3 * v3;
                x.ic1 = 2 * v1 - x.ic1;
                x.ic2 = 2 * v2 - x.ic2;
                sum = v2;
            }
            envStep(x, target);
            mix[i] += sum * x.env;
            x.t += dt;
        }
        if ((x.rel || x.vs == 0) && x.t > x.va && x.env < 1e-5f) x.on = false;
    }

    // Filtro de la rueda de modulación (cierra hasta ~280 Hz con la rueda al máximo)
    const float wantCut = modDest == 2 ? std::exp2(-mod * 6.f) : 1.f;
    modCut += (wantCut - modCut) * smooth;
    const bool useLp = modCut < .999f;
    float la1 = 0, la2 = 0, la3 = 0;
    if (useLp) svfCoefs(18000.f * modCut, .7071f, sr, la1, la2, la3);

    const float norm = 1.f / std::tanh(2.f);
    const float dlyS = 1.f - std::exp(-bdt / .08f);
    for (int i = 0; i < m; i++) {
        float s = mix[i] * volume * .5f * trem;
        if (useLp) {
            float v3 = s - mlpB;
            float v1 = la1 * mlpL + la2 * v3;
            float v2 = mlpB + la2 * mlpL + la3 * v3;
            mlpL = 2 * v1 - mlpL;
            mlpB = 2 * v2 - mlpB;
            s = v2;
        } else { mlpL = mlpB = 0; }

        float L = s, R = s;
        if (dlyMix > 0) {  // delay ping-pong estéreo
            dlyTimeS += (dlyTime - dlyTimeS) * dlyS / m;
            const int n = (int)dlyL.size();
            float rp = (float)dlyIdx - dlyTimeS * sr;
            while (rp < 0) rp += n;
            int i0 = (int)rp; float fr = rp - i0; int i1 = i0 + 1 >= n ? 0 : i0 + 1;
            float yl = dlyL[i0] + (dlyL[i1] - dlyL[i0]) * fr;
            float yr = dlyR[i0] + (dlyR[i1] - dlyR[i0]) * fr;
            dlyLpL += (yl - dlyLpL) * .45f;
            dlyLpR += (yr - dlyLpR) * .45f;
            dlyL[dlyIdx] = s + dlyLpR * dlyFb;
            dlyR[dlyIdx] = dlyLpL * dlyFb;
            if (++dlyIdx >= n) dlyIdx = 0;
            L += yl * dlyMix;
            R += yr * dlyMix;
        }
        if (revMix > 0) {
            float rl, rr;
            reverb(s, rl, rr);
            L += rl * revMix;
            R += rr * revMix;
        }
        out[2 * i] = std::tanh(2.f * std::clamp(L, -1.f, 1.f)) * norm;
        out[2 * i + 1] = std::tanh(2.f * std::clamp(R, -1.f, 1.f)) * norm;
    }
}

}  // namespace rusc
