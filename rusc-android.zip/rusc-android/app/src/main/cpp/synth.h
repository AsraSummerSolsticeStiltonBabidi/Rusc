#pragma once
#include <atomic>
#include <cstdint>
#include <vector>
#include "soundfont.h"
#include "pads.h"

namespace rusc {

enum Wave : uint8_t { SINE = 0, SAW, SQUARE, TRI, ORGAN, REED, PRIMES, NOISE, VOWEL, CHURCH, SOFT, VOWEL_O, HOLLOW, VOWEL_I, COMB, NWAVES };

struct OscDef {
    Wave w = SINE;
    float ratio = 1, cents = 0, level = 0, levelTau = 0;
    int fmTarget = -1;                        // >= 0: modulador FM de ese oscilador
    float fmPeak = 0, fmSus = 0, fmTau = 0;   // índice FM (relativo a la frecuencia sonando)
    float velFm = 0;                          // cuánto sube el índice FM con la velocidad (0-1)
    float width = .5f;                        // ancho de pulso (SQUARE)
    // capas de los timbres ambient
    float rise = 0, wait = 0;                 // capa lenta: tras `wait` s entra desde el silencio (constante `rise` s) mientras se mantiene la nota
    bool dry = false;                         // no pasa por el filtro de la voz
    float pan = 0;                            // -1 izquierda … 1 derecha
    float stay = 0, fall = 0;                 // capa lenta que se retira: `stay` s después de empezar cae (constante `fall` s)
    float floor = 0;                          // fracción del nivel en la que se queda una capa que cae (0: desaparece)
    float cents0 = 0, gather = 0;             // desafinación al pulsar; converge a `cents` con constante `gather` s
    float swRate = 0, swDepth = 0, swPhase = 0;   // vaivén lento del nivel (Hz, profundidad 0-1, fase 0-1; empieza lleno con fase 0)
};

static constexpr int MAXOSC = 8;

struct Preset {
    int n = 1;
    OscDef o[MAXOSC];
    bool filt = false;
    float fStart = 0, fEnd = 0, fTau = 0, q = 0.7f;   // corte en múltiplos de la frecuencia sonando
    float a = .005f, d = .1f, s = 1, r = .1f, gain = 1;
    int sampleSet = -1;                               // >= 0: instrumento sampleado
    bool sf2 = false;                                 // SoundFont del usuario
    float velAmp = .65f;                              // sensibilidad del volumen a la velocidad
    float velFilt = 0;                                // el filtro se abre con la velocidad (octavas)
    float keyDecay = 0;                               // las notas agudas se apagan antes (por octava)
    float pickDrive = 0, pickAsym = 0;                // pastilla magnética (Rhodes, Wurlitzer)
    float chorus = 0, panRate = 0, panDepth = 0;      // efectos propios del timbre
    // ---- timbres ambient: evolucionan mientras se mantiene la nota
    bool amb = false, wide = false;                   // usa el camino ambient / tiene capas filtradas con panorama
    float evTau = 0, evRel = 1;                       // evolución 0→1 al mantener (s); vuelve a 0 al soltar (s)
    float evOct = 0, modOct = 0;                      // octavas que abren el filtro la evolución y la rueda de modulación
    bool evArc = false;                               // el filtro sube y vuelve a bajar en vez de quedarse abierto
    int ftype = 0;                                    // 0 paso bajo, 1 paso banda, 2 paso alto
    float brRate = 0, brOct = 0;                      // respiración lenta del filtro (Hz, octavas); cada voz con su fase
    float chime = 0, chimeEv = 0;                     // campanitas: nivel con la rueda de modulación / con la evolución
    float chimeRate = 7, chimeTau = .22f;             // golpes por segundo y caída de cada campanita
    int chimeN = 0; float chimeH[8] = {};             // armónicos de la nota entre los que se elige cada golpe
    float rev = 0, revSize = 0;                       // espacio propio del timbre (mezcla y tamaño de reverb mínimos)
};

struct Ev { uint8_t kind, a, b, c; float v; };

class Queue {  // un productor (Kotlin sincronizado), un consumidor (hilo de audio)
    static constexpr uint32_t N = 2048;
    Ev buf[N];
    std::atomic<uint32_t> w{0}, r{0};
public:
    bool push(const Ev& e) {
        uint32_t wi = w.load(std::memory_order_relaxed);
        if (wi - r.load(std::memory_order_acquire) >= N) return false;
        buf[wi % N] = e;
        w.store(wi + 1, std::memory_order_release);
        return true;
    }
    bool pop(Ev& e) {
        uint32_t ri = r.load(std::memory_order_relaxed);
        if (ri == w.load(std::memory_order_acquire)) return false;
        e = buf[ri % N];
        r.store(ri + 1, std::memory_order_release);
        return true;
    }
};

struct Zone { float freq = 440; uint32_t loopStart = 0, loopEnd = 0; std::vector<int16_t> data; };
struct SampleSet { float sr = 32000; std::vector<Zone> zones; };

struct OscState {
    double ph = 0;
    float ratioMul = 1, level = 0, lvlCoef = 1, fm = 0, fmSus = 0, fmCoef = 1;
    float lvlEnd = 0;     // nivel al que tiende la capa (0: se apaga; capas lentas: su nivel final)
    float fallCoef = 1;   // caída de una capa lenta que se retira
};

static constexpr int NCH = 3;   // campanitas simultáneas por voz

struct Voice {
    bool on = false, rel = false, sus = false;
    uint8_t ch = 0, note = 0;
    uint32_t age = 0;
    const Preset* p = nullptr;
    float f = 0, t = 0, env = 0, peak = 0, dCoef = 0, rCoef = 0;
    float chanCents = 0;      // parte del bend propia de la nota (se congela al soltar)
    OscState o[MAXOSC];
    float ic1 = 0, ic2 = 0;
    float vel = 1;                 // velocidad 0-1
    float filtMul = 1;             // apertura del filtro por velocidad
    uint32_t noise = 1;            // generador de ruido de la voz
    float dcX = 0, dcY = 0;        // bloqueo de continua tras la pastilla
    const Zone* zone = nullptr;
    float zoneSr = 32000;
    double pos = 0;
    // envolvente propia de la voz
    float va = .005f, vh = 0, vs = 1;
    // SoundFont
    const SfRegion* reg = nullptr;
    const SfBank* bank = nullptr;
    float sfCents = 0;    // afinación de la zona para esta tecla (sin bend)
    // timbres ambient
    float ev = 0, brPh = 0;        // evolución 0-1 y fase de la respiración del filtro
    float ic3 = 0, ic4 = 0;        // filtro del canal lateral
    bool chLive = false;           // hay campanitas sonando
    bool cap = false;              // nota tocada con el pedal pisado (modo fijado): se queda sonando
    bool evFlip = false;           // filtro en arco: ya se ha dado la vuelta al soltar
    uint8_t chNext = 0;
    float chT = 0;                 // tiempo hasta el siguiente golpe
    float chPh[NCH] = {}, chRatio[NCH] = {}, chAmp[NCH] = {}, chGain[NCH] = {}, chPan[NCH] = {}, chDec[NCH] = {};
};

// Parámetros (kind = 1)
enum Param : uint8_t {
    P_PRESET = 0, P_VOLUME, P_REVERB_MIX, P_BEND_NOTE, P_PANIC,
    P_ATTACK, P_DECAY, P_SUSTAIN, P_RELEASE,
    P_BEND_GLOBAL, P_MOD_DEST, P_LFO_RATE, P_VIB_DEPTH,
    P_REVERB_SIZE, P_DELAY_MIX, P_DELAY_TIME, P_DELAY_FB,
    P_ARP,       // pedal mantenido: arpegio ascendente sobre los timbres ambient
    P_LAYER,     // segundo timbre que suena a la vez (-1: ninguno)
    P_LAYER_MIX, // nivel del segundo timbre
    P_PEDAL_LATCH // 1: lo tocado con el pedal pisado se queda sonando hasta la siguiente pisada; 0: sustain normal
};

class Synth {
public:
    static constexpr int MAXV = 64;
    static constexpr int NSYNTH = 40;                      // sintetizados
    static constexpr int PRIMES_PRESET = NSYNTH;           // sinte de primos
    static constexpr int NSETS = 32;                       // instrumentos sampleados (máximo)
    static constexpr int FIRST_SET = NSYNTH + 1;
    static constexpr int SF2_PRESET = FIRST_SET + NSETS;   // SoundFont del usuario
    static constexpr int FIRST_AMB = SF2_PRESET + 1;       // timbres ambient (van al final: los índices anteriores no cambian)
    static constexpr int NAMB = 16;                        // dos hornadas de 8
    static constexpr int NPRESETS = FIRST_AMB + NAMB;
    static constexpr int MAXHELD = 24;
    static constexpr int TBL = 2048;
    static constexpr int NLEV = 11;

    Queue q;
    Pads pads;                         // sampler de pads (eventos con kind = 2)
    std::atomic<int> rpnSeen{-1};
    std::atomic<uint32_t> chanMask{0};
    std::atomic<int> voicesOn{0};
    std::atomic<float> wheelOut{0};    // rueda de pitch (cents) para la interfaz
    std::atomic<float> modOut{0};      // rueda de modulación 0-1

    // Notas pulsadas (cents absolutos, nota MIDI*100 + bends) para la rueda de intervalos
    std::atomic<uint32_t> heldSeq{0};
    std::atomic<float> heldBuf[MAXHELD];
    std::atomic<int> heldKey[MAXHELD];
    std::atomic<int> heldN{0};
    int readHeld(float* out, int* keys, int max);   // desde cualquier hilo

    // SoundFont: el hilo de la interfaz publica un banco nuevo; el de audio lo adopta
    void publishBank(SfBank* b);
    void collectBanks();                 // libera bancos retirados (fuera del hilo de audio)

    Synth();
    ~Synth();
    void init(float sampleRate);
    void render(float* out, int frames);

    // Llamadas desde fuera del hilo de audio
    bool loadSamples(int set, const uint8_t* data, int len);
    bool samplesReady(int set) const { return sets[set].load() != nullptr; }
    void buildPrimes(uint32_t primeMask, int maxHarm, float slope);
    static float presetDefault(int preset, int which);   // 0=A 1=D 2=S 3=R

private:
    static constexpr int BLK = 32;
    float sr = 48000, dt = 1.f / 48000;
    Voice v[MAXV];
    float bend[16]{};
    int bendRaw[16]{};
    float range[16];
    uint8_t rpnM[16], rpnL[16];
    bool sustain = false;
    uint32_t ageCounter = 0, rng = 22222;
    int preset = 0;
    int layer = -1;                    // timbre mezclado con el principal
    float layerMix = .7f;

    float volume = .8f;
    float mod = 0; int modDest = 0; float lfoRate = 5.6f, vibDepth = 35;
    double lfoPh = 0;
    float mlpL = 0, mlpB = 0, modCut = 1;     // filtro maestro de la rueda de modulación
    float modS = 0;                           // rueda de modulación suavizada (timbres ambient)
    bool arpOn = false;                       // arpegio ascendente (pedal mantenido)
    float arpAmt = 0, arpT = 0;
    int arpStep = 0;
    float modT = 0;                           // cascada descendente de la rueda de modulación
    int modStep = 0;
    bool pedalLatch = true, pedalDown = false, pedalArp = false;
    float pedalT = 0;                         // tiempo que lleva pisado el pedal
    void setSustain(bool on);
    void arpStrike(bool up);

    float revMix = 0, revFb = .82f;
    float revAmt = 0, revFbS = .82f;          // mezcla y tamaño en uso (ajuste del usuario o espacio propio del timbre)
    std::vector<float> comb[8], ap[4];
    int combIdx[8]{}, apIdx[4]{};
    float combStore[8]{};

    float dlyMix = 0, dlyFb = .35f, dlyTime = .35f, dlyTimeS = .35f;
    std::vector<float> dlyL, dlyR;

    // efectos propios del timbre (chorus y trémolo estéreo)
    std::vector<float> chBuf;
    int chIdx = 0;
    double chPh = 0, panPh = 0;
    float chAmt = 0, panRt = 0, panDp = 0;

    // salida: nivelador lento + control de picos con anticipación de un bloque (sin recortes)
    float levEnv = 0, levGain = 1;
    float lookL[BLK] = {}, lookR[BLK] = {};
    float qRing[BLK + 1] = {}, mRing[BLK] = {};
    float mSum = BLK, gRel = 1;
    int lookIdx = 0, qIdx = 0, mIdx = 0;
    void master(float L, float R, float& outL, float& outR);
    int dlyIdx = 0;
    float dlyLpL = 0, dlyLpR = 0;

    std::atomic<SampleSet*> sets[NSETS];
    std::atomic<SfBank*> sfPending{nullptr};
    SfBank* sfCur = nullptr;
    static constexpr int NRETIRE = 8, NFREE = 32;
    SfBank* retiring[NRETIRE] = {};
    std::atomic<SfBank*> toFree[NFREE];
    bool queueFree(SfBank* b);
    void adoptBank();
    void retireBanks();
    void publishHeld();
    float primeTables[2][NLEV][TBL + 1];
    std::atomic<int> primeActive{0};

    void handle(const Ev& e);
    void midi(uint8_t s, uint8_t a, uint8_t b);
    void cc(int ch, int n, int val);
    void noteOn(int ch, int note, int vel);
    void startNote(int ch, int note, int vel, int which, float gain);
    Voice& allocVoice();
    void noteOff(int ch, int note);
    void allOff(int ch);
    void updBend(int ch);
    float globalCents() const { return bend[0]; }
    void block(float* out, int m);
    void reverb(float x, float& l, float& r);
    void clearReverb();
    float rnd();
};

}  // namespace rusc
