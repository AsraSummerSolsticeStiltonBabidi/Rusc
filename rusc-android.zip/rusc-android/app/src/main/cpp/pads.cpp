#include "pads.h"
#include <algorithm>
#include <cmath>

namespace rusc {

// ---------- reverb de catedral ----------
void Cathedral::init(float sr, float rt60) {
    static const float LEN[NL] = {.0437f, .0533f, .0611f, .0719f, .0833f, .0971f, .1093f, .1277f};
    static const float AP[NAP] = {.0048f, .0036f, .0127f, .0093f};
    for (int k = 0; k < NL; k++) {
        int n = (int)(LEN[k] * sr) | 1;
        line[k].assign((size_t)n, 0.f);
        g[k] = std::pow(10.f, -3.f * (float)n / sr / rt60);
        idx[k] = 0; lp[k] = 0;
    }
    for (int k = 0; k < NAP; k++) { ap[k].assign((size_t)((int)(AP[k] * sr) | 1), 0.f); apIdx[k] = 0; }
    damp = 1.f - std::exp(-2.f * (float)M_PI * 6000.f / sr);   // los agudos se apagan antes, como en piedra
}

void Cathedral::clear() {
    for (auto& b : line) std::fill(b.begin(), b.end(), 0.f);
    for (auto& b : ap) std::fill(b.begin(), b.end(), 0.f);
    for (auto& x : lp) x = 0;
}

inline void Cathedral::process(float in, float& l, float& r) {
    float x = in;
    for (int k = 0; k < NAP; k++) {   // difusión
        auto& b = ap[k];
        const float bo = b[apIdx[k]];
        const float v = x + bo * .6f;
        b[apIdx[k]] = v;
        x = bo - v * .6f;
        if (++apIdx[k] >= (int)b.size()) apIdx[k] = 0;
    }
    float d[NL];
    for (int k = 0; k < NL; k++) d[k] = line[k][idx[k]];
    l = d[0] - d[2] + d[4] - d[6];
    r = d[1] - d[3] + d[5] - d[7];
    for (int k = 0; k < NL; k++) { lp[k] += (d[k] - lp[k]) * damp; d[k] = lp[k] * g[k]; }
    for (int h = 1; h < NL; h *= 2)   // mezcla de Hadamard: reparte cada línea entre todas sin perder energía
        for (int i = 0; i < NL; i += 2 * h)
            for (int j = i; j < i + h; j++) { const float a = d[j], b = d[j + h]; d[j] = a + b; d[j + h] = a - b; }
    for (int k = 0; k < NL; k++) {
        line[k][idx[k]] = ((k & 2) ? -x : x) + d[k] * .35355339f;   // mismo signo que su salida: L y R nacen en fase
        if (++idx[k] >= (int)line[k].size()) idx[k] = 0;
    }
}

// ---------- pads ----------
Pads::Pads() { for (auto& p : progress) p.store(0.f); }

Pads::~Pads() {
    for (auto& p : pad) { delete p.cur; delete p.pending.exchange(nullptr); delete p.retired.exchange(nullptr); }
}

void Pads::init(float sampleRate) {
    sr = sampleRate;
    hall.init(sr, 9.f);
    dlyL.assign((size_t)(sr * 2.1f), 0.f);
    dlyR.assign((size_t)(sr * 2.1f), 0.f);
    dlyIdx = 0; dlyLpL = dlyLpR = 0; tail = 0;
    for (auto& p : pad) { p.on = false; p.gain = 0; }
}

void Pads::publish(int i, PadSample* s) {
    if (i < 0 || i >= N) { delete s; return; }
    delete pad[i].pending.exchange(s);   // uno anterior que el hilo de audio aún no había recogido
}

void Pads::collect() {
    for (auto& p : pad) delete p.retired.exchange(nullptr);
}

void Pads::adopt() {
    for (auto& p : pad) {
        if (!p.pending.load(std::memory_order_acquire)) continue;
        if (p.retired.load(std::memory_order_acquire)) continue;   // la interfaz aún no ha liberado el anterior
        PadSample* n = p.pending.exchange(nullptr);
        if (!n) continue;
        p.retired.store(p.cur, std::memory_order_release);
        p.cur = n;
        p.on = false; p.gain = 0;
    }
}

void Pads::event(int i, int what, float v) {
    if (what == DELAY_TIME) { dlyTime = std::clamp(v, .02f, 2.f); return; }
    if (what == DELAY_FB) { dlyFb = std::clamp(v, 0.f, .9f); return; }
    if (i < 0 || i >= N) return;
    Pad& p = pad[i];
    switch (what) {
        case TRIGGER:   // pulsar: suena desde el principio; pulsar otra vez mientras suena: se apaga
            if (p.on && !p.stopping) p.stopping = true;
            else if (v > .5f && p.cur && p.cur->frames() > 2) {
                p.on = true; p.stopping = false; p.pos = 0; p.gain = 0;
                p.l1 = p.l2 = p.r1 = p.r2 = 0;
            }
            break;
        case VOLUME: p.vol = std::clamp(v, 0.f, 1.5f); break;
        case REVERB: p.rev = std::clamp(v, 0.f, 1.f); break;
        case DELAY: p.dly = std::clamp(v, 0.f, 1.f); break;
        case LOWCUT: p.cut = std::clamp(v, 0.f, 2000.f); break;
        case LOOP: p.loop = v > .5f; break;
    }
}

void Pads::stopAll() { for (auto& p : pad) if (p.on) p.stopping = true; }

void Pads::render(float* L, float* R, int m) {
    adopt();
    float rv[MAXBLK] = {0}, dl[MAXBLK] = {0}, dr[MAXBLK] = {0};
    bool any = false;
    uint32_t mask = 0;
    const float att = 1.f - std::exp(-1.f / (sr * .004f)), rel = 1.f - std::exp(-1.f / (sr * .05f));
    for (int k = 0; k < N; k++) {
        Pad& p = pad[k];
        if (!p.on || !p.cur) continue;
        any = true;
        const PadSample& s = *p.cur;
        const size_t n = s.frames();
        const int16_t* d = s.data.data();
        const int ch = s.ch;
        const double step = (double)s.sr / sr;
        const bool hp = p.cut > 25.f;
        float a1 = 0, a2 = 0, a3 = 0;
        const float kq = 1.4142f;
        if (hp) {
            const float gg = std::tan((float)M_PI * std::min(p.cut, sr * .45f) / sr);
            a1 = 1.f / (1.f + gg * (gg + kq)); a2 = gg * a1; a3 = gg * a2;
        }
        const float want = p.stopping ? 0.f : 1.f, coef = p.stopping ? rel : att;
        for (int i = 0; i < m; i++) {
            if (p.pos >= (double)(n - 1)) {
                if (p.loop) p.pos -= (double)(n - 1);
                else { p.on = false; break; }
            }
            const size_t ip = (size_t)p.pos;
            const float fr = (float)(p.pos - (double)ip);
            const int16_t* q = d + ip * (size_t)ch;
            float l = ((float)q[0] + (float)(q[ch] - q[0]) * fr) * (1.f / 32768.f);
            float r = ch > 1 ? ((float)q[1] + (float)(q[ch + 1] - q[1]) * fr) * (1.f / 32768.f) : l;
            p.pos += step;
            if (hp) {   // quita graves (12 dB por octava)
                float v3 = l - p.l2, v1 = a1 * p.l1 + a2 * v3, v2 = p.l2 + a2 * p.l1 + a3 * v3;
                p.l1 = 2 * v1 - p.l1; p.l2 = 2 * v2 - p.l2;
                l = l - kq * v1 - v2;
                v3 = r - p.r2; v1 = a1 * p.r1 + a2 * v3; v2 = p.r2 + a2 * p.r1 + a3 * v3;
                p.r1 = 2 * v1 - p.r1; p.r2 = 2 * v2 - p.r2;
                r = r - kq * v1 - v2;
            }
            p.gain += (want - p.gain) * coef;
            l *= p.gain * p.vol; r *= p.gain * p.vol;
            L[i] += l; R[i] += r;
            rv[i] += (l + r) * .5f * p.rev;
            dl[i] += l * p.dly; dr[i] += r * p.dly;
        }
        if (p.stopping && p.gain < 1e-3f) { p.on = false; p.stopping = false; }
        if (p.on) mask |= 1u << k;
        progress[k].store(n > 1 ? (float)(p.pos / (double)(n - 1)) : 0.f, std::memory_order_relaxed);
    }
    playing.store(mask, std::memory_order_relaxed);

    // efectos: siguen sonando un rato después del último pad (cola de la catedral y ecos)
    if (any) {
        if (tail == 0) { hall.clear(); std::fill(dlyL.begin(), dlyL.end(), 0.f); std::fill(dlyR.begin(), dlyR.end(), 0.f); dlyLpL = dlyLpR = 0; }
        tail = (int)(30.f * sr / MAXBLK);
    } else if (tail > 0) tail--;
    if (tail == 0) return;
    const int dn = (int)dlyL.size();
    const float dlyS = 1.f - std::exp(-1.f / (sr * .08f));
    for (int i = 0; i < m; i++) {
        // delay ping-pong
        dlyTimeS += (dlyTime - dlyTimeS) * dlyS;
        float rp = (float)dlyIdx - dlyTimeS * sr;
        while (rp < 0) rp += dn;
        int i0 = (int)rp; float fr = rp - i0;
        if (i0 >= dn) { i0 -= dn; fr = 0; }
        const int i1 = i0 + 1 >= dn ? 0 : i0 + 1;
        const float yl = dlyL[i0] + (dlyL[i1] - dlyL[i0]) * fr;
        const float yr = dlyR[i0] + (dlyR[i1] - dlyR[i0]) * fr;
        dlyLpL += (yl - dlyLpL) * .45f;
        dlyLpR += (yr - dlyLpR) * .45f;
        dlyL[dlyIdx] = dl[i] + dlyLpR * dlyFb;
        dlyR[dlyIdx] = dr[i] + dlyLpL * dlyFb;
        if (++dlyIdx >= dn) dlyIdx = 0;
        float hl, hr;
        hall.process(rv[i], hl, hr);
        L[i] += yl + hl * .4f;
        R[i] += yr + hr * .4f;
    }
}

}  // namespace rusc
