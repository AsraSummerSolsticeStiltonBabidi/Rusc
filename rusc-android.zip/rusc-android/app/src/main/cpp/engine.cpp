#include <algorithm>
#include <cstring>
#include <jni.h>
#include <oboe/Oboe.h>
#include <atomic>
#include <memory>
#include <mutex>
#include <vector>
#include <string>
#include <unistd.h>
#include <sys/stat.h>
#include "synth.h"
#include "soundfont.h"

using namespace oboe;

namespace {

class Player : public AudioStreamDataCallback, public AudioStreamErrorCallback {
public:
    rusc::Synth synth;

    bool open() {
        std::lock_guard<std::mutex> g(lock);
        if (stream) return true;
        AudioStreamBuilder b;
        b.setDirection(Direction::Output)
            ->setPerformanceMode(PerformanceMode::LowLatency)
            ->setSharingMode(SharingMode::Exclusive)
            ->setFormat(AudioFormat::Float)
            ->setChannelCount(ChannelCount::Stereo)
            ->setDataCallback(this)
            ->setErrorCallback(this);
        if (b.openStream(stream) != Result::OK) { stream.reset(); return false; }

        // Pide a la CPU que acelere cuando entran muchas notas de golpe (ADPF, si el móvil lo tiene)
        stream->setPerformanceHintEnabled(true);

        synth.init((float)stream->getSampleRate());
        tuner = std::make_unique<LatencyTuner>(*stream);
        tuner->setMinimumBufferSize(stream->getFramesPerBurst() * 2);   // 1 ráfaga da cortes en muchos móviles
        applyBufferLocked();

        if (stream->requestStart() != Result::OK) {
            stream->close(); stream.reset(); tuner.reset();
            return false;
        }
        return true;
    }

    void close() {
        std::lock_guard<std::mutex> g(lock);
        if (stream) { stream->stop(); stream->close(); stream.reset(); }
        tuner.reset();
    }

    // 0 = automático; n = n ráfagas fijas
    void setBufferMode(int m) {
        std::lock_guard<std::mutex> g(lock);
        bufferMode.store(m);
        applyBufferLocked();
    }

    float latency() {
        std::lock_guard<std::mutex> g(lock);
        if (!stream) return -1.f;
        auto r = stream->calculateLatencyMillis();
        if (r) return (float)r.value();
        return 1000.f * stream->getBufferSizeInFrames() / stream->getSampleRate();
    }

    int xruns() {
        std::lock_guard<std::mutex> g(lock);
        if (!stream) return 0;
        auto r = stream->getXRunCount();
        return r ? r.value() : 0;
    }

    int bufferFrames() {
        std::lock_guard<std::mutex> g(lock);
        return stream ? stream->getBufferSizeInFrames() : 0;
    }

    int sampleRate() {
        std::lock_guard<std::mutex> g(lock);
        return stream ? stream->getSampleRate() : 0;
    }

    bool exclusive() {
        std::lock_guard<std::mutex> g(lock);
        return stream && stream->getSharingMode() == SharingMode::Exclusive;
    }

    DataCallbackResult onAudioReady(AudioStream*, void* data, int32_t frames) override {
        synth.render(static_cast<float*>(data), frames);
        if (bufferMode.load(std::memory_order_relaxed) == 0 && tuner) {
            tuner->tune();
            shrink(frames);
        }
        return DataCallbackResult::Continue;
    }

    // Si cambia la salida de audio (auriculares, USB), se reabre el stream
    void onErrorAfterClose(AudioStream*, Result r) override {
        if (r == Result::ErrorDisconnected) {
            {
                std::lock_guard<std::mutex> g(lock);
                stream.reset();
                tuner.reset();
            }
            open();
        }
    }

private:
    std::shared_ptr<AudioStream> stream;
    std::unique_ptr<LatencyTuner> tuner;
    std::atomic<int> bufferMode{0};
    std::mutex lock;

    // Modo automático: el búfer crece cuando hay un corte, pero por sí solo nunca vuelve a bajar y la latencia
    // se queda alta el resto de la sesión. Tras 20 s sin cortes se prueba una ráfaga menos; si esa bajada
    // provoca un corte, se recuerda el tamaño anterior como suelo y no se vuelve a probar por debajo.
    int32_t lastXruns = 0, floorFrames = 0, beforeStep = 0;
    int64_t calm = 0, sinceStep = 0;
    bool stepped = false;

    void shrink(int32_t frames) {   // hilo de audio
        AudioStream* s = stream.get();
        if (!s) return;
        const int32_t sr = s->getSampleRate(), burst = s->getFramesPerBurst();
        calm += frames; sinceStep += frames;
        auto xr = s->getXRunCount();
        if (xr && xr.value() != lastXruns) {
            lastXruns = xr.value();
            if (stepped && sinceStep < (int64_t)sr * 30) floorFrames = std::max(floorFrames, beforeStep);
            stepped = false;
            calm = 0;
        }
        if (calm > (int64_t)sr * 20) {
            calm = 0;
            const int32_t cur = s->getBufferSizeInFrames();
            if (cur - burst >= std::max(burst * 2, floorFrames)) {
                beforeStep = cur;
                s->setBufferSizeInFrames(cur - burst);
                stepped = true; sinceStep = 0;
            }
        }
    }

    void applyBufferLocked() {
        if (!stream) return;
        const int m = bufferMode.load();
        if (m == 0) {
            if (tuner) tuner->requestReset();   // empieza en 1 ráfaga y crece solo si hay cortes
        } else {
            stream->setBufferSizeInFrames(stream->getFramesPerBurst() * m);
        }
    }
};

Player player;

// Samples de los pads mientras se van cargando (por trozos, desde Kotlin)
std::mutex padLock;
std::unique_ptr<rusc::PadSample> padBuilding[rusc::Pads::N];
constexpr size_t PAD_MAX_SAMPLES = (size_t)48000 * 2 * 60 * 8;   // unos 8 minutos en estéreo

// SoundFont abierto (las zonas en uso viven en bancos con su propia referencia al archivo)
std::mutex sfLock;
std::unique_ptr<rusc::SoundFont> soundFont;

// Lee todo el archivo a memoria nativa: así el hilo de audio nunca espera al disco
bool readAll(int fd, std::vector<uint8_t>& out) {
    struct stat st {};
    if (fstat(fd, &st) == 0 && st.st_size > 0) out.reserve((size_t)st.st_size);
    uint8_t buf[1 << 16];
    for (;;) {
        ssize_t n = read(fd, buf, sizeof buf);
        if (n < 0) return false;
        if (n == 0) return true;
        if (out.size() + (size_t)n > (size_t)2000 * 1024 * 1024) return false;
        out.insert(out.end(), buf, buf + n);
    }
}

}  // namespace

extern "C" {

JNIEXPORT jboolean JNICALL Java_cat_asra_rusc_Engine_start(JNIEnv*, jobject) {
    return player.open() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL Java_cat_asra_rusc_Engine_stop(JNIEnv*, jobject) {
    player.close();
}

JNIEXPORT void JNICALL Java_cat_asra_rusc_Engine_send(JNIEnv*, jobject, jint kind, jint a, jint b, jint c, jfloat v) {
    player.synth.q.push({(uint8_t)kind, (uint8_t)a, (uint8_t)b, (uint8_t)c, v});
}

JNIEXPORT void JNICALL Java_cat_asra_rusc_Engine_setBufferMode(JNIEnv*, jobject, jint mode) {
    player.setBufferMode(mode);
}

JNIEXPORT jfloat JNICALL Java_cat_asra_rusc_Engine_latencyMs(JNIEnv*, jobject) {
    return player.latency();
}

JNIEXPORT jint JNICALL Java_cat_asra_rusc_Engine_xruns(JNIEnv*, jobject) {
    return player.xruns();
}

JNIEXPORT jint JNICALL Java_cat_asra_rusc_Engine_bufferFrames(JNIEnv*, jobject) {
    return player.bufferFrames();
}

JNIEXPORT jint JNICALL Java_cat_asra_rusc_Engine_sampleRate(JNIEnv*, jobject) {
    return player.sampleRate();
}

JNIEXPORT jboolean JNICALL Java_cat_asra_rusc_Engine_exclusive(JNIEnv*, jobject) {
    return player.exclusive() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jint JNICALL Java_cat_asra_rusc_Engine_rpnRange(JNIEnv*, jobject) {
    return player.synth.rpnSeen.load();
}

JNIEXPORT jint JNICALL Java_cat_asra_rusc_Engine_channelMask(JNIEnv*, jobject) {
    return (jint)player.synth.chanMask.load();
}

JNIEXPORT jint JNICALL Java_cat_asra_rusc_Engine_voices(JNIEnv*, jobject) {
    return player.synth.voicesOn.load();
}

JNIEXPORT jfloat JNICALL Java_cat_asra_rusc_Engine_wheelCents(JNIEnv*, jobject) {
    return player.synth.wheelOut.load();
}

JNIEXPORT jfloat JNICALL Java_cat_asra_rusc_Engine_modWheel(JNIEnv*, jobject) {
    return player.synth.modOut.load();
}

JNIEXPORT jboolean JNICALL Java_cat_asra_rusc_Engine_loadSamples(JNIEnv* env, jobject, jint set, jbyteArray data) {
    const jsize len = env->GetArrayLength(data);
    std::vector<uint8_t> buf((size_t)len);
    env->GetByteArrayRegion(data, 0, len, reinterpret_cast<jbyte*>(buf.data()));
    return player.synth.loadSamples(set, buf.data(), (int)len) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL Java_cat_asra_rusc_Engine_samplesReady(JNIEnv*, jobject, jint set) {
    if (set < 0 || set >= rusc::Synth::NSETS) return JNI_FALSE;
    return player.synth.samplesReady(set) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL Java_cat_asra_rusc_Engine_buildPrimes(JNIEnv*, jobject, jint mask, jint maxHarm, jfloat slope) {
    player.synth.buildPrimes((uint32_t)mask, maxHarm, slope);
}

JNIEXPORT jfloat JNICALL Java_cat_asra_rusc_Engine_presetDefault(JNIEnv*, jobject, jint preset, jint which) {
    return rusc::Synth::presetDefault(preset, which);
}

JNIEXPORT jint JNICALL Java_cat_asra_rusc_Engine_heldNotes(JNIEnv* env, jobject, jfloatArray pitches, jintArray keys) {
    float tmp[rusc::Synth::MAXHELD];
    int k[rusc::Synth::MAXHELD];
    const int n = player.synth.readHeld(tmp, k, rusc::Synth::MAXHELD);
    const int len = std::min(n, (int)std::min(env->GetArrayLength(pitches), env->GetArrayLength(keys)));
    if (len > 0) {
        env->SetFloatArrayRegion(pitches, 0, len, tmp);
        env->SetIntArrayRegion(keys, 0, len, k);
    }
    return len;
}

// Abre un .sf2 desde un descriptor (se cierra aquí). Devuelve el número de presets o -1.
JNIEXPORT jint JNICALL Java_cat_asra_rusc_Engine_sf2Open(JNIEnv*, jobject, jint fd) {
    std::vector<uint8_t> bytes;
    const bool ok = readAll(fd, bytes);
    close(fd);
    if (!ok) return -1;
    auto sf = std::make_unique<rusc::SoundFont>();
    if (!sf->open(std::move(bytes))) return -1;
    std::lock_guard<std::mutex> g(sfLock);
    soundFont = std::move(sf);
    return soundFont->count();
}

JNIEXPORT jstring JNICALL Java_cat_asra_rusc_Engine_sf2Name(JNIEnv* env, jobject, jint i) {
    std::lock_guard<std::mutex> g(sfLock);
    const std::string n = soundFont ? soundFont->name(i) : std::string();
    return env->NewStringUTF(n.c_str());   // solo ASCII: siempre UTF-8 válido
}

JNIEXPORT jboolean JNICALL Java_cat_asra_rusc_Engine_sf2Select(JNIEnv*, jobject, jint i) {
    rusc::SfBank* b = nullptr;
    {
        std::lock_guard<std::mutex> g(sfLock);
        if (soundFont) b = soundFont->makeBank(i);
    }
    if (!b) return JNI_FALSE;
    player.synth.collectBanks();
    player.synth.publishBank(b);
    return JNI_TRUE;
}

JNIEXPORT void JNICALL Java_cat_asra_rusc_Engine_sf2Collect(JNIEnv*, jobject) {
    player.synth.collectBanks();
}

// ---------- pads ----------
JNIEXPORT void JNICALL Java_cat_asra_rusc_Engine_padBegin(JNIEnv*, jobject, jint i, jint channels, jint rate) {
    if (i < 0 || i >= rusc::Pads::N) return;
    auto s = std::make_unique<rusc::PadSample>();
    s->ch = channels >= 2 ? 2 : 1;
    s->sr = (float)std::clamp((int)rate, 4000, 384000);
    std::lock_guard<std::mutex> g(padLock);
    padBuilding[i] = std::move(s);
}

// `n` muestras entrelazadas con `channels` canales (los que sobran de dos se descartan)
JNIEXPORT void JNICALL Java_cat_asra_rusc_Engine_padAppend(JNIEnv* env, jobject, jint i, jshortArray data, jint n, jint channels) {
    if (i < 0 || i >= rusc::Pads::N || n <= 0 || channels < 1 || n > env->GetArrayLength(data)) return;
    std::vector<int16_t> tmp((size_t)n);
    env->GetShortArrayRegion(data, 0, n, tmp.data());
    std::lock_guard<std::mutex> g(padLock);
    rusc::PadSample* s = padBuilding[i].get();
    if (!s || s->data.size() >= PAD_MAX_SAMPLES) return;
    if (channels <= 2) s->data.insert(s->data.end(), tmp.begin(), tmp.end());
    else for (int k = 0; k + channels <= n; k += channels) { s->data.push_back(tmp[(size_t)k]); s->data.push_back(tmp[(size_t)k + 1]); }
}

JNIEXPORT jboolean JNICALL Java_cat_asra_rusc_Engine_padEnd(JNIEnv*, jobject, jint i) {
    if (i < 0 || i >= rusc::Pads::N) return JNI_FALSE;
    std::unique_ptr<rusc::PadSample> s;
    {
        std::lock_guard<std::mutex> g(padLock);
        s = std::move(padBuilding[i]);
    }
    if (!s || s->frames() < 4) return JNI_FALSE;
    s->data.resize(s->frames() * (size_t)s->ch);
    player.synth.pads.collect();
    player.synth.pads.publish(i, s.release());
    return JNI_TRUE;
}

JNIEXPORT void JNICALL Java_cat_asra_rusc_Engine_padClear(JNIEnv*, jobject, jint i) {
    if (i < 0 || i >= rusc::Pads::N) return;
    {
        std::lock_guard<std::mutex> g(padLock);
        padBuilding[i].reset();
    }
    player.synth.pads.collect();
    player.synth.pads.publish(i, new rusc::PadSample());
}

JNIEXPORT jint JNICALL Java_cat_asra_rusc_Engine_padMask(JNIEnv*, jobject) {
    player.synth.pads.collect();
    return (jint)player.synth.pads.playing.load();
}

JNIEXPORT jfloat JNICALL Java_cat_asra_rusc_Engine_padProgress(JNIEnv*, jobject, jint i) {
    if (i < 0 || i >= rusc::Pads::N) return 0.f;
    return player.synth.pads.progress[i].load();
}

}
