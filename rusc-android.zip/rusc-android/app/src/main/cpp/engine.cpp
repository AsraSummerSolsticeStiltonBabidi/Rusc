#include <algorithm>
#include <cstring>
#include <jni.h>
#include <oboe/Oboe.h>
#include <atomic>
#include <memory>
#include <mutex>
#include <vector>
#include <string>
#include <unistd.h>
#include <sys/stat.h>
#include "synth.h"
#include "soundfont.h"

using namespace oboe;

namespace {

class Player : public AudioStreamDataCallback, public AudioStreamErrorCallback {
public:
    rusc::Synth synth;

    bool open() {
        std::lock_guard<std::mutex> g(lock);
        if (stream) return true;
        AudioStreamBuilder b;
        b.setDirection(Direction::Output)
            ->setPerformanceMode(PerformanceMode::LowLatency)
            ->setSharingMode(SharingMode::Exclusive)
            ->setFormat(AudioFormat::Float)
            ->setChannelCount(ChannelCount::Stereo)
            ->setDataCallback(this)
            ->setErrorCallback(this);
        if (b.openStream(stream) != Result::OK) { stream.reset(); return false; }

        // Pide a la CPU que acelere cuando entran muchas notas de golpe (ADPF, si el móvil lo tiene)
        stream->setPerformanceHintEnabled(true);

        synth.init((float)stream->getSampleRate());
        tuner = std::make_unique<LatencyTuner>(*stream);
        tuner->setMinimumBufferSize(stream->getFramesPerBurst());
        applyBufferLocked();

        if (stream->requestStart() != Result::OK) {
            stream->close(); stream.reset(); tuner.reset();
            return false;
        }
        return true;
    }

    void close() {
        std::lock_guard<std::mutex> g(lock);
        if (stream) { stream->stop(); stream->close(); stream.reset(); }
        tuner.reset();
    }

    // 0 = automático; n = n ráfagas fijas
    void setBufferMode(int m) {
        std::lock_guard<std::mutex> g(lock);
        bufferMode.store(m);
        applyBufferLocked();
    }

    float latency() {
        std::lock_guard<std::mutex> g(lock);
        if (!stream) return -1.f;
        auto r = stream->calculateLatencyMillis();
        if (r) return (float)r.value();
        return 1000.f * stream->getBufferSizeInFrames() / stream->getSampleRate();
    }

    int xruns() {
        std::lock_guard<std::mutex> g(lock);
        if (!stream) return 0;
        auto r = stream->getXRunCount();
        return r ? r.value() : 0;
    }

    int bufferFrames() {
        std::lock_guard<std::mutex> g(lock);
        return stream ? stream->getBufferSizeInFrames() : 0;
    }

    int sampleRate() {
        std::lock_guard<std::mutex> g(lock);
        return stream ? stream->getSampleRate() : 0;
    }

    bool exclusive() {
        std::lock_guard<std::mutex> g(lock);
        return stream && stream->getSharingMode() == SharingMode::Exclusive;
    }

    DataCallbackResult onAudioReady(AudioStream*, void* data, int32_t frames) override {
        synth.render(static_cast<float*>(data), frames);
        if (bufferMode.load(std::memory_order_relaxed) == 0 && tuner) tuner->tune();
        return DataCallbackResult::Continue;
    }

    // Si cambia la salida de audio (auriculares, USB), se reabre el stream
    void onErrorAfterClose(AudioStream*, Result r) override {
        if (r == Result::ErrorDisconnected) {
            {
                std::lock_guard<std::mutex> g(lock);
                stream.reset();
                tuner.reset();
            }
            open();
        }
    }

private:
    std::shared_ptr<AudioStream> stream;
    std::unique_ptr<LatencyTuner> tuner;
    std::atomic<int> bufferMode{0};
    std::mutex lock;

    void applyBufferLocked() {
        if (!stream) return;
        const int m = bufferMode.load();
        if (m == 0) {
            if (tuner) tuner->requestReset();   // empieza en 1 ráfaga y crece solo si hay cortes
        } else {
            stream->setBufferSizeInFrames(stream->getFramesPerBurst() * m);
        }
    }
};

Player player;

// SoundFont abierto (las zonas en uso viven en bancos con su propia referencia al archivo)
std::mutex sfLock;
std::unique_ptr<rusc::SoundFont> soundFont;

// Lee todo el archivo a memoria nativa: así el hilo de audio nunca espera al disco
bool readAll(int fd, std::vector<uint8_t>& out) {
    struct stat st {};
    if (fstat(fd, &st) == 0 && st.st_size > 0) out.reserve((size_t)st.st_size);
    uint8_t buf[1 << 16];
    for (;;) {
        ssize_t n = read(fd, buf, sizeof buf);
        if (n < 0) return false;
        if (n == 0) return true;
        if (out.size() + (size_t)n > (size_t)2000 * 1024 * 1024) return false;
        out.insert(out.end(), buf, buf + n);
    }
}

}  // namespace

extern "C" {

JNIEXPORT jboolean JNICALL Java_cat_asra_rusc_Engine_start(JNIEnv*, jobject) {
    return player.open() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL Java_cat_asra_rusc_Engine_stop(JNIEnv*, jobject) {
    player.close();
}

JNIEXPORT void JNICALL Java_cat_asra_rusc_Engine_send(JNIEnv*, jobject, jint kind, jint a, jint b, jint c, jfloat v) {
    player.synth.q.push({(uint8_t)kind, (uint8_t)a, (uint8_t)b, (uint8_t)c, v});
}

JNIEXPORT void JNICALL Java_cat_asra_rusc_Engine_setBufferMode(JNIEnv*, jobject, jint mode) {
    player.setBufferMode(mode);
}

JNIEXPORT jfloat JNICALL Java_cat_asra_rusc_Engine_latencyMs(JNIEnv*, jobject) {
    return player.latency();
}

JNIEXPORT jint JNICALL Java_cat_asra_rusc_Engine_xruns(JNIEnv*, jobject) {
    return player.xruns();
}

JNIEXPORT jint JNICALL Java_cat_asra_rusc_Engine_bufferFrames(JNIEnv*, jobject) {
    return player.bufferFrames();
}

JNIEXPORT jint JNICALL Java_cat_asra_rusc_Engine_sampleRate(JNIEnv*, jobject) {
    return player.sampleRate();
}

JNIEXPORT jboolean JNICALL Java_cat_asra_rusc_Engine_exclusive(JNIEnv*, jobject) {
    return player.exclusive() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jint JNICALL Java_cat_asra_rusc_Engine_rpnRange(JNIEnv*, jobject) {
    return player.synth.rpnSeen.load();
}

JNIEXPORT jint JNICALL Java_cat_asra_rusc_Engine_channelMask(JNIEnv*, jobject) {
    return (jint)player.synth.chanMask.load();
}

JNIEXPORT jint JNICALL Java_cat_asra_rusc_Engine_voices(JNIEnv*, jobject) {
    return player.synth.voicesOn.load();
}

JNIEXPORT jfloat JNICALL Java_cat_asra_rusc_Engine_wheelCents(JNIEnv*, jobject) {
    return player.synth.wheelOut.load();
}

JNIEXPORT jfloat JNICALL Java_cat_asra_rusc_Engine_modWheel(JNIEnv*, jobject) {
    return player.synth.modOut.load();
}

JNIEXPORT jboolean JNICALL Java_cat_asra_rusc_Engine_loadSamples(JNIEnv* env, jobject, jint set, jbyteArray data) {
    const jsize len = env->GetArrayLength(data);
    std::vector<uint8_t> buf((size_t)len);
    env->GetByteArrayRegion(data, 0, len, reinterpret_cast<jbyte*>(buf.data()));
    return player.synth.loadSamples(set, buf.data(), (int)len) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL Java_cat_asra_rusc_Engine_samplesReady(JNIEnv*, jobject, jint set) {
    if (set < 0 || set >= rusc::Synth::NSETS) return JNI_FALSE;
    return player.synth.samplesReady(set) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL Java_cat_asra_rusc_Engine_buildPrimes(JNIEnv*, jobject, jint mask, jint maxHarm, jfloat slope) {
    player.synth.buildPrimes((uint32_t)mask, maxHarm, slope);
}

JNIEXPORT jfloat JNICALL Java_cat_asra_rusc_Engine_presetDefault(JNIEnv*, jobject, jint preset, jint which) {
    return rusc::Synth::presetDefault(preset, which);
}

JNIEXPORT jint JNICALL Java_cat_asra_rusc_Engine_heldPitches(JNIEnv* env, jobject, jfloatArray out) {
    float tmp[rusc::Synth::MAXHELD];
    const int n = player.synth.readHeld(tmp, rusc::Synth::MAXHELD);
    const int len = std::min(n, (int)env->GetArrayLength(out));
    if (len > 0) env->SetFloatArrayRegion(out, 0, len, tmp);
    return len;
}

// Abre un .sf2 desde un descriptor (se cierra aquí). Devuelve el número de presets o -1.
JNIEXPORT jint JNICALL Java_cat_asra_rusc_Engine_sf2Open(JNIEnv*, jobject, jint fd) {
    std::vector<uint8_t> bytes;
    const bool ok = readAll(fd, bytes);
    close(fd);
    if (!ok) return -1;
    auto sf = std::make_unique<rusc::SoundFont>();
    if (!sf->open(std::move(bytes))) return -1;
    std::lock_guard<std::mutex> g(sfLock);
    soundFont = std::move(sf);
    return soundFont->count();
}

JNIEXPORT jstring JNICALL Java_cat_asra_rusc_Engine_sf2Name(JNIEnv* env, jobject, jint i) {
    std::lock_guard<std::mutex> g(sfLock);
    const std::string n = soundFont ? soundFont->name(i) : std::string();
    return env->NewStringUTF(n.c_str());   // solo ASCII: siempre UTF-8 válido
}

JNIEXPORT jboolean JNICALL Java_cat_asra_rusc_Engine_sf2Select(JNIEnv*, jobject, jint i) {
    rusc::SfBank* b = nullptr;
    {
        std::lock_guard<std::mutex> g(sfLock);
        if (soundFont) b = soundFont->makeBank(i);
    }
    if (!b) return JNI_FALSE;
    player.synth.collectBanks();
    player.synth.publishBank(b);
    return JNI_TRUE;
}

JNIEXPORT void JNICALL Java_cat_asra_rusc_Engine_sf2Collect(JNIEnv*, jobject) {
    player.synth.collectBanks();
}

}
