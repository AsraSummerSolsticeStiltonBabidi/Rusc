#include "soundfont.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>

namespace rusc {

namespace {

inline uint16_t u16(const uint8_t* p) { return (uint16_t)(p[0] | (p[1] << 8)); }
inline int16_t s16(const uint8_t* p) { return (int16_t)u16(p); }
inline uint32_t u32(const uint8_t* p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }

// Generadores SF2 que usamos
enum {
    G_START = 0, G_END = 1, G_LOOPSTART = 2, G_LOOPEND = 3, G_START_C = 4,
    G_FC = 8, G_Q = 9, G_END_C = 12,
    G_ATTACK = 34, G_HOLD = 35, G_DECAY = 36, G_SUSTAIN = 37, G_RELEASE = 38,
    G_KEY2HOLD = 39, G_KEY2DECAY = 40, G_INSTRUMENT = 41, G_KEYRANGE = 43, G_VELRANGE = 44,
    G_LOOPSTART_C = 45, G_ATTEN = 48, G_LOOPEND_C = 50, G_COARSE = 51, G_FINE = 52,
    G_SAMPLE = 53, G_MODES = 54, G_SCALE = 56, G_ROOT = 58, G_COUNT = 61
};

struct Gens {
    int16_t v[G_COUNT];
    bool set[G_COUNT];
    uint8_t keyLo = 0, keyHi = 127, velLo = 0, velHi = 127;
};

void instDefaults(Gens& g) {
    std::memset(g.v, 0, sizeof(g.v));
    std::memset(g.set, 0, sizeof(g.set));
    g.v[G_FC] = 13500;
    g.v[G_ATTACK] = g.v[G_HOLD] = g.v[G_DECAY] = g.v[G_RELEASE] = -12000;
    g.v[G_SCALE] = 100;
    g.v[G_ROOT] = -1;
    g.keyLo = 0; g.keyHi = 127; g.velLo = 0; g.velHi = 127;
}

void presetDefaults(Gens& g) {
    std::memset(g.v, 0, sizeof(g.v));
    std::memset(g.set, 0, sizeof(g.set));
    g.keyLo = 0; g.keyHi = 127; g.velLo = 0; g.velHi = 127;
}

// Aplica los generadores [from, to) de una lista pgen/igen sobre g
void readGens(const uint8_t* list, uint32_t n, uint32_t from, uint32_t to, Gens& g) {
    if (from > to || to > n) return;
    for (uint32_t i = from; i < to; i++) {
        const uint8_t* r = list + i * 4;
        const uint16_t op = u16(r);
        if (op >= G_COUNT) continue;
        if (op == G_KEYRANGE) { g.keyLo = r[2]; g.keyHi = r[3]; }
        else if (op == G_VELRANGE) { g.velLo = r[2]; g.velHi = r[3]; }
        g.v[op] = s16(r + 2);
        g.set[op] = true;
    }
}

bool hasGen(const uint8_t* list, uint32_t n, uint32_t from, uint32_t to, uint16_t op) {
    if (from > to || to > n) return false;
    for (uint32_t i = from; i < to; i++) if (u16(list + i * 4) == op) return true;
    return false;
}

inline float tcToSec(int tc) { return std::exp2(std::clamp(tc, -12000, 8000) / 1200.f); }

// Generadores que el preset suma a los del instrumento
const int ADDITIVE[] = {G_FC, G_Q, G_ATTACK, G_HOLD, G_DECAY, G_SUSTAIN, G_RELEASE,
                        G_KEY2HOLD, G_KEY2DECAY, G_ATTEN, G_COARSE, G_FINE, G_SCALE};

}  // namespace

bool SoundFont::open(std::vector<uint8_t>&& bytes) {
    auto f = std::make_shared<SfFile>();
    f->bytes = std::move(bytes);
    const uint8_t* d = f->bytes.data();
    const size_t size = f->bytes.size();
    if (size < 12 || std::memcmp(d, "RIFF", 4) != 0 || std::memcmp(d + 8, "sfbk", 4) != 0) return false;

    const uint8_t* smplChunk = nullptr;
    uint32_t smplSize = 0;
    struct Sub { const char* id; const uint8_t** ptr; uint32_t* count; uint32_t rec; };
    const uint8_t *pmod = nullptr, *imod = nullptr;
    uint32_t nPmod = 0, nImod = 0;
    Sub subs[] = {
        {"phdr", &phdr, &nPhdr, 38}, {"pbag", &pbag, &nPbag, 4}, {"pmod", &pmod, &nPmod, 10},
        {"pgen", &pgen, &nPgen, 4}, {"inst", &inst, &nInst, 22}, {"ibag", &ibag, &nIbag, 4},
        {"imod", &imod, &nImod, 10}, {"igen", &igen, &nIgen, 4}, {"shdr", &shdr, &nShdr, 46}};

    size_t pos = 12;
    const size_t riffEnd = std::min(size, (size_t)u32(d + 4) + 8);
    while (pos + 12 <= riffEnd) {
        const uint32_t len = u32(d + pos + 4);
        if (pos + 8 + (size_t)len > riffEnd) break;
        if (std::memcmp(d + pos, "LIST", 4) == 0) {
            const bool sdta = std::memcmp(d + pos + 8, "sdta", 4) == 0;
            const bool pdta = std::memcmp(d + pos + 8, "pdta", 4) == 0;
            size_t p = pos + 12;
            const size_t end = pos + 8 + len;
            while (p + 8 <= end) {
                const uint32_t l = u32(d + p + 4);
                if (p + 8 + (size_t)l > end) break;
                if (sdta && std::memcmp(d + p, "smpl", 4) == 0) { smplChunk = d + p + 8; smplSize = l; }
                if (pdta)
                    for (auto& s : subs)
                        if (std::memcmp(d + p, s.id, 4) == 0) { *s.ptr = d + p + 8; *s.count = l / s.rec; }
                p += 8 + l + (l & 1);
            }
        }
        pos += 8 + len + (len & 1);
    }
    if (!smplChunk || !phdr || !pbag || !pgen || !inst || !ibag || !igen || !shdr) return false;
    if (nPhdr < 2 || nInst < 2 || nShdr < 2) return false;
    if (((uintptr_t)smplChunk & 1) != 0) return false;   // los datos RIFF van alineados a 2
    f->smpl = reinterpret_cast<const int16_t*>(smplChunk);
    f->nsmpl = smplSize / 2;

    order.clear();
    for (uint32_t i = 0; i + 1 < nPhdr; i++) order.push_back((int)i);
    std::sort(order.begin(), order.end(), [&](int a, int b) {
        const uint8_t* pa = phdr + a * 38;
        const uint8_t* pb = phdr + b * 38;
        uint32_t ka = ((uint32_t)u16(pa + 22) << 16) | u16(pa + 20);
        uint32_t kb = ((uint32_t)u16(pb + 22) << 16) | u16(pb + 20);
        return ka < kb;
    });
    file = f;
    return true;
}

std::string SoundFont::name(int i) const {
    if (i < 0 || i >= (int)order.size()) return "";
    const uint8_t* p = phdr + order[i] * 38;
    char buf[40];
    std::snprintf(buf, sizeof(buf), "%03u:%03u ", u16(p + 22), u16(p + 20));
    std::string s(buf);
    for (int k = 0; k < 20 && p[k]; k++) s += (p[k] >= 32 && p[k] < 127) ? (char)p[k] : '?';
    while (!s.empty() && s.back() == ' ') s.pop_back();
    return s;
}

SfBank* SoundFont::makeBank(int i) const {
    if (!file || i < 0 || i >= (int)order.size()) return nullptr;
    auto* bank = new SfBank();
    bank->file = file;
    const uint32_t ph = (uint32_t)order[i];
    const uint32_t b0 = u16(phdr + ph * 38 + 24), b1 = u16(phdr + (ph + 1) * 38 + 24);
    if (b0 > b1 || b1 >= nPbag) { delete bank; return nullptr; }

    Gens pGlobal; presetDefaults(pGlobal);
    for (uint32_t zb = b0; zb < b1; zb++) {
        const uint32_t g0 = u16(pbag + zb * 4), g1 = u16(pbag + (zb + 1) * 4);
        if (!hasGen(pgen, nPgen, g0, g1, G_INSTRUMENT)) {
            if (zb == b0) readGens(pgen, nPgen, g0, g1, pGlobal);   // zona global del preset
            continue;
        }
        Gens pz = pGlobal;
        readGens(pgen, nPgen, g0, g1, pz);
        const int instIdx = pz.v[G_INSTRUMENT];
        if (instIdx < 0 || (uint32_t)instIdx + 1 >= nInst) continue;
        const uint32_t ib0 = u16(inst + instIdx * 22 + 20), ib1 = u16(inst + (instIdx + 1) * 22 + 20);
        if (ib0 > ib1 || ib1 >= nIbag) continue;

        Gens iGlobal; instDefaults(iGlobal);
        for (uint32_t zi = ib0; zi < ib1; zi++) {
            const uint32_t h0 = u16(ibag + zi * 4), h1 = u16(ibag + (zi + 1) * 4);
            if (!hasGen(igen, nIgen, h0, h1, G_SAMPLE)) {
                if (zi == ib0) readGens(igen, nIgen, h0, h1, iGlobal);   // zona global del instrumento
                continue;
            }
            Gens g = iGlobal;
            readGens(igen, nIgen, h0, h1, g);
            const int sIdx = g.v[G_SAMPLE];
            if (sIdx < 0 || (uint32_t)sIdx + 1 >= nShdr) continue;
            const uint8_t* sh = shdr + sIdx * 46;
            if (u16(sh + 44) & 0x8000) continue;   // muestras en ROM: no disponibles

            for (int op : ADDITIVE) g.v[op] = (int16_t)std::clamp((int)g.v[op] + (int)pz.v[op], -32768, 32767);

            SfRegion r;
            r.keyLo = std::max(g.keyLo, pz.keyLo); r.keyHi = std::min(g.keyHi, pz.keyHi);
            r.velLo = std::max(g.velLo, pz.velLo); r.velHi = std::min(g.velHi, pz.velHi);
            if (r.keyLo > r.keyHi || r.velLo > r.velHi) continue;

            const int64_t start = (int64_t)u32(sh + 20) + g.v[G_START] + 32768LL * g.v[G_START_C];
            const int64_t end = (int64_t)u32(sh + 24) + g.v[G_END] + 32768LL * g.v[G_END_C];
            const int64_t ls = (int64_t)u32(sh + 28) + g.v[G_LOOPSTART] + 32768LL * g.v[G_LOOPSTART_C];
            const int64_t le = (int64_t)u32(sh + 32) + g.v[G_LOOPEND] + 32768LL * g.v[G_LOOPEND_C];
            if (start < 0 || end <= start + 4 || end > (int64_t)file->nsmpl - 3) continue;
            r.start = (uint32_t)start; r.end = (uint32_t)end;
            const int mode = g.v[G_MODES] & 3;
            if ((mode == 1 || mode == 3) && ls >= start && le <= end && le > ls + 2) {
                r.loopMode = (uint8_t)mode; r.loopStart = (uint32_t)ls; r.loopEnd = (uint32_t)le;
            }

            const uint32_t rate = u32(sh + 36);
            r.srcRate = rate >= 400 && rate <= 200000 ? (float)rate : 44100.f;
            int root = g.v[G_ROOT] >= 0 && g.v[G_ROOT] <= 127 ? g.v[G_ROOT] : sh[40];
            if (root > 127) root = 60;
            // rangos de la especificación SF2 2.04: un archivo dañado no puede desbocar la afinación
            r.scale = (float)std::clamp((int)g.v[G_SCALE], 0, 1200);
            r.offset = std::clamp((int)g.v[G_COARSE], -120, 120) * 100.f + std::clamp((int)g.v[G_FINE], -99, 99)
                     + std::clamp((int)(int8_t)sh[41], -99, 99) - r.scale * root;

            // Atenuación con el factor 0,4 compatible con E-mu (como FluidSynth)
            r.gain = std::pow(10.f, -0.4f * std::clamp((int)g.v[G_ATTEN], 0, 1440) / 200.f);
            r.attack = tcToSec(g.v[G_ATTACK]);
            r.hold = g.v[G_HOLD] <= -12000 ? 0.f : tcToSec(g.v[G_HOLD]);
            r.decay = tcToSec(g.v[G_DECAY]);
            r.sustain = std::pow(10.f, -std::clamp((int)g.v[G_SUSTAIN], 0, 1440) / 200.f);
            r.release = tcToSec(g.v[G_RELEASE]);
            r.keyToHold = g.v[G_KEY2HOLD];
            r.keyToDecay = g.v[G_KEY2DECAY];

            const int fc = std::clamp((int)g.v[G_FC], 1500, 13500);
            if (fc < 13500) {
                r.filterHz = 8.176f * std::exp2(fc / 1200.f);
                const float qdb = std::clamp((int)g.v[G_Q], 0, 960) / 10.f;
                r.filterQ = std::max(.5f, .707f * std::pow(10.f, qdb / 20.f));
            }
            bank->regions.push_back(r);
        }
    }
    if (bank->regions.empty()) { delete bank; return nullptr; }
    return bank;
}

}  // namespace rusc
